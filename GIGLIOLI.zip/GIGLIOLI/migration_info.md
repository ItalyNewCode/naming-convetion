# 🚀 Migration Report

## 📌 Version: 11.14

- Updated ui-build.js file


- Updated `app.web.compression.mimetypes.excludePatterns` to include ``text/event-stream`` in app.properties


- Removed [`app.build.ui.spa.enabled, app.build.ui.ng.config, app.build.ui.mode`] properties that are starting with ['build.\*' and 'app.build.\*'] from 'app.properties'.
- Resolved placeholders for properties such as [`app.proxy.port, app.cdnUrl, app.web.compression.mimetypes.excludePatterns, ...and 11 more.`] in 'app.properties' with actual values from 'development.properties'.
- Removed duplicate properties from the profile files: `[ development: (app.proxy.port, app.cdnUrl, app.web.compression.mimetypes.excludePatterns, ...and 11 more.) ]; [ prod: (app.proxy.port, app.cdnUrl, app.web.compression.mimetypes.excludePatterns, ...and 10 more.) ]; [ deployment: (app.proxy.port, app.cdnUrl, app.web.compression.mimetypes.excludePatterns, ...and 10 more.) ]` that matched the values in app.properties 
- Removed service properties from profile(s) [`[ development : (70) ], [ prod : (64) ], [ deployment : (67) ]`] that matched the default values in their respective service JSONs.
- Removed '/src/conf' folder(s) from the service(s) [`EVENTI, GIGLIOLI_PREVENTIVI, ana01, ...and 1 more.`].
- Removed [`locations , yamlLocations`] property source references from 'appPropertySourcesPlaceHolderConfigurer' bean in 'project-springapp.xml'.


- Updated build.xml file


- Updated maven version from `3.9.11` to  `3.9.12` in `maven-wrapper.properties` file 


## 📌 Version: 11.13

- Updated .gitignore with new patterns `[generated-react-app/**, src/main/webapp/design-tokens/temp-tokens, src/main/webapp/design-tokens/app.override.css]`


- Added new default file `package-override.json` to /build-src/
- Added new default file `eslintrc-override.js` to /build-src/


- Removed aria label attribute from `12` page markup files


- Updated ui-build.js file
- Updated build.xml file


