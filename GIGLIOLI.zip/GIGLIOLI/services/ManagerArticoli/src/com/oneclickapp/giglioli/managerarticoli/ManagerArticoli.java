/*Copyright (c) 2022–2023 oneclickapp.com – Tutti i diritti riservati.

Il presente software è da considerarsi a tutti gli effetti un’opera intellettuale riservata, contenente informazionistrettamente confidenziali e di esclusiva titolarità di oneclickapp.com, marchio e divisione operativa di Plumma S.R.L.. Qualsiasi utilizzo, riproduzione, distribuzione, comunicazione o divulgazione, totale o parziale, del software o della relativa documentazione, in qualunque forma o modalità, è espressamente vietato se non previamente autorizzato per iscritto da oneclickapp.com o regolato da uno specifico accordo di licenza.

L’utente o licenziatario è vincolato a trattare tutte le informazioni contenute nel software come strettamente confidenziali e a non utilizzarle per scopi diversi da quelli esplicitamente consentiti nel contratto di licenza del codice sorgente sottoscritto con oneclickapp.com, impegnandosi altresì a non divulgarle a terzi senza il previo consenso scritto della stessa.

La proprietà intellettuale del so*/
package com.oneclickapp.giglioli.managerarticoli;

import com.oneclickapp.giglioli.GigliolicReportService;
import com.oneclickapp.giglioli.MasterExcelExporter;
import com.oneclickapp.giglioli.giglioli_preventivi.Articoli;
import com.oneclickapp.giglioli.giglioli_preventivi.ArticoliComunicazioni;
import com.oneclickapp.giglioli.giglioli_preventivi.ArticoliPropieta;
import com.oneclickapp.giglioli.giglioli_preventivi.ArticoliStati;
import com.oneclickapp.giglioli.giglioli_preventivi.Bom;
import com.oneclickapp.giglioli.giglioli_preventivi.Note;
import com.oneclickapp.giglioli.giglioli_preventivi.NoteId;
import com.oneclickapp.giglioli.giglioli_preventivi.models.query.GetAllMasterArticlesResponse;
import com.oneclickapp.giglioli.giglioli_preventivi.service.*;
import com.oneclickapp.giglioli.models.bom.BOMArticolo;
import com.oneclickapp.giglioli.models.bom.Materiali;
import com.oneclickapp.giglioli.models.bom.LavorazioniEsterne;
import com.oneclickapp.giglioli.models.bom.LavorazioniInterne;
import com.oneclickapp.giglioli.models.bom.Sottoelementus;
import com.oneclickapp.giglioli.models.master.ArticoloMaster; 
import com.oneclickapp.giglioli.models.master.Master; 
import com.oneclickapp.giglioli.models.master.Scheda;
import com.oneclickapp.giglioli.ste01.service.Ste01Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wavemaker.commons.json.JSONUtils;
import com.wavemaker.runtime.commons.file.model.DownloadResponse;
import com.wavemaker.runtime.data.dao.query.WMQueryExecutor;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Qualifier;

import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import com.wavemaker.runtime.security.SecurityService;
import com.wavemaker.runtime.service.annotations.ExposeToClient;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

//import com.oneclickapp.giglioli.managerarticoli.model.*;


@ExposeToClient
public class ManagerArticoli {

    private static final Logger logger = LoggerFactory.getLogger(ManagerArticoli.class);

    /**
     * Soglia massima per {@code provv + scontoPremio} (decimale). Oltre, il denominatore
     * {@code 1 - provv - scontoPremio} del pareggio diventa troppo piccolo e i lordi (e le provv/sconti)
     * esplodono numericamente o superano i DECIMAL del DB, pur restando {@code < 1}.
     * Valori tipo PROV=33 e SCONTO_PREMIO_DEFAULT=65 (98%) sono tipici di test errati.
     */
    private static final double MAX_SOMMA_PROVV_SCONTO_PREMIO = 0.97;

    // Classe interna per chiave composita Scheda+Stagione (compatibile Java 8)
    private static class SchedaStagioneKey {
        private final Integer schedaId;
        private final String stagione;

        public SchedaStagioneKey(Integer schedaId, String stagione) {
            this.schedaId = schedaId;
            this.stagione = stagione;
        }

        public Integer getSchedaId() {
            return schedaId;
        }

        public String getStagione() {
            return stagione;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            SchedaStagioneKey that = (SchedaStagioneKey) o;
            return java.util.Objects.equals(schedaId, that.schedaId) &&
                    java.util.Objects.equals(stagione, that.stagione);
        }

        @Override
        public int hashCode() {
            return java.util.Objects.hash(schedaId, stagione);
        }
    }

    // Chiave di raggruppamento master: evita discrepanze tra progetto/brand/grouptech.
    private static class MasterGroupingKey {
        private final String nomeProgetto;
        private final String brand;
        private final String groupTech;

        public MasterGroupingKey(String nomeProgetto, String brand, String groupTech) {
            this.nomeProgetto = nomeProgetto;
            this.brand = brand;
            this.groupTech = groupTech;
        }

        public String getNomeProgetto() {
            return nomeProgetto;
        }

        public String getBrand() {
            return brand;
        }

        public String getGroupTech() {
            return groupTech;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            MasterGroupingKey that = (MasterGroupingKey) o;
            return Objects.equals(nomeProgetto, that.nomeProgetto)
                    && Objects.equals(brand, that.brand)
                    && Objects.equals(groupTech, that.groupTech);
        }

        @Override
        public int hashCode() {
            return Objects.hash(nomeProgetto, brand, groupTech);
        }
    }

    /**
     * Stagione usata per listini e parametri di calcolo sulla BOM: se {@code defaultListini} è valorizzato
     * (scelta operatore in maschera BOM), ha priorità; altrimenti si usa la stagione anagrafica dell'articolo.
     * L'anagrafica articolo non va modificata per questo scopo.
     */
    private static String resolveStagioneRiferimentoCalcolo(String defaultListiniBom, Articoli articolo) {
        if (defaultListiniBom != null && !defaultListiniBom.trim().isEmpty()) {
            return defaultListiniBom.trim();
        }
        if (articolo != null && articolo.getStagioneAnno() > 0 && articolo.getStagioneTipo() != null
                && !articolo.getStagioneTipo().isEmpty()) {
            return articolo.getStagioneAnno() + articolo.getStagioneTipo();
        }
        return null;
    }

    @Autowired
    private SecurityService securityService;

    @Autowired
    private ArticoliService articoliService;

    @Autowired
    private BomService bomService;

    @Autowired
    private Ste01Service ste01RestService;

    @Autowired
    private GIGLIOLI_PREVENTIVIQueryExecutorService giglioliPreventiviQueryExecutorService;

    @Autowired
    private ListinoMaterialiService listinoMaterialiService;

    @Autowired
    private ListinoLavorazioniEsterneService listinoLavorazioniEsterneService;

    @Autowired
    private ParametersService parametersService;

    @Autowired
    private com.oneclickapp.giglioli.giglioli_preventivi.service.RigheAggiuntiveBomService righeAggiuntiveBomService;

    @Autowired
    private com.oneclickapp.giglioli.giglioli_preventivi.service.IntegrationChangeQueueService integrationChangeQueueService;

    @Autowired
    @Qualifier("GIGLIOLI_PREVENTIVI.NoteService")
    private NoteService noteService;

    @Autowired
    @Qualifier("GIGLIOLI_PREVENTIVI.ArticoliPropietaService")
    private ArticoliPropietaService articoliPropietaService;

    @Autowired
    @Qualifier("GIGLIOLI_PREVENTIVI.ArticoliComunicazioniService")
    private ArticoliComunicazioniService articoliComunicazioniService;

    @Autowired
    @Qualifier("GIGLIOLI_PREVENTIVI.ArticoliStatiService")
    private ArticoliStatiService articoliStatiService;

    @Autowired
    private org.springframework.context.ApplicationContext applicationContext;

    @Autowired
    @Qualifier("GIGLIOLI_PREVENTIVIWMQueryExecutor")
    private WMQueryExecutor wmQueryExecutor;

    /**
     * Recupera una vista dei master raggruppati per progetto, con i relativi articoli e schede.
     * <p>
     * Questo metodo esegue una query per ottenere tutti gli articoli, li raggruppa per nome del progetto,
     * quindi crea una lista di oggetti {@link Master}, ciascuno contenente una lista di schede
     * e articoli associati. Infine, restituisce una {@link Page} contenente la lista di {@link Master}.
     *
     * @param pageable Oggetto per la paginazione dei risultati.
     * @return Una {@link Page} contenente la lista di {@link Master} per il progetto.
     */
    public Page<Master> getMasterView(
            List<Integer> idsArticoli,
            String nomeProgetto,
            String senzaProgetto,
            String descProgetto,
            String descScheda,
            String codiceScheda,
            String brand,
            String groupTech,
            String clienteRagioneSociale,
            String proprietaArticolo,
            String stagione,
            String articolo,
            String descArticolo,
            String statoArticolo,
            String campione,
            String codiceComponentiDistinta,
            Pageable pageable) {
        // Log per il monitoraggio del flusso del metodo
        logger.debug("Finding all Articolis");
        List<Integer> idsArticoliFiltro = normalizeIdsArticoliFilter(idsArticoli);

        Map<MasterGroupingKey, List<GetAllMasterArticlesResponse>> progetti = new LinkedHashMap<>();

        // Esegui la query per recuperare tutti gli articoli e raggruppali per nome del progetto

        progetti = giglioliPreventiviQueryExecutorService.executeGetAllMasterArticles(
                        idsArticoliFiltro,
                        nomeProgetto,
                        descProgetto,
                        descScheda,
                        codiceScheda,
                        brand,
                        groupTech,
                        clienteRagioneSociale,
                        proprietaArticolo,
                        stagione,
                        articolo,
                        descArticolo,
                        statoArticolo,
                        codiceComponentiDistinta,
                        campione,
                        Pageable.unpaged())
                .stream()
                .collect(Collectors.groupingBy(a -> new MasterGroupingKey(
                                a.getNomeProgetto() != null ? a.getNomeProgetto() : "SENZA PROGETTO",
                                a.getBrand() != null ? a.getBrand() : "",
                                a.getGrouptech() != null ? a.getGrouptech() : ""),
                        LinkedHashMap::new,
                        Collectors.toList()));
        if (Objects.isNull(senzaProgetto)) {
            // do nothing
        } else if (senzaProgetto.equals("true")) {
            progetti = progetti.entrySet()
                    .stream()
                    .filter(entry -> {
                        return !"SENZA PROGETTO".equals(entry.getKey().getNomeProgetto());

                    })
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        } else if (senzaProgetto.equals("false")) {
            progetti = progetti.entrySet()
                    .stream()
                    .filter(entry -> {
                        return "SENZA PROGETTO".equals(entry.getKey().getNomeProgetto());
                    })
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));


        }


        // Log per visualizzare la dimensione dei progetti raggruppati
        logger.debug("PROGETTI SIZE {} {}", progetti.size(), progetti.toString());

        // Crea una lista vuota di Master che conterrà i risultati finali
        List<Master> masterView = new ArrayList<>();

        // Contatore per l'indice del progetto
        AtomicInteger i = new AtomicInteger();

        // Itera sui progetti raggruppati per nome progetto
        progetti.forEach((masterKey, articoli) -> {


            // Crea un oggetto Master per ogni progetto
            Master master = new Master();
            master.setProgetto(masterKey.getNomeProgetto()); // Imposta il nome del progetto
            master.setProgettoIndex(i.getAndIncrement()); // Imposta l'indice del progetto
            master.setBrand(masterKey.getBrand());
            master.setGroupTecnology(masterKey.getGroupTech());


            // Raggruppa gli articoli per Scheda
            Map<SchedaStagioneKey, List<GetAllMasterArticlesResponse>> listaArticoliPerScheda = articoli.stream().collect(Collectors.groupingBy(
                    t -> new SchedaStagioneKey(t.getSchedaId(), t
                            .getStagione())));


            // GetAllMasterArticlesResponse::getSchedaId));

            // Log per visualizzare gli articoli raggruppati per scheda
            logger.debug("(getMasterView) lista listaArticoliPerScheda {}", listaArticoliPerScheda.toString());

            // Lista di Schede associate al progetto
            List<Scheda> schedePerProgetto = new ArrayList<>();

            // Itera sulle schede raggruppate per codice
            listaArticoliPerScheda.forEach((codicescheda, articoliMasterDellaScheda) -> {
                // Crea una nuova scheda
                Scheda scheda = new Scheda();
                scheda.setNumero(codicescheda.schedaId); // Imposta il numero della scheda
                scheda.setStagione(codicescheda.stagione);

                // Lista per contenere gli articoli della scheda
                List<ArticoloMaster> articoliDellaScheda = new ArrayList<>();

                // Itera sugli articoli della scheda e crea gli oggetti Articoli
                articoliMasterDellaScheda.forEach(articoloMaster -> {
                    // Crea un oggetto Articoli e imposta i relativi dati
                    ArticoloMaster articolo1 = new ArticoloMaster();
                    articolo1.setSchedaId(articoloMaster.getSchedaId());
                    articolo1.setLogo(articoloMaster.getLogo());
                    articolo1.setIndustrializzato(articoloMaster.getIndustrializzato());
                    articolo1.setClienteArticolo(articoloMaster.getClienteArticolo());
                    articolo1.setGrouptech(articoloMaster.getGrouptech());
                    articolo1.setStagioneAnno(articoloMaster.getStagioneAnno());
                    articolo1.setClienteRagioneSociale(articoloMaster.getClienteRagioneSociale());
                    articolo1.setForma(articoloMaster.getForma());
                    articolo1.setModellistaCodice(articoloMaster.getModellistaCodice());
                    articolo1.setForma(articoloMaster.getForma());
                    articolo1.setStagioneTipo(articoloMaster.getStagioneTipo());
                    articolo1.setBrand(articoloMaster.getBrand());
                    articolo1.setDescrizioneInterna(articoloMaster.getDescrizioneInterna());
                    articolo1.setDescrizione(articoloMaster.getDescrizioneArticolo());
                    articolo1.setModellistaNome(articoloMaster.getModellistaNome());
                    articolo1.setClienteCodice(articoloMaster.getClienteCodice());
                    articolo1.setCampione(articoloMaster.getCampione());
                    articolo1.setScatola(articoloMaster.getScatola());
                    articolo1.setArticolo(articoloMaster.getArticolo());
                    articolo1.setModificationTimestamp(articoloMaster.getModificationTimestamp());
                    articolo1.setCreationTimestamp(articoloMaster.getCreationTimestamp());
                    articolo1.setId(articoloMaster.getIdArticolo());
                    articolo1.setStato(articoloMaster.getStatoArticolo());
                    articolo1.setPropieta(articoloMaster.getPropieta());
                    
                    // Popola campi BOM quando la riga bom è storicizzata (getAllMasterArticles: BOM_STORICIZZATO = bom.storicizzato).
                    // Nota: GetAllMasterArticlesResponse.bomStoricizzato è Short (0/1), non Boolean.
                    Short bomStoricizzato = articoloMaster.getBomStoricizzato();
                    if (bomStoricizzato != null && bomStoricizzato == 1) {
                        articolo1.setStato(articoloMaster.getStatoPreventivo());
                        articolo1.setMinuti(articoloMaster.getMinutiLavorazione());
                        articolo1.setConsumo(articoloMaster.getConsumoCuoioMq() != null ? articoloMaster.getConsumoCuoioMq() : 0.0);
                        articolo1.setCostoComponenti(articoloMaster.getCostoComponenti() != null ? articoloMaster.getCostoComponenti() : 0.0);
                        articolo1.setCostoScheda(articoloMaster.getCostoScheda() != null ? articoloMaster.getCostoScheda() : 0.0);
                        articolo1.setCostoTotale(articoloMaster.getCostoTotale() != null ? articoloMaster.getCostoTotale() : 0.0);
                        articolo1.setEuroPareggio(articoloMaster.getPareggioPrezzoLordo());
                        articolo1.setEuroObiettivo(articoloMaster.getObiettivoPrezzoLordo());
                        articolo1.setEuroAs400(articoloMaster.getAs400PrezzoLordo());
                        articolo1.setPropostoPrezzoLordo(articoloMaster.getPropostoPrezzoLordo());
                        articolo1.setMCont(articoloMaster.getMcontrib());
                        articolo1.setMContMin(articoloMaster.getMcontribMin());
                        
                        // m_va = prezzoVendita - pareggioNetto
                        // prezzoVendita = proposto (se esiste) altrimenti AS400
                        Double prezzoVendita = articoloMaster.getPropostoPrezzoLordo() != null && articoloMaster.getPropostoPrezzoLordo() > 0
                                ? articoloMaster.getPropostoPrezzoLordo()
                                : articoloMaster.getAs400PrezzoLordo();
                        Double pareggioNetto = articoloMaster.getPareggioPrezzoNetto();
                        
                        if (prezzoVendita != null && pareggioNetto != null) {
                            Double mVa = prezzoVendita - pareggioNetto;
                            articolo1.setMVa(Math.round(mVa * 100.0) / 100.0);
                            
                            // m_percentuale = (m_va / prezzoVendita) * 100, arrotondato a 1 decimale
                            if (prezzoVendita != 0) {
                                Double mPerc = (mVa / prezzoVendita) * 100.0;
                                articolo1.setMPercentuale(Math.round(mPerc * 10.0) / 10.0);
                            }
                        }
                    }
                    
                    // Popola flag calcolo: solo se il calcolo è stato effettivamente eseguito
                    // (statoPreventivo diverso da "RICHIESTO" indica che il calcolo è avvenuto)
                    String esito = articoloMaster.getEsitoCalcolo();
                    String statoPrev = articoloMaster.getStatoPreventivo();
                    if (esito != null && statoPrev != null && !"RICHIESTO".equals(statoPrev)) {
                        articolo1.setFlagCalcolo(esito);
                    }
                    
                    // Popola flag storicizzato: "S" se storicizzato
                    if (bomStoricizzato != null && bomStoricizzato == 1) {
                        articolo1.setFlagStoricizzato("S");
                    }
                    
                    // TODO: implementare flag_parametri quando sarà disponibile il campo parametri_custom nel BOM
                    // articolo1.setFlagParametri("M") se l'operatore ha usato parametri non standard
                    
                    // Popola data_comunicazione (dalla query SQL)
                    if (articoloMaster.getDataComunicazione() != null) {
                        articolo1.setDataComunicazione((double) articoloMaster.getDataComunicazione().getTime());
                    }
                    
                    // Aggiungi l'articolo alla lista degli articoli della scheda
                    articoliDellaScheda.add(articolo1);
                });

                // Imposta la lista degli articoli nella scheda
                scheda.setArticoli(articoliDellaScheda);


                // Aggiungi la scheda alla lista delle schede per il progetto
                schedePerProgetto.add(scheda);
            });


            // Imposta le schede nel master
            master.setSchede(schedePerProgetto);

            // Aggiungi il master alla lista dei master
            masterView.add(master);
        });

        // Totale progetti
        int total = masterView.size();

        // Offset e dimensione pagina
        int start = (int) pageable.getOffset();
        int end = Math.min(start + pageable.getPageSize(), total);

        // Protezione offset fuori range
        List<Master> pagedMasters = start >= total ? Collections.emptyList() : masterView.subList(start, end);

        // Ritorna la pagina corretta
        return new PageImpl<>(pagedMasters, pageable, total);
    }


    public DownloadResponse downloadMasterView(
            String nomeProgetto,
            String senzaProgetto,
            String descProgetto,
            String descScheda,
            String codiceScheda,
            String brand,
            String groupTech,
            String clienteRagioneSociale,
            String proprietaArticolo,
            String stagione,
            String articolo,
            String descArticolo,
            String statoArticolo,
            String campione,
            String codiceComponentiDistinta,
            Pageable pageable) {
        return downloadMasterViewByIds(
                null,
                nomeProgetto,
                senzaProgetto,
                descProgetto,
                descScheda,
                codiceScheda,
                brand,
                groupTech,
                clienteRagioneSociale,
                proprietaArticolo,
                stagione,
                articolo,
                descArticolo,
                statoArticolo,
                campione,
                codiceComponentiDistinta,
                pageable);
    }

    public DownloadResponse downloadMasterViewByIds(
            List<Integer> idsArticoli,
            String nomeProgetto,
            String senzaProgetto,
            String descProgetto,
            String descScheda,
            String codiceScheda,
            String brand,
            String groupTech,
            String clienteRagioneSociale,
            String proprietaArticolo,
            String stagione,
            String articolo,
            String descArticolo,
            String statoArticolo,
            String campione,
            String codiceComponentiDistinta,
            Pageable pageable) {
        try {
            List<Master> masters = getMasterView(
                    idsArticoli,
                    nomeProgetto,
                    senzaProgetto,
                    descProgetto,
                    descScheda,
                    codiceScheda,
                    brand,
                    groupTech,
                    clienteRagioneSociale,
                    proprietaArticolo,
                    stagione,
                    articolo,
                    descArticolo,
                    statoArticolo,
                    campione,
                    codiceComponentiDistinta,
                    pageable).stream().toList();

            byte[] excelBytes = new MasterExcelExporter().export(masters);


            DownloadResponse d = new DownloadResponse();
            d.setContents(new ByteArrayInputStream(excelBytes));
            d.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            d.setFileName("master_view.xlsx");
            return d;
        } catch (Exception e) {
            logger.error("Errore durante l'esportazione della Master View in Excel", e);
            throw new RuntimeException("Errore durante l'esportazione della Master View in Excel: " + e.getMessage(), e);
        }
    }

    private static List<Integer> normalizeIdsArticoliFilter(List<Integer> idsArticoli) {
        if (idsArticoli == null || idsArticoli.isEmpty()) {
            return Collections.singletonList(-1);
        }
        List<Integer> validIds = idsArticoli.stream()
                .filter(Objects::nonNull)
                .map(Integer::intValue)
                .filter(id -> id > 0)
                .distinct()
                .collect(Collectors.toList());
        return validIds.isEmpty() ? Collections.singletonList(-1) : validIds;
    }

    @Autowired
    ReportsService reportsService;





    public DownloadResponse downloadPdfBomArticolo(Integer idArticolo, HttpServletRequest request,
                                                   HttpServletResponse response) {
        try {
            // 1. Leggi lo ZIP BLOB dal DB
            byte[] reportZipBytes = reportsService
                    .findAll("reportName='BOM'", Pageable.unpaged())
                    .getContent()
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Report 'BOM' non trovato in database"))
                    .getReportZip();



            // 2. Costruisci il JSON da passare al report (adatta alla tua logica)
            String jsonData = JSONUtils.toJSON(getBomArticoloJasperById(idArticolo));

            // 3. Genera il PDF (decompressione ZIP + fill + export sono dentro generateGiglioliPdf)
            byte[] pdfBytes = GigliolicReportService.generateGiglioliPdf(jsonData, reportZipBytes);

            // 4. Ritorna il PDF come DownloadResponse Wavemaker
            DownloadResponse downloadResponse = new DownloadResponse();
            downloadResponse.setContents(new ByteArrayInputStream(pdfBytes));
            downloadResponse.setContentType("application/pdf");
            downloadResponse.setFileName("GIGLIOLI_" + idArticolo + ".pdf");
            return downloadResponse;

        } catch (Exception e) {
            throw new RuntimeException("Errore generazione PDF per articolo " + idArticolo, e);
        }
    }

    public DownloadResponse downloadPdfBomArticoliZip(List<Integer> idArticoli, HttpServletRequest request,
                                                      HttpServletResponse response) {
        try {
            // 1. Leggi lo ZIP BLOB dal DB (una sola volta per tutti gli articoli)
            byte[] reportZipBytes = reportsService
                    .findAll("reportName='BOM'", Pageable.unpaged())
                    .getContent()
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("Report 'BOM' non trovato in database"))
                    .getReportZip();

            // 2. Crea lo ZIP di output contenente tutti i PDF
            ByteArrayOutputStream zipOutputStream = new ByteArrayOutputStream();
            try (ZipOutputStream zos = new ZipOutputStream(zipOutputStream)) {

                for (Integer idArticolo : idArticoli) {
                    try {
                        // 3. Genera il JSON per questo articolo
                        String jsonData = JSONUtils.toJSON(getBomArticoloJasperById(idArticolo));

                        // 4. Genera il PDF
                        byte[] pdfBytes = GigliolicReportService.generateGiglioliPdf(jsonData, reportZipBytes);

                        // 5. Aggiunge il PDF allo ZIP con nome GIGLIOLI_{idArticolo}.pdf
                        ZipEntry zipEntry = new ZipEntry("GIGLIOLI_" + idArticolo + ".pdf");
                        zos.putNextEntry(zipEntry);
                        zos.write(pdfBytes);
                        zos.closeEntry();

                    } catch (Exception e) {
                        // Logga l'errore per questo articolo ma continua con gli altri
                        logger.error("Errore generazione PDF per articolo {}: {}", idArticolo, e.getMessage(), e);
                    }
                }
            }

            // 6. Ritorna lo ZIP come DownloadResponse
            DownloadResponse downloadResponse = new DownloadResponse();
            downloadResponse.setContents(new ByteArrayInputStream(zipOutputStream.toByteArray()));
            downloadResponse.setContentType("application/zip");
            downloadResponse.setFileName("GIGLIOLI_articoli.zip");
            return downloadResponse;

        } catch (Exception e) {
            throw new RuntimeException("Errore generazione ZIP PDF articoli", e);
        }
    }


    public BOMArticolo getBomArticolo(Articoli articolo) {
        String bom = articoliService.findAssociatedBoms(articolo.getId(), Pageable.unpaged()).getContent().getFirst().getBom();
        return JSONUtils.convert(bom, BOMArticolo.class);
    }

    /**
     * Solo diagnostica: JSON della risposta STE01 così com’è mappata su {@link com.oneclickapp.giglioli.ste01.model.RootResponse}
     * (utile per verificare se {@code dati.materiali[*].sottoelementi} arrivano già vuoti dall’API).
     * <p>
     * Usare {@code macar0} come query STE01, oppure {@code idArticolo} (codice = {@code String.valueOf(idArticolo)}).
     */
    public JsonNode getSte01TestResponseJson(String macar0, Integer idArticolo) {
        final String codice;
        if (macar0 != null && !macar0.trim().isEmpty()) {
            codice = macar0.trim();
        } else if (idArticolo != null) {
            codice = String.valueOf(idArticolo);
        } else {
            throw new IllegalArgumentException("Impostare macar0 oppure idArticolo");
        }
        try {
            com.oneclickapp.giglioli.ste01.model.RootResponse root = ste01RestService.invoke(codice);
            ObjectMapper mapper = new ObjectMapper();
            return mapper.valueToTree(root);
        } catch (Exception e) {
            logger.error("Test STE01 fallito per codice={}", codice, e);
            throw new RuntimeException("Errore chiamata STE01 (test): " + codice + " — " + e.getMessage(), e);
        }
    }

    public BOMArticolo getBomArticoloById(Integer idArticolo) {
        if (idArticolo == null) {
            throw new IllegalArgumentException("idArticolo obbligatorio: impossibile caricare o calcolare la distinta senza articolo.");
        }
        Bom bomEntity = null;
        
        try {
            bomEntity = articoliService.findAssociatedBoms(articoliService.getById(idArticolo).getId(), Pageable.unpaged()).getContent().getFirst();
            logger.debug("BOM trovata nel DB per articolo ID: {}", idArticolo);
            logger.debug("BOM JSON dal DB: {}", bomEntity.getBom());
        } catch (Exception e) {
            logger.warn("Nessuna BOM in database per articolo ID: {}", idArticolo, e);
            throw new IllegalStateException(
                    "Nessuna distinta presente in database per l'articolo " + idArticolo + ". Creare o associare la distinta prima di usarla.", e);
        }
        
        // Deserializza il JSON della BOM
        BOMArticolo bomArticolo;
        try {
            ObjectMapper mapper = new ObjectMapper();
            bomArticolo = mapper.readValue(bomEntity.getBom(), BOMArticolo.class);
            
            // Inizializza campi per materiali e lavorazioni esterne (sempre, anche se mancano nel JSON)
            if (bomArticolo.getMateriali() != null) {
                for (Materiali m : bomArticolo.getMateriali()) {
                    m.setTipoC(m.getTipoC()); // Forza la serializzazione del campo
                    m.setConsumo(m.getConsumo()); // Forza la serializzazione del campo
                    m.setCostUnit(m.getCostUnit()); // Forza la serializzazione del campo
            }
            }
            if (bomArticolo.getLavorazioniEsterne() != null) {
                for (LavorazioniEsterne le : bomArticolo.getLavorazioniEsterne()) {
                    le.setTipoC(le.getTipoC()); // Forza la serializzazione del campo
                    le.setCostUnit(le.getCostUnit()); // Forza la serializzazione del campo
                }
            }
        } catch (Exception ex) {
            logger.error("Errore deserializzazione JSON BOM per articolo ID: {}", idArticolo, ex);
            throw new RuntimeException("Impossibile deserializzare il JSON della distinta per articolo ID: " + idArticolo, ex);
        }
        
        // Mappa i campi aggiuntivi dalla tabella bom
        bomArticolo.setStatoPreventivo(bomEntity.getStatoPreventivo());
        bomArticolo.setDataStatoPreventivo(bomEntity.getDataStatoPreventivo() != null ? bomEntity.getDataStatoPreventivo().toString() : null);
        bomArticolo.setEsitoCalcolo(bomEntity.getEsitoCalcolo());
        bomArticolo.setBandierina(bomEntity.getBandierina());
        bomArticolo.setStoricizzato(bomEntity.getStoricizzato());
        bomArticolo.setBloccato(bomEntity.getBloccato());
        bomArticolo.setConsumoCuoioMq(bomEntity.getConsumoCuoioMq());
        bomArticolo.setCostoComponenti(bomEntity.getCostoComponenti());
        bomArticolo.setMinutiLavorazione(bomEntity.getMinutiLavorazione());
        bomArticolo.setManovia(bomEntity.getManovia());
        bomArticolo.setLavorazioniInterneValore(bomEntity.getLavorazioniInterne());
        bomArticolo.setCostoScheda(bomEntity.getCostoScheda());
        bomArticolo.setCostiGenerali(bomEntity.getCostiGenerali());
        bomArticolo.setCostoTotale(bomEntity.getCostoTotale());
        bomArticolo.setPareggioPrezzoLordo(bomEntity.getPareggioPrezzoLordo());
        bomArticolo.setPareggioProvvSconti(bomEntity.getPareggioProvvSconti());
        bomArticolo.setPareggioPrezzoNetto(bomEntity.getPareggioPrezzoNetto());
        bomArticolo.setPareggioMargine(bomEntity.getPareggioMargine());
        bomArticolo.setPareggioMargineContrib(bomEntity.getPareggioMargineContrib());
        bomArticolo.setPareggioMcMinuto(bomEntity.getPareggioMcMinuto());
        bomArticolo.setObiettivoPrezzoLordo(bomEntity.getObiettivoPrezzoLordo());
        bomArticolo.setObiettivoProvvSconti(bomEntity.getObiettivoProvvSconti());
        bomArticolo.setObiettivoPrezzoNetto(bomEntity.getObiettivoPrezzoNetto());
        bomArticolo.setObiettivoMargine(bomEntity.getObiettivoMargine());
        bomArticolo.setObiettivoMargineContrib(bomEntity.getObiettivoMargineContrib());
        bomArticolo.setObiettivoMcMinuto(bomEntity.getObiettivoMcMinuto());
        // Se la colonna DB è null ma il JSON bom.bom contiene già il prezzo proposto, non sovrascrivere con null
        // (altrimenti storicizzazione e confronto storici perdono prezzo_proposto_lordo / chiave nel JSON).
        if (bomEntity.getPropostoPrezzoLordo() != null) {
            bomArticolo.setPropostoPrezzoLordo(bomEntity.getPropostoPrezzoLordo());
        }
        bomArticolo.setPropostoProvvSconti(bomEntity.getPropostoProvvSconti());
        bomArticolo.setPropostoPrezzoNetto(bomEntity.getPropostoPrezzoNetto());
        bomArticolo.setPropostoMargine(bomEntity.getPropostoMargine());
        bomArticolo.setPropostoMargineContrib(bomEntity.getPropostoMargineContrib());
        bomArticolo.setPropostoMcMinuto(bomEntity.getPropostoMcMinuto());
        bomArticolo.setAs400PrezzoLordo(bomEntity.getAs400PrezzoLordo());
        bomArticolo.setAs400ProvvSconti(bomEntity.getAs400ProvvSconti());
        bomArticolo.setAs400PrezzoNetto(bomEntity.getAs400PrezzoNetto());
        bomArticolo.setAs400Margine(bomEntity.getAs400Margine());
        bomArticolo.setAs400MargineContrib(bomEntity.getAs400MargineContrib());
        bomArticolo.setAs400McMinuto(bomEntity.getAs400McMinuto());
        bomArticolo.setDefaultListini(bomEntity.getDefaultListini());
        if (bomEntity.getMatAccessori() != null) {
            bomArticolo.setMatAccessori(bomEntity.getMatAccessori());
        }
        bomArticolo.setCostoMinMop(bomEntity.getCostoMinMop());
        bomArticolo.setCostoMinCge(bomEntity.getCostoMinCge());
        bomArticolo.setProvv(bomEntity.getProvv());
        bomArticolo.setMargineObiett(bomEntity.getMargineObiett());
        if (bomEntity.getScontoPremio() != null) {
            bomArticolo.setScontoPremio(bomEntity.getScontoPremio());
        }

        // Popola i campi stagione e valori di default dai parametri (scope calcolo = stagione riferimento BOM se impostata)
        try {
            com.oneclickapp.giglioli.giglioli_preventivi.Articoli articolo = articoliService.getById(idArticolo);
            String stagioneRifCalcolo = resolveStagioneRiferimentoCalcolo(bomArticolo.getDefaultListini(), articolo);

            Map<String, ParametroInfo> parametriCalcolo = getParametriByScope("calcolo", stagioneRifCalcolo);
            
            ParametroInfo cmopInfo = parametriCalcolo.get("CMOP");
            ParametroInfo cgenInfo = parametriCalcolo.get("CGEN");
            ParametroInfo provInfo = parametriCalcolo.get("PROV");
            ParametroInfo mobbInfo = parametriCalcolo.get("MOBB");
            ParametroInfo scontoPremioInfo = parametriCalcolo.get("SCONTO_PREMIO_DEFAULT");
            
            // Popola le stagioni
            bomArticolo.setCmopStagione(cmopInfo != null ? cmopInfo.getStagione() : "");
            bomArticolo.setCgenStagione(cgenInfo != null ? cgenInfo.getStagione() : "");
            bomArticolo.setProvStagione(provInfo != null ? provInfo.getStagione() : "");
            bomArticolo.setMobbStagione(mobbInfo != null ? mobbInfo.getStagione() : "");
            bomArticolo.setScontoPremioStagione(scontoPremioInfo != null ? scontoPremioInfo.getStagione() : "");
            // Mat. accessori: default da parameters (MACC-{GT}) per stagione di riferimento.
            ParametroInfo maccInfo = resolveMaccByGroupTechAndSeason(articolo.getGrouptech(), stagioneRifCalcolo);
            // Se il valore corrente non combacia con il parametro DB della stagione, considera override manuale ("M").
            String matAccessoriCorrente = bomArticolo.getMatAccessori() != null ? bomArticolo.getMatAccessori().trim() : "";
            String matAccessoriParametro = (maccInfo != null && maccInfo.getValore() != null) ? maccInfo.getValore().trim() : "";
            if (!matAccessoriCorrente.isEmpty() && !matAccessoriParametro.isEmpty()
                    && !sameParametroValue(matAccessoriCorrente, matAccessoriParametro)) {
                bomArticolo.setMatAccessoriStagione("M");
            } else if (bomArticolo.getMatAccessoriStagione() == null || bomArticolo.getMatAccessoriStagione().trim().isEmpty()) {
                // Preserva override manuale già presente nel JSON BOM (M), altrimenti valorizza da parametri.
                bomArticolo.setMatAccessoriStagione(maccInfo != null ? maccInfo.getStagione() : (stagioneRifCalcolo != null ? stagioneRifCalcolo : ""));
            }
            
            // Se i valori nel BOM sono null/vuoti, usa i default dai parametri
            if (bomArticolo.getCostoMinMop() == null || bomArticolo.getCostoMinMop().isEmpty()) {
                bomArticolo.setCostoMinMop(cmopInfo != null ? cmopInfo.getValore() : null);
            }
            if (bomArticolo.getCostoMinCge() == null || bomArticolo.getCostoMinCge().isEmpty()) {
                bomArticolo.setCostoMinCge(cgenInfo != null ? cgenInfo.getValore() : null);
            }
            if (bomArticolo.getProvv() == null || bomArticolo.getProvv().isEmpty()) {
                if (provInfo != null) {
                    Double provVal = parseDoubleOrDefault(provInfo.getValore(), 0.0);
                    bomArticolo.setProvv(String.valueOf(provVal / 100.0));
                }
            }
            if (bomArticolo.getMargineObiett() == null || bomArticolo.getMargineObiett().isEmpty()) {
                if (mobbInfo != null) {
                    Double mobbVal = parseDoubleOrDefault(mobbInfo.getValore(), 0.0);
                    bomArticolo.setMargineObiett(String.valueOf(mobbVal / 100.0));
                }
            }
            if (bomArticolo.getScontoPremio() == null) {
                if (scontoPremioInfo != null) {
                    Double spVal = parseDoubleOrDefault(scontoPremioInfo.getValore(), 0.0);
                    if (spVal > 0.0) {
                        bomArticolo.setScontoPremio(spVal / 100.0);
                    }
                }
            }
            if ((bomArticolo.getMatAccessori() == null || bomArticolo.getMatAccessori().trim().isEmpty()) && maccInfo != null) {
                bomArticolo.setMatAccessori(maccInfo.getValore());
            }
        } catch (Exception e) {
            logger.warn("Impossibile caricare le stagioni dei parametri per articolo ID: {}", idArticolo, e);
            // Non bloccare il caricamento del BOM se fallisce il recupero delle stagioni
        }

        // Fallback dati visuali distinta: derivazione da righe JSON quando i campi tabellari sono vuoti.
        if (bomArticolo.getConsumoCuoioMq() == null) {
            bomArticolo.setConsumoCuoioMq(round3(computeConsumoCuoioMq(bomArticolo.getMateriali())));
        }
        if (bomArticolo.getMinutiLavorazione() == null) {
            bomArticolo.setMinutiLavorazione(round3(sumLavorazioniInterneConsumo(bomArticolo.getLavorazioniInterne())));
        }
        if (bomArticolo.getManovia() == null) {
            bomArticolo.setManovia(round3(sumManoviaConsumo(bomArticolo.getLavorazioniInterne())));
        }
        if (bomArticolo.getLavorazioniInterneValore() == null) {
            Double costoMinMopNum = parseDoubleOrDefault(bomArticolo.getCostoMinMop(), 0.0);
            Double minuti = bomArticolo.getMinutiLavorazione() != null ? bomArticolo.getMinutiLavorazione() : 0.0;
            bomArticolo.setLavorazioniInterneValore(round3(minuti * costoMinMopNum));
        }

        normalizzaFlagAnalizzato(bomArticolo);

        return bomArticolo;
    }

    public Map<String, Object> getBomArticoloJasperById(Integer idArticolo) {
        BOMArticolo bomArticolo = getBomArticoloById(idArticolo);
        Map<String, Object> payload = new LinkedHashMap<>();
        Map<String, Object> bomFlat = new ObjectMapper().convertValue(bomArticolo, Map.class);
        payload.putAll(bomFlat);

        Articoli articolo = articoliService.getById(idArticolo);
        payload.put("articoloDettaglio", articolo);

        String codiceArticolo = articolo != null ? articolo.getArticolo() : null;
        List<com.oneclickapp.giglioli.giglioli_preventivi.RigheAggiuntiveBom> righeAggiuntive = Collections.emptyList();
        if (codiceArticolo != null && !codiceArticolo.trim().isEmpty()) {
            Page<com.oneclickapp.giglioli.giglioli_preventivi.RigheAggiuntiveBom> righeAggiuntivePage =
                    righeAggiuntiveBomService.findAll("articolo='" + codiceArticolo + "'", Pageable.unpaged());
            righeAggiuntive = righeAggiuntivePage != null ? righeAggiuntivePage.getContent() : Collections.emptyList();
        }
        payload.put("righeAggiuntive", righeAggiuntive);

        List<Map<String, Object>> lavorazioniUnificate = new ArrayList<>();
        if (bomArticolo.getLavorazioniInterne() != null) {
            for (LavorazioniInterne li : bomArticolo.getLavorazioniInterne()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("type", "interne");
                row.put("sequenza", li != null ? li.getSequenza() : null);
                row.put("data", li);
                lavorazioniUnificate.add(row);
            }
        }
        if (bomArticolo.getLavorazioniEsterne() != null) {
            for (LavorazioniEsterne le : bomArticolo.getLavorazioniEsterne()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("type", "esterne");
                row.put("sequenza", le != null ? le.getSequenza() : null);
                row.put("data", le);
                lavorazioniUnificate.add(row);
            }
        }

        // TEMP Jasper test: riempie sottoelementi vuoti su LI/LE (rimuovere in produzione).
        //applyTempJasperSottoelementiPatchForTesting(lavorazioniUnificate);

        lavorazioniUnificate.sort(Comparator.comparingInt(r -> parseSequenzaSortValue(r.get("sequenza"))));
        payload.put("lavorazioniUnificate", lavorazioniUnificate);

        return payload;
    }

    /**
     * TEMP solo per test Jasper: su {@code lavorazioniUnificate[*].data} (LI/LE), se {@code sottoelementi}
     * è null o [], imposta una copia del primo elenco non vuoto trovato, altrimenti un default fisso.
     * Non modificare la BOM in DB — solo il payload di {@link #getBomArticoloJasperById(Integer)}.
     */
    private static void applyTempJasperSottoelementiPatchForTesting(List<Map<String, Object>> lavorazioniUnificate) {
        if (lavorazioniUnificate == null || lavorazioniUnificate.isEmpty()) {
            return;
        }
        List<Sottoelementus> template = null;
        for (Map<String, Object> row : lavorazioniUnificate) {
            List<Sottoelementus> se = extractSottoelementiFromLavRow(row.get("data"));
            if (se != null && !se.isEmpty()) {
                template = cloneSottoelementiList(se);
                break;
            }
        }
        if (template == null) {
            template = defaultJasperTestSottoelementi();
        }
        final List<Sottoelementus> fill = template;
        for (Map<String, Object> row : lavorazioniUnificate) {
            Object data = row.get("data");
            if (data instanceof LavorazioniInterne) {
                LavorazioniInterne li = (LavorazioniInterne) data;
                if (isSottoelementiVuoti(li.getSottoelementi())) {
                    li.setSottoelementi(cloneSottoelementiList(fill));
                }
            } else if (data instanceof LavorazioniEsterne) {
                LavorazioniEsterne le = (LavorazioniEsterne) data;
                if (isSottoelementiVuoti(le.getSottoelementi())) {
                    le.setSottoelementi(cloneSottoelementiList(fill));
                }
            }
        }
    }

    private static List<Sottoelementus> extractSottoelementiFromLavRow(Object data) {
        if (data instanceof LavorazioniInterne) {
            return ((LavorazioniInterne) data).getSottoelementi();
        }
        if (data instanceof LavorazioniEsterne) {
            return ((LavorazioniEsterne) data).getSottoelementi();
        }
        return null;
    }

    private static boolean isSottoelementiVuoti(List<Sottoelementus> list) {
        return list == null || list.isEmpty();
    }

    private static List<Sottoelementus> cloneSottoelementiList(List<Sottoelementus> source) {
        if (source == null) {
            return new ArrayList<>();
        }
        List<Sottoelementus> out = new ArrayList<>(source.size());
        for (Sottoelementus s : source) {
            Sottoelementus c = new Sottoelementus();
            if (s != null) {
                c.setDescrizione(s.getDescrizione());
                c.setConsumo(s.getConsumo());
                c.setUnitaMisura(s.getUnitaMisura());
                c.setSottoelCodiceSl(s.getSottoelCodiceSl());
            }
            out.add(c);
        }
        return out;
    }

    private static List<Sottoelementus> defaultJasperTestSottoelementi() {
        List<Sottoelementus> out = new ArrayList<>(2);
        out.add(new Sottoelementus("Jasper TEST fase A", 0.5, "NR", "JST-A"));
        out.add(new Sottoelementus("Jasper TEST fase B", 1.0, "MQ", "JST-B"));
        return out;
    }

    private int parseSequenzaSortValue(Object sequenzaObj) {
        if (sequenzaObj == null) {
            return Integer.MAX_VALUE;
        }
        String sequenza = String.valueOf(sequenzaObj).trim();
        if (sequenza.isEmpty()) {
            return Integer.MAX_VALUE;
        }
        try {
            return Integer.parseInt(sequenza);
        } catch (Exception ignored) {
            return Integer.MAX_VALUE;
        }
    }

    /**
     * Imposta sulla BOM la stagione di riferimento per listini e calcolo ({@code bom.default_listini}),
     * senza modificare la stagione anagrafica dell'articolo ({@code articoli.STAGIONE_*} resta invariata).
     * <p>
     * Logica:
     * - aggiorna solo {@code default_listini} (e JSON BOM) con la nuova stagione scelta
     * - azzera costUnit/tipoC sui soli campi NON manuali (tipoC != 'M')
     * - azzera i parametri calcolo in testata per forzare i default lato calcolo sulla nuova stagione
     * - salva BOM e aggiorna colonne del bom lette da getBomArticoloById/calcolaBom
     *
     * @param idArticolo id dell'articolo
     * @param stagioneAnno anno scelto
     * @param stagioneTipo 'E' oppure 'I'
     * @return BOMArticolo aggiornato per frontend (pronto per CALCOLA)
     */
    public BOMArticolo cambiaStagioneArticolo(Integer idArticolo, Integer stagioneAnno, String stagioneTipo) {
        if (idArticolo == null) {
            throw new IllegalArgumentException("idArticolo è obbligatorio");
        }
        if (stagioneAnno == null || stagioneAnno <= 0) {
            throw new IllegalArgumentException("stagioneAnno non valido");
        }
        if (stagioneTipo == null || stagioneTipo.trim().isEmpty()) {
            throw new IllegalArgumentException("stagioneTipo è obbligatorio (E/I)");
        }

        String stagioneTipoNorm = stagioneTipo.trim().toUpperCase();
        if (!"E".equals(stagioneTipoNorm) && !"I".equals(stagioneTipoNorm)) {
            throw new IllegalArgumentException("stagioneTipo non valido. Atteso: E oppure I");
        }

        String nuovaStagione = String.valueOf(stagioneAnno) + stagioneTipoNorm;

        logger.debug("Imposta stagione riferimento listini sulla BOM (senza toccare anagrafica articolo): idArticolo={} -> defaultListini={}",
                idArticolo, nuovaStagione);

        com.oneclickapp.giglioli.giglioli_preventivi.Articoli articolo = articoliService.getById(idArticolo);
        if (articolo == null) {
            throw new RuntimeException("Articolo non trovato per idArticolo=" + idArticolo);
        }

        java.util.List<Bom> bomsGate = articoliService.findAssociatedBoms(articolo.getId(), Pageable.unpaged()).getContent();
        if (!bomsGate.isEmpty()) {
            Bom bomGate = bomsGate.get(0);
            if (Boolean.TRUE.equals(bomGate.getBloccato())) {
                throw new RuntimeException("Impossibile cambiare stagione: distinta bloccata");
            }
            if ("STORICIZZATO".equals(bomGate.getStatoPreventivo())) {
                throw new RuntimeException("Impossibile cambiare stagione: stato preventivo STORICIZZATO");
            }
        }

        // 1) Non aggiornare articoli.STAGIONE_ANNO / STAGIONE_TIPO: la stagione anagrafica resta quella di sistema.

        // 2) Carica BOM corrente e resetta campi dipendenti dalla stagione (NON manuali)
        BOMArticolo bomArticolo = getBomArticoloById(idArticolo);

        if (bomArticolo.getMateriali() != null) {
            for (Materiali m : bomArticolo.getMateriali()) {
                if (!"M".equals(m.getTipoC())) {
                    m.setCostUnit(0.0d);
                    m.setTipoC(null);
                }
            }
        }

        if (bomArticolo.getLavorazioniEsterne() != null) {
            for (LavorazioniEsterne le : bomArticolo.getLavorazioniEsterne()) {
                if (!"M".equals(le.getTipoC())) {
                    le.setCostUnit(0.0d);
                    le.setTipoC(null);
                }
            }
        }

        // 3) Reset testata calcolo (così calcolaBom usa i default sulla nuova stagione)
        bomArticolo.setCostoScheda(0.0d);
        bomArticolo.setCostiGenerali(0.0d);
        bomArticolo.setCostoTotale(0.0d);
        bomArticolo.setMinutiLavorazione(0.0d);
        bomArticolo.setCostoComponenti(0.0d);

        bomArticolo.setCostoMinMop("");
        bomArticolo.setCostoMinCge("");

        bomArticolo.setProvv("");
        bomArticolo.setMargineObiett(null);
        bomArticolo.setScontoPremio(null);

        bomArticolo.setEsitoCalcolo("DA CALCOLARE");
        bomArticolo.setBandierina(null);
        bomArticolo.setDefaultListini(nuovaStagione);

        // 4) Salva BOM nel DB (reset/override manuali già gestiti nel BOM JSON)
        // Nota: salvaBomNelDB può mettere in coda aggiornamenti AS400 se propostoPrezzoLordo è non-null.
        // In un cambio stagione non vogliamo triggerare quell'integrazione.
        bomArticolo.setPropostoPrezzoLordo(null);
        bomArticolo.setAs400PrezzoLordo(null);

        Bom bomEntity = articoliService.findAssociatedBoms(
            articolo.getId(),
            Pageable.unpaged()
        ).getContent().getFirst();

        String statoPreventivo = bomEntity != null ? bomEntity.getStatoPreventivo() : "IN CORSO";
        try {
            salvaBomNelDB(bomArticolo, idArticolo, statoPreventivo);
        } catch (Exception e) {
            logger.error("Errore durante salva BOM dopo cambio stagione. idArticolo={}", idArticolo, e);
            // Non bloccare il ritorno: torniamo comunque il BOM in stato coerente lato UI
        }

        // 5) Aggiorna anche le colonne del BOM lette da getBomArticoloById/calcolaBom
        //    (salvaBomNelDB aggiorna il JSON ma NON queste colonne)
        Bom bomEntityAfter = articoliService.findAssociatedBoms(
            articoliService.getById(idArticolo).getId(),
            Pageable.unpaged()
        ).getContent().getFirst();

        if (bomEntityAfter != null) {
            bomEntityAfter.setDefaultListini(nuovaStagione);
            bomEntityAfter.setCostoMinMop(null);
            bomEntityAfter.setCostoMinCge(null);
            bomEntityAfter.setProvv(null);
            bomEntityAfter.setMargineObiett(null);
            bomEntityAfter.setScontoPremio(null);
            bomEntityAfter.setCostoComponenti(0.0d);
            bomEntityAfter.setBandierina(null);

            // Lasciare i prezzi proposti/AS400 coerenti col fatto che serve un nuovo CALCOLA
            // (evita che la UI passi un override "vecchio" quando si preme CALCOLA).
            bomEntityAfter.setPropostoPrezzoLordo(null);
            bomEntityAfter.setPropostoProvvSconti(null);
            bomEntityAfter.setPropostoPrezzoNetto(null);
            bomEntityAfter.setPropostoMargine(null);
            bomEntityAfter.setPropostoMargineContrib(null);
            bomEntityAfter.setPropostoMcMinuto(null);

            bomEntityAfter.setAs400PrezzoLordo(null);
            bomEntityAfter.setAs400ProvvSconti(null);
            bomEntityAfter.setAs400PrezzoNetto(null);
            bomEntityAfter.setAs400Margine(null);
            bomEntityAfter.setAs400MargineContrib(null);
            bomEntityAfter.setAs400McMinuto(null);

            bomService.update(bomEntityAfter);
        }

        // 6) Ricarica BOM (default_listini aggiornato; parametri/listini da stagione riferimento BOM)
        return getBomArticoloById(idArticolo);
    }

    private static String chiaveMateriale(Materiali m) {
        if (m == null) {
            return "";
        }
        String el = m.getElemento() != null ? m.getElemento() : "";
        String fc = m.getFornitoreTerzistaCodice() != null ? m.getFornitoreTerzistaCodice() : "";
        return el + "\u0001" + fc;
    }

    private static String fingerprintMateriale(Materiali m) {
        if (m == null) {
            return "";
        }
        String tipo = m.getTipoC() != null ? m.getTipoC() : "";
        String cons = m.getConsumo() != null ? m.getConsumo().toString() : "null";
        return tipo + "|" + m.getCostUnit() + "|" + cons;
    }

    private static Map<String, String> snapshotFingerprintsMateriali(List<Materiali> list) {
        Map<String, String> map = new HashMap<>();
        if (list == null) {
            return map;
        }
        for (Materiali m : list) {
            map.put(chiaveMateriale(m), fingerprintMateriale(m));
        }
        return map;
    }

    private static void aggiornaAnalizzatoDopoCalcoloMateriali(List<Materiali> righe, Map<String, String> snapPreCalcolo) {
        if (righe == null) {
            return;
        }
        for (Materiali m : righe) {
            String k = chiaveMateriale(m);
            String prima = snapPreCalcolo.get(k);
            String dopo = fingerprintMateriale(m);
            boolean cambiata = prima == null || !prima.equals(dopo);
            if (cambiata) {
                m.setAnalizzato(Boolean.FALSE);
            } else if (m.getAnalizzato() == null) {
                m.setAnalizzato(Boolean.FALSE);
            }
        }
    }

    private static String chiaveLavEst(LavorazioniEsterne l) {
        if (l == null) {
            return "";
        }
        String el = l.getElemento() != null ? l.getElemento() : "";
        String fc = l.getFornitoreTerzistaCodice() != null ? l.getFornitoreTerzistaCodice() : "";
        return el + "\u0001" + fc;
    }

    private static String fingerprintLavEst(LavorazioniEsterne l) {
        if (l == null) {
            return "";
        }
        String tipo = l.getTipoC() != null ? l.getTipoC() : "";
        String cons = l.getConsUnit() != null ? l.getConsUnit().toString() : "null";
        return tipo + "|" + l.getCostUnit() + "|" + cons;
    }

    private static Map<String, String> snapshotFingerprintsLavEst(List<LavorazioniEsterne> list) {
        Map<String, String> map = new HashMap<>();
        if (list == null) {
            return map;
        }
        for (LavorazioniEsterne l : list) {
            map.put(chiaveLavEst(l), fingerprintLavEst(l));
        }
        return map;
    }

    private static void aggiornaAnalizzatoDopoCalcoloLavEst(List<LavorazioniEsterne> righe, Map<String, String> snapPreCalcolo) {
        if (righe == null) {
            return;
        }
        for (LavorazioniEsterne l : righe) {
            String k = chiaveLavEst(l);
            String prima = snapPreCalcolo.get(k);
            String dopo = fingerprintLavEst(l);
            boolean cambiata = prima == null || !prima.equals(dopo);
            if (cambiata) {
                l.setAnalizzato(Boolean.FALSE);
            } else if (l.getAnalizzato() == null) {
                l.setAnalizzato(Boolean.FALSE);
            }
        }
    }

    private void normalizzaFlagAnalizzato(BOMArticolo bom) {
        if (bom == null) {
            return;
        }
        if (bom.getMateriali() != null) {
            for (Materiali m : bom.getMateriali()) {
                if (m.getAnalizzato() == null) {
                    m.setAnalizzato(Boolean.FALSE);
                }
            }
        }
        if (bom.getLavorazioniEsterne() != null) {
            for (LavorazioniEsterne l : bom.getLavorazioniEsterne()) {
                if (l.getAnalizzato() == null) {
                    l.setAnalizzato(Boolean.FALSE);
                }
            }
        }
        if (bom.getLavorazioniInterne() != null) {
            for (LavorazioniInterne li : bom.getLavorazioniInterne()) {
                if (li.getAnalizzato() == null) {
                    li.setAnalizzato(Boolean.FALSE);
                }
            }
        }
    }

    private static String jsonFieldAsText(JsonNode row, String field) {
        if (row == null || !row.has(field) || row.get(field).isNull()) {
            return "";
        }
        return row.get(field).asText("");
    }

    /** Codice fornitore da riga JSON client (camelCase o snake_case come in WM). */
    private static String jsonFieldFornitoreCodiceClient(JsonNode row) {
        String v = jsonFieldAsText(row, "fornitoreTerzistaCodice");
        if (v.isEmpty()) {
            v = jsonFieldAsText(row, "fornitore_terzista_codice");
        }
        return v.trim();
    }

    /** Chiave merge stabile per {@code elemento}: trim, NBSP, maiuscole (ASCII). */
    private static String normalizeElementoMergeKey(String elemento) {
        if (elemento == null) {
            return "";
        }
        String s = elemento.replace('\u00a0', ' ').trim();
        return s.toUpperCase(Locale.ROOT);
    }

    private static String jsonElementoClient(JsonNode row) {
        return normalizeElementoMergeKey(jsonFieldAsText(row, "elemento"));
    }

    /** Allinea chiavi merge quando DB ha "123" e il client "123.0". */
    private static String normalizeFornitoreMergeKey(String raw) {
        if (raw == null) {
            return "";
        }
        String s = raw.trim();
        if (s.matches("^\\d+\\.0+$")) {
            return s.substring(0, s.indexOf('.'));
        }
        return s;
    }

    private static String mergeKeyMateriale(String elemento, String fornitoreCodice) {
        String el = normalizeElementoMergeKey(elemento);
        String fc = normalizeFornitoreMergeKey(fornitoreCodice != null ? fornitoreCodice : "");
        return el + "\u0001" + fc;
    }

    private static String mergeKeyFromMateriale(Materiali m) {
        if (m == null) {
            return "\u0001";
        }
        return mergeKeyMateriale(m.getElemento(), m.getFornitoreTerzistaCodice());
    }

    private static String mergeKeyFromLavEst(LavorazioniEsterne l) {
        if (l == null) {
            return "\u0001";
        }
        return mergeKeyMateriale(l.getElemento(), l.getFornitoreTerzistaCodice());
    }

    /** Chiave merge lav. interne: sequenza + elemento + codice SL (univoco riga in distinta). */
    private static String mergeKeyLavInt(String sequenza, String elemento, String codiceSl) {
        String seq = sequenza != null ? sequenza.trim() : "";
        String el = normalizeElementoMergeKey(elemento);
        String cs = codiceSl != null ? codiceSl.replace('\u00a0', ' ').trim().toUpperCase(Locale.ROOT) : "";
        return seq + "\u0001" + el + "\u0001" + cs;
    }

    private static String mergeKeyFromLavInt(LavorazioniInterne li) {
        if (li == null) {
            return "\u0001\u0001";
        }
        return mergeKeyLavInt(li.getSequenza(), li.getElemento(), li.getCodiceSl());
    }

    private static String jsonSequenzaClient(JsonNode row) {
        if (row == null || !row.has("sequenza") || row.get("sequenza").isNull()) {
            return "";
        }
        JsonNode n = row.get("sequenza");
        if (n.isNumber()) {
            return n.asText().trim();
        }
        return n.asText("").trim();
    }

    private static String jsonCodiceSlClient(JsonNode row) {
        String v = jsonFieldAsText(row, "codiceSl");
        if (v.isEmpty()) {
            v = jsonFieldAsText(row, "codice_sl");
        }
        return v.replace('\u00a0', ' ').trim().toUpperCase(Locale.ROOT);
    }

    /** Accetta boolean, numero, stringa ("true"/"1"/"S") come da alcuni client JS. */
    private static Boolean readAnalizzatoLoose(JsonNode row) {
        if (row == null || !row.has("analizzato") || row.get("analizzato").isNull()) {
            return null;
        }
        JsonNode n = row.get("analizzato");
        if (n.isBoolean()) {
            return n.booleanValue();
        }
        if (n.isNumber()) {
            return n.intValue() != 0;
        }
        if (n.isTextual()) {
            String s = n.asText("").trim().toLowerCase(Locale.ROOT);
            if ("true".equals(s) || "1".equals(s) || "yes".equals(s) || "s".equals(s)) {
                return Boolean.TRUE;
            }
            if ("false".equals(s) || "0".equals(s) || "no".equals(s) || "n".equals(s)) {
                return Boolean.FALSE;
            }
        }
        return null;
    }

    /** Legge un numero opzionale dal JSON client (camelCase o snake_case). */
    private static Double readOptionalClientDouble(JsonNode root, String... fieldNames) {
        if (root == null || root.isNull()) {
            return null;
        }
        for (String name : fieldNames) {
            if (!root.has(name) || root.get(name).isNull()) {
                continue;
            }
            JsonNode n = root.get(name);
            if (n.isNumber()) {
                return n.doubleValue();
            }
            if (n.isTextual()) {
                String s = n.asText("").trim().replace(',', '.');
                if (s.isEmpty()) {
                    continue;
                }
                try {
                    return Double.parseDouble(s);
                } catch (NumberFormatException ignored) {
                    // prova il prossimo alias
                }
            }
        }
        return null;
    }

    /**
     * Allinea il prezzo lordo proposto dalla maschera BOM: il JSON su tabella {@code bom} può non essere
     * aggiornato prima della storicizzazione; serve per {@code bom_history.prezzo_proposto_lordo} e per il JSON storico.
     */
    private static void mergePropostoPrezzoLordoFromClientJson(BOMArticolo server, JsonNode clientRoot) {
        if (server == null || clientRoot == null || clientRoot.isNull()) {
            return;
        }
        boolean hasCamel = clientRoot.has("propostoPrezzoLordo");
        boolean hasSnake = clientRoot.has("proposto_prezzo_lordo");
        if (!hasCamel && !hasSnake) {
            return;
        }
        JsonNode primary = hasCamel ? clientRoot.get("propostoPrezzoLordo") : clientRoot.get("proposto_prezzo_lordo");
        if (primary != null && primary.isNull()) {
            server.setPropostoPrezzoLordo(null);
            return;
        }
        Double pp = readOptionalClientDouble(clientRoot, "propostoPrezzoLordo", "proposto_prezzo_lordo");
        if (pp != null) {
            server.setPropostoPrezzoLordo(pp);
        }
    }

    /**
     * Applica sul BOM server i soli flag {@code analizzato} dal JSON client (chiave elemento+fornitore,
     * con fallback per solo elemento se il client non invia il codice fornitore).
     */
    private void mergeAnalizzatoFlagsFromClientJson(BOMArticolo server, JsonNode clientRoot) {
        if (clientRoot == null || clientRoot.isNull()) {
            return;
        }
        if (server.getMateriali() != null && clientRoot.has("materiali") && clientRoot.get("materiali").isArray()) {
            Map<String, Boolean> byKey = new HashMap<>();
            Map<String, Boolean> byElementoSolo = new HashMap<>();
            for (JsonNode c : clientRoot.get("materiali")) {
                Boolean a = readAnalizzatoLoose(c);
                if (a == null) {
                    continue;
                }
                String el = jsonElementoClient(c);
                String fc = jsonFieldFornitoreCodiceClient(c);
                byKey.put(mergeKeyMateriale(el, fc), a);
                if (fc.isEmpty() && !el.isEmpty()) {
                    byElementoSolo.put(el, a);
                }
            }
            for (Materiali m : server.getMateriali()) {
                Boolean f = byKey.get(mergeKeyFromMateriale(m));
                if (f == null && m.getElemento() != null) {
                    f = byElementoSolo.get(normalizeElementoMergeKey(m.getElemento()));
                }
                if (f != null) {
                    m.setAnalizzato(f);
                }
            }
        }
        if (server.getLavorazioniEsterne() != null && clientRoot.has("lavorazioniEsterne")
                && clientRoot.get("lavorazioniEsterne").isArray()) {
            Map<String, Boolean> byKeyLe = new HashMap<>();
            Map<String, Boolean> byElementoLavSolo = new HashMap<>();
            for (JsonNode c : clientRoot.get("lavorazioniEsterne")) {
                Boolean a = readAnalizzatoLoose(c);
                if (a == null) {
                    continue;
                }
                String el = jsonElementoClient(c);
                String fc = jsonFieldFornitoreCodiceClient(c);
                byKeyLe.put(mergeKeyMateriale(el, fc), a);
                if (fc.isEmpty() && !el.isEmpty()) {
                    byElementoLavSolo.put(el, a);
                }
            }
            for (LavorazioniEsterne l : server.getLavorazioniEsterne()) {
                Boolean f = byKeyLe.get(mergeKeyFromLavEst(l));
                if (f == null && l.getElemento() != null) {
                    f = byElementoLavSolo.get(normalizeElementoMergeKey(l.getElemento()));
                }
                if (f != null) {
                    l.setAnalizzato(f);
                }
            }
        }
        if (server.getLavorazioniInterne() != null && clientRoot.has("lavorazioniInterne")
                && clientRoot.get("lavorazioniInterne").isArray()) {
            Map<String, Boolean> byKeyLi = new HashMap<>();
            Map<String, Boolean> byElementoLiSolo = new HashMap<>();
            for (JsonNode c : clientRoot.get("lavorazioniInterne")) {
                Boolean a = readAnalizzatoLoose(c);
                if (a == null) {
                    continue;
                }
                String seq = jsonSequenzaClient(c);
                String el = jsonElementoClient(c);
                String cs = jsonCodiceSlClient(c);
                byKeyLi.put(mergeKeyLavInt(seq, el, cs), a);
                if (seq.isEmpty() && cs.isEmpty() && !el.isEmpty()) {
                    byElementoLiSolo.put(el, a);
                }
            }
            for (LavorazioniInterne li : server.getLavorazioniInterne()) {
                Boolean f = byKeyLi.get(mergeKeyFromLavInt(li));
                if (f == null && li.getElemento() != null) {
                    f = byElementoLiSolo.get(normalizeElementoMergeKey(li.getElemento()));
                }
                if (f != null) {
                    li.setAnalizzato(f);
                }
            }
        }
    }

    private void assertDistintaAnalizzataPerStoricizzazione(BOMArticolo bom) {
        normalizzaFlagAnalizzato(bom);
        List<String> mancanti = new ArrayList<>();
        if (bom.getMateriali() != null) {
            for (Materiali m : bom.getMateriali()) {
                if (!Boolean.TRUE.equals(m.getAnalizzato())) {
                    mancanti.add("materiale " + (m.getElemento() != null ? m.getElemento() : "?"));
                }
            }
        }
        if (bom.getLavorazioniEsterne() != null) {
            for (LavorazioniEsterne l : bom.getLavorazioniEsterne()) {
                if (!Boolean.TRUE.equals(l.getAnalizzato())) {
                    mancanti.add("lav.esterna " + (l.getElemento() != null ? l.getElemento() : "?"));
                }
            }
        }
        if (!mancanti.isEmpty()) {
            int max = Math.min(10, mancanti.size());
            throw new IllegalStateException(
                    "VALIDAZIONE DISTINTA INCOMPLETA: spuntare \"Analisi OK\" su ogni riga materiali e lavorazioni esterne prima di storicizzare. "
                            + "Righe non validate: " + String.join(", ", mancanti.subList(0, max))
                            + (mancanti.size() > max ? "..." : ""));
        }
    }

    /**
     * Metodo per calcolare tutti i prezzi della BOM (pareggio, obiettivo, proposto, AS400).
     * Può essere invocato sia dalla pagina "bom" (calcolo preventivo con dati manuali) 
     * che dalla pagina "master" (calcolo persistente con dati dal DB).
     * 
     * @param idArticolo ID dell'articolo (obbligatorio)
     * @param materialiOverride Lista materiali per calcolo preventivo (nullable)
     * @param lavorazioniInterneOverride Lista lavorazioni interne per calcolo preventivo (nullable)
     * @param lavorazioniEsterneOverride Lista lavorazioni esterne per calcolo preventivo (nullable)
     * @param provvOverride Percentuale provvigioni per calcolo preventivo (nullable)
     * @param scontoPremioOverride Percentuale sconto premio per calcolo preventivo (nullable)
     * @param margineObiettOverride Percentuale margine obiettivo per calcolo preventivo (nullable)
     * @param costoMinMopOverride Costo minuto manodopera per calcolo preventivo (nullable)
     * @param costoMinCgeOverride Costo minuto costi generali per calcolo preventivo (nullable)
     * @param propostoPrezzoLordoOverride Prezzo proposto lordo per calcolo preventivo (nullable)
     * @param as400PrezzoLordoOverride Prezzo AS400 lordo per calcolo preventivo (nullable)
     * @return BOMArticolo con tutti i campi calcolati
     */
    public BOMArticolo calcolaBom(
            Integer idArticolo,
            @org.springframework.lang.Nullable List<Materiali> materialiOverride,
            @org.springframework.lang.Nullable List<LavorazioniInterne> lavorazioniInterneOverride,
            @org.springframework.lang.Nullable List<LavorazioniEsterne> lavorazioniEsterneOverride,
            @org.springframework.lang.Nullable String matAccessoriOverride,
            @org.springframework.lang.Nullable Double provvOverride,
            @org.springframework.lang.Nullable Double scontoPremioOverride,
            @org.springframework.lang.Nullable Double margineObiettOverride,
            @org.springframework.lang.Nullable Double costoMinMopOverride,
            @org.springframework.lang.Nullable Double costoMinCgeOverride,
            @org.springframework.lang.Nullable Double propostoPrezzoLordoOverride,
            @org.springframework.lang.Nullable Double as400PrezzoLordoOverride
    ) {
        if (idArticolo == null) {
            throw new IllegalArgumentException("idArticolo obbligatorio per calcolaBom.");
        }
        logger.debug("Inizio calcolo BOM per articolo ID: {}", idArticolo);
        
        // 1. RECUPERO BOM ESISTENTE
        BOMArticolo bom = getBomArticoloById(idArticolo);
        // Tratta liste vuote come null
        if (materialiOverride != null && materialiOverride.isEmpty()) materialiOverride = null;
        if (lavorazioniInterneOverride != null && lavorazioniInterneOverride.isEmpty()) lavorazioniInterneOverride = null;
        if (lavorazioniEsterneOverride != null && lavorazioniEsterneOverride.isEmpty()) lavorazioniEsterneOverride = null;
        // NOTA: calcolaBom ora salva SEMPRE nel DB, con o senza override
        
        // 2. USA OVERRIDE O VALORI DAL DB
        List<Materiali> materiali = materialiOverride != null ? materialiOverride : bom.getMateriali();
        List<LavorazioniInterne> lavInt = lavorazioniInterneOverride != null ? lavorazioniInterneOverride : bom.getLavorazioniInterne();
        List<LavorazioniEsterne> lavEst = lavorazioniEsterneOverride != null ? lavorazioniEsterneOverride : bom.getLavorazioniEsterne();
        if (matAccessoriOverride != null) {
            String macc = matAccessoriOverride.trim();
            bom.setMatAccessori(macc);
            if (!macc.isEmpty()) {
                bom.setMatAccessoriStagione("M");
            }
        }
        
        // CRITICO: imposta subito le liste nel BOM di ritorno, così vengono restituite
        // anche in caso di errore di validazione (il return anticipato non perde i valori manuali)
        bom.setMateriali(materiali);
        bom.setLavorazioniInterne(lavInt);
        bom.setLavorazioniEsterne(lavEst);
        
        // AUTO-POPOLAMENTO LISTINI MANCANTI
        // Stagione listini: default_listini BOM se valorizzato, altrimenti anagrafica articolo
        com.oneclickapp.giglioli.giglioli_preventivi.Articoli articoloPerListini = articoliService.getById(idArticolo);
        String codiceArticoloPerListini = articoloPerListini.getArticolo();
        String stagionePerListini = resolveStagioneRiferimentoCalcolo(bom.getDefaultListini(), articoloPerListini);

        // Snapshot righe (tipoC/costo/consumo) prima di listino auto + calcolo: se cambiano, si azzera il flag "analizzato" (requisito analisi)
        Map<String, String> snapMatPreCalcolo = snapshotFingerprintsMateriali(materiali);
        Map<String, String> snapLavEstPreCalcolo = snapshotFingerprintsLavEst(lavEst);

        // Popola listini mancanti (solo se costUnit = 0 e tipoC != 'M')
        popolaListiniMancanti(bom, codiceArticoloPerListini, stagionePerListini);
        
        // Carica righe aggiuntive dal DB (sempre)
        List<com.oneclickapp.giglioli.giglioli_preventivi.RigheAggiuntiveBom> righeAggiuntive = null;
        {
            try {
                com.oneclickapp.giglioli.giglioli_preventivi.Articoli articolo = articoliService.getById(idArticolo);
                String codiceArticolo = articolo.getArticolo();
                // Carica righe aggiuntive filtrate per articolo
                org.springframework.data.domain.Page<com.oneclickapp.giglioli.giglioli_preventivi.RigheAggiuntiveBom> righeAggiuntivePage = 
                    righeAggiuntiveBomService.findAll("articolo='" + codiceArticolo + "'", org.springframework.data.domain.Pageable.unpaged());
                righeAggiuntive = righeAggiuntivePage.getContent();
                logger.debug("Caricate {} righe aggiuntive per articolo {}", righeAggiuntive.size(), codiceArticolo);
            } catch (Exception e) {
                logger.error("Errore caricamento righe aggiuntive per articolo ID: {}", idArticolo, e);
                righeAggiuntive = new java.util.ArrayList<>();
            }
        }
        
        // Parsing parametri (String -> Double)
        Double provv = provvOverride != null ? provvOverride : parseDoubleOrDefault(bom.getProvv(), 0.0);
        Double scontoPremioRaw = scontoPremioOverride != null ? scontoPremioOverride : (bom.getScontoPremio() != null ? bom.getScontoPremio() : 0.0);
        // Input utente spesso espresso in percentuale intera (es. "1" = 1%): normalizza in frazione decimale SOLO per i calcoli.
        Double scontoPremio = normalizePercentFraction(scontoPremioRaw);
        Double margineObiett = margineObiettOverride != null ? margineObiettOverride : parseDoubleOrDefault(bom.getMargineObiett(), 0.0);
        Double costoMinMop = costoMinMopOverride != null ? costoMinMopOverride : parseDoubleOrDefault(bom.getCostoMinMop(), 0.0);
        Double costoMinCge = costoMinCgeOverride != null ? costoMinCgeOverride : parseDoubleOrDefault(bom.getCostoMinCge(), 0.0);
        // Proposto persistito sulla BOM *prima* di applicare l'override (serve per agganciare AS400 al vecchio proposto)
        Double propostoPersistitoBom = bom.getPropostoPrezzoLordo();
        Double propostoPrezzoLordo = propostoPrezzoLordoOverride != null ? propostoPrezzoLordoOverride : bom.getPropostoPrezzoLordo();
        Double as400PrezzoLordo = as400PrezzoLordoOverride != null ? as400PrezzoLordoOverride : bom.getAs400PrezzoLordo();
        // Nuovo proposto da UI: la colonna AS400 lordo (confronto) diventa il proposto che era già salvato sulla BOM,
        // così i margini AS400 si ricalcolano sul prezzo "precedente" e non restano sul valore ERP/eventuale 30.12 fermo.
        // Non si applica se c'è override esplicito del lordo AS400 o se il proposto in BOM era assente/uguale al nuovo.
        if (as400PrezzoLordoOverride == null
                && propostoPrezzoLordoOverride != null
                && propostoPersistitoBom != null
                && propostoPersistitoBom > 0
                && !java.util.Objects.equals(propostoPersistitoBom, propostoPrezzoLordoOverride)) {
            as400PrezzoLordo = propostoPersistitoBom;
            logger.debug("AS400 lordo agganciato al proposto precedentemente salvato in BOM ({}) per confronto col nuovo proposto={}",
                    propostoPersistitoBom, propostoPrezzoLordoOverride);
        }
        
        // Stagione per parametri calcolo: come per i listini (default_listini BOM o anagrafica)
        com.oneclickapp.giglioli.giglioli_preventivi.Articoli articolo = articoliService.getById(idArticolo);
        String stagioneRifCalcolo = resolveStagioneRiferimentoCalcolo(bom.getDefaultListini(), articolo);

        // Recupera parametri di sistema dallo scope 'calcolo' filtrati per stagione
        Map<String, ParametroInfo> parametriCalcolo = getParametriByScope("calcolo", stagioneRifCalcolo);
        
        // Se costoMinMop o costoMinCge sono 0, recuperarli dalla tabella parameters
        if (costoMinMop == 0.0) {
            ParametroInfo cmop = parametriCalcolo.get("CMOP");
            if (cmop != null) {
                costoMinMop = parseDoubleOrDefault(cmop.getValore(), 0.0);
                logger.debug("costoMinMop da parametri di sistema (CMOP): {}", costoMinMop);
            }
        }
        if (costoMinCge == 0.0) {
            ParametroInfo cgen = parametriCalcolo.get("CGEN");
            if (cgen != null) {
                costoMinCge = parseDoubleOrDefault(cgen.getValore(), 0.0);
                logger.debug("costoMinCge da parametri di sistema (CGEN): {}", costoMinCge);
            }
        }
        // Se provv non è settata nel BOM, usa il default da parametri
        if (provv == 0.0 && provvOverride == null) {
            ParametroInfo prov = parametriCalcolo.get("PROV");
            if (prov != null) {
                Double provvDefault = parseDoubleOrDefault(prov.getValore(), 0.0);
                if (provvDefault > 0.0) {
                    provv = provvDefault / 100.0; // Converti da percentuale a decimale
                    logger.debug("provv da parametri di sistema (PROV): {}", provv);
                }
            }
        }
        // Se scontoPremio non è settato nel BOM, usa il default da parametri (stessa convenzione di PROV/MOBB: valore intero = percentuale, es. 65 → 0.65)
        if (scontoPremio == 0.0 && scontoPremioOverride == null) {
            ParametroInfo scontoPremioParam = parametriCalcolo.get("SCONTO_PREMIO_DEFAULT");
            if (scontoPremioParam != null) {
                Double scontoPremioDefault = parseDoubleOrDefault(scontoPremioParam.getValore(), 0.0);
                if (scontoPremioDefault > 0.0) {
                    scontoPremioRaw = scontoPremioDefault;
                    scontoPremio = normalizePercentFraction(scontoPremioRaw);
                    logger.debug("scontoPremio da parametri di sistema (SCONTO_PREMIO_DEFAULT): {}% → {}", scontoPremioDefault, scontoPremio);
                }
            }
        }
        // Se margineObiett non è settato nel BOM, usa il default da parametri
        if (margineObiett == 0.0 && margineObiettOverride == null) {
            ParametroInfo mobb = parametriCalcolo.get("MOBB");
            if (mobb != null) {
                Double margineObiettDefault = parseDoubleOrDefault(mobb.getValore(), 0.0);
                if (margineObiettDefault > 0.0) {
                    margineObiett = margineObiettDefault / 100.0; // Converti da percentuale a decimale
                    logger.debug("margineObiett da parametri di sistema (MOBB): {}", margineObiett);
                }
            }
        }
        
        bom.setBandierina(null);
        List<String> erroriCalcolo = new java.util.ArrayList<>();
        if (stagioneRifCalcolo != null && !stagioneRifCalcolo.isBlank()) {
            String[] requiredCalcoloKeys = {"CMOP", "CGEN", "PROV", "MOBB"};
            List<String> missingCalcolo = new java.util.ArrayList<>();
            for (String key : requiredCalcoloKeys) {
                if (!parametriCalcolo.containsKey(key)) {
                    missingCalcolo.add(key);
                }
            }
            if (!missingCalcolo.isEmpty()) {
                erroriCalcolo.add(
                        "PARAMETRI DI CALCOLO MANCANTI PER STAGIONE " + stagioneRifCalcolo + ": "
                                + String.join(", ", missingCalcolo)
                                + ". Configurare in parameters (scope calcolo) tutte le chiavi per quella stagione.");
            }
        }
        
        logger.debug("Valori pre-validazione: provv={}, margineObiett={}, scontoPremio={}, costoMinMop={}, costoMinCge={}", provv, margineObiett, scontoPremio, costoMinMop, costoMinCge);
        
        // VALIDAZIONE PRE-CALCOLO: raccoglie errori specifici per esitoCalcolo (erroriCalcolo già inizializzata sopra)
        
        // Validazione parametri
        if (provv < 0 || provv >= 1) {
            erroriCalcolo.add("PROVVIGIONI NON VALIDE");
        }
        if (scontoPremio < 0 || scontoPremio >= 1) {
            erroriCalcolo.add("SCONTO PREMIO NON VALIDO");
        }
        if (margineObiett < 0 || margineObiett >= 1) {
            erroriCalcolo.add("MARGINE OBIETTIVO NON VALIDO");
        }
        if (provv >= 0 && provv < 1 && scontoPremio >= 0 && scontoPremio < 1) {
            double sommaProvvScontoPremio = provv + scontoPremio;
            if (sommaProvvScontoPremio > MAX_SOMMA_PROVV_SCONTO_PREMIO) {
                erroriCalcolo.add(
                    "PROVV + SCONTO PREMIO TROPPO ALTI (max combinato ~97%: controllare PROV e SCONTO_PREMIO_DEFAULT nello scope calcolo o in testata distinta)");
            }
        }
        
        // Validazione materiali: verifica che abbiano prezzo (listino) e consumo
        // Accetta valori manuali (tipoC = 'M') con costUnit > 0 anche senza listino
        if (materiali != null && !materiali.isEmpty()) {
            boolean materialiSenzaPrezzo = false;
            boolean materialiSenzaConsumo = false;
            for (Materiali m : materiali) {
                // Se tipoC = 'M' (manuale) e costUnit > 0, OK anche senza listino
                boolean isManuale = "M".equals(m.getTipoC());
                boolean hasCostUnit = m.getCostUnit() > 0;
                
                if (!hasCostUnit) {
                    // costUnit <= 0: errore sempre (anche se manuale)
                    materialiSenzaPrezzo = true;
                    if (isManuale) {
                        logger.warn("Materiale {} con tipoC='M' ma costUnit <= 0", m.getElemento());
                    }
                }
                // Se costUnit > 0 e tipoC='M', OK (non aggiungere errore)
                
                if (m.getConsumo() == null || m.getConsumo() < 0) {
                    materialiSenzaConsumo = true;
                }
            }
            if (materialiSenzaPrezzo) {
                erroriCalcolo.add("VERIFICA LISTINO ASSOCIATO AI COMPONENTI");
            }
            if (materialiSenzaConsumo) {
                erroriCalcolo.add("VERIFICA CONSUMI ASSOCIATI AI COMPONENTI");
            }
        }
        
        // Validazione lavorazioni interne: verifica tempi/consumi
        if (lavInt != null && !lavInt.isEmpty()) {
            boolean lavIntSenzaConsumo = false;
            for (LavorazioniInterne l : lavInt) {
                if (l.getConsUnit() == null || l.getConsUnit() < 0) {
                    lavIntSenzaConsumo = true;
                }
            }
            if (lavIntSenzaConsumo) {
                erroriCalcolo.add("VERIFICA TEMPI/CONSUMI ASSOCIATI AI COMPONENTI");
            }
        }
        
        // Validazione lavorazioni esterne: verifica prezzo e consumi
        // Accetta valori manuali (tipoC = 'M') con costUnit > 0 anche senza listino
        if (lavEst != null && !lavEst.isEmpty()) {
            boolean lavEstSenzaPrezzo = false;
            boolean lavEstSenzaConsumo = false;
            for (LavorazioniEsterne l : lavEst) {
                // Se tipoC = 'M' (manuale) e costUnit > 0, OK anche senza listino
                boolean isManuale = "M".equals(l.getTipoC());
                boolean hasCostUnit = l.getCostUnit() > 0;
                
                if (!hasCostUnit) {
                    // costUnit <= 0: errore sempre (anche se manuale)
                    lavEstSenzaPrezzo = true;
                    if (isManuale) {
                        logger.warn("Lavorazione esterna {} con tipoC='M' ma costUnit <= 0", l.getElemento());
                    }
                }
                // Se costUnit > 0 e tipoC='M', OK (non aggiungere errore)
                
                if (l.getConsUnit() == null || l.getConsUnit() < 0) {
                    lavEstSenzaConsumo = true;
                }
            }
            if (lavEstSenzaPrezzo) {
                erroriCalcolo.add("VERIFICA PREZZO ASSOCIATO ALLE LAVORAZIONI ESTERNE");
            }
            if (lavEstSenzaConsumo) {
                erroriCalcolo.add("VERIFICA CONSUMI ASSOCIATI ALLE LAVORAZIONI ESTERNE");
            }
        }
        
        // Se ci sono errori di validazione, salva l'esito nel DB e restituisci il BOM con gli errori
        if (!erroriCalcolo.isEmpty()) {
            String esitoErrore = String.join(" | ", erroriCalcolo);
            logger.warn("Errori di validazione nel calcolo BOM per articolo {}: {}", idArticolo, esitoErrore);
            bom.setEsitoCalcolo(esitoErrore);
            bom.setBandierina("R");
            
            // Salva l'esito errore nel DB
            try {
                Bom bomEntity = articoliService.findAssociatedBoms(articoliService.getById(idArticolo).getId(), Pageable.unpaged()).getContent().getFirst();
                bomEntity.setStatoPreventivo("IN CORSO");
                bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
                bomEntity.setEsitoCalcolo(esitoErrore);
                bomEntity.setBandierina("R");
                bomService.update(bomEntity);
                upsertArticoloStato(idArticolo, "IN CORSO", currentUsernameOrSystem());
                logger.debug("Esito errore salvato nel DB per articolo {}", idArticolo);
            } catch (Exception e) {
                logger.error("Errore durante il salvataggio dell'esito errore nel DB", e);
            }
            
            return bom;
        }
        
        // 3. CALCOLO COSTO SCHEDA
        logger.debug("Calcolo costo scheda...");
        
        // 3.1 Costo Materiali
        Double costoMateriali = 0.0;
        Double consumoCuoioMq = 0.0;
        if (materiali != null && !materiali.isEmpty()) {
            for (Materiali m : materiali) {
                double costUnit = m.getCostUnit();
                Double consumo = m.getConsumo() != null ? m.getConsumo() : 0.0;
                costoMateriali += consumo * costUnit;
                if (isCuoioMaterialCode(m)) {
                    consumoCuoioMq += consumo;
                }
                logger.debug("Materiale {} - consumo: {}, costUnit: {}, subtotale: {}", m.getElemento(), consumo, costUnit, consumo * costUnit);
            }
        }
        logger.debug("Costo materiali: {}", costoMateriali);
        logger.debug("Consumo cuoio mq: {}", consumoCuoioMq);
        
        // 3.2 Costo Lavorazioni Esterne
        Double costoLavEsterne = 0.0;
        if (lavEst != null && !lavEst.isEmpty()) {
            for (LavorazioniEsterne l : lavEst) {
                Double consumo = l.getConsUnit() != null ? l.getConsUnit() : 0.0;
                double costUnit = l.getCostUnit();
                costoLavEsterne += consumo * costUnit;
                logger.debug("Lav. esterna {} - consumo: {}, costUnit: {}, subtotale: {}", l.getElemento(), consumo, costUnit, consumo * costUnit);
            }
        }
        logger.debug("Costo lavorazioni esterne: {}", costoLavEsterne);
        
        // 3.3 Costo Lavorazioni Interne (consumo * costoMinMop)
        Double costoLavInterne = 0.0;
        Double minutiTotali = 0.0;
        Double minutiManovia = 0.0;
        if (lavInt != null && !lavInt.isEmpty()) {
            for (LavorazioniInterne l : lavInt) {
                Double consumo = l.getConsUnit() != null ? l.getConsUnit() : 0.0;
                costoLavInterne += consumo * costoMinMop;
                minutiTotali += consumo;
                if (isManoviaLavorazioneInterna(l)) {
                    minutiManovia += consumo;
                }
            }
        }
        logger.debug("Costo lavorazioni interne: {}", costoLavInterne);
        logger.debug("Minuti totali lavorazioni interne: {}", minutiTotali);
        logger.debug("Minuti manovia: {}", minutiManovia);
        
        // 3.4 Costo Righe Aggiuntive (consumo * costo unitario)
        Double costoRigheAggiuntive = 0.0;
        if (righeAggiuntive != null && !righeAggiuntive.isEmpty()) {
            for (com.oneclickapp.giglioli.giglioli_preventivi.RigheAggiuntiveBom riga : righeAggiuntive) {
                double consumo = riga.getConsUnit();
                double costoUnit = riga.getCostoUnit();
                double costoTotRiga = consumo * costoUnit;
                costoRigheAggiuntive += costoTotRiga;
                
                // Aggiorna il costo_tot della riga
                riga.setCostoTot(costoTotRiga);
                
                logger.debug("Riga aggiuntiva {} - consumo: {}, costoUnit: {}, costoTot: {}", 
                    riga.getCodice(), consumo, costoUnit, costoTotRiga);
            }
        }
        logger.debug("Costo righe aggiuntive: {}", costoRigheAggiuntive);
        
        // Costo Scheda Totale (include ora anche le righe aggiuntive)
        Double costoScheda = costoMateriali + costoLavEsterne + costoLavInterne + costoRigheAggiuntive;
        logger.debug("Costo scheda totale: {}", costoScheda);
        
        if (costoScheda <= 0) {
            String errore = "COSTO SCHEDA NON VALIDO (deve essere > 0)";
            bom.setEsitoCalcolo(errore);
            bom.setBandierina("R");
            try {
                Bom bomEntity = articoliService.findAssociatedBoms(articoliService.getById(idArticolo).getId(), Pageable.unpaged()).getContent().getFirst();
                bomEntity.setEsitoCalcolo(errore);
                bomEntity.setBandierina("R");
                bomEntity.setStatoPreventivo("IN CORSO");
                bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
                bomService.update(bomEntity);
                upsertArticoloStato(idArticolo, "IN CORSO", currentUsernameOrSystem());
            } catch (Exception ex) {
                logger.error("Errore salvataggio esito", ex);
            }
            return bom;
        }
        
        // 4. CALCOLO COSTI GENERALI
        // Formula: somma consumi unitari lavorazioni interne * costoMinCge
        Double costiGenerali = minutiTotali * costoMinCge;
        logger.debug("Costi generali: {}", costiGenerali);
        
        if (minutiTotali <= 0) {
            logger.warn("Minuti totali = 0, impossibile calcolare margini al minuto");
            minutiTotali = 1.0; // Evita divisione per zero
        }
        
        // 5. CALCOLO PAREGGIO
        logger.debug("Calcolo prezzi di pareggio...");
        // Formula: (costo scheda + costi generali) / (1 - provvigioni% - sconto premio%)
        Double denominatorePareggio = 1 - provv - scontoPremio;
        if (denominatorePareggio <= 0) {
            String errore = "DENOMINATORE PAREGGIO NON VALIDO (provv + scontoPremio >= 1)";
            bom.setEsitoCalcolo(errore);
            bom.setBandierina("R");
            try {
                Bom bomEntity = articoliService.findAssociatedBoms(articoliService.getById(idArticolo).getId(), Pageable.unpaged()).getContent().getFirst();
                bomEntity.setEsitoCalcolo(errore);
                bomEntity.setBandierina("R");
                bomEntity.setStatoPreventivo("IN CORSO");
                bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
                bomService.update(bomEntity);
                upsertArticoloStato(idArticolo, "IN CORSO", currentUsernameOrSystem());
            } catch (Exception ex) { logger.error("Errore salvataggio esito", ex); }
            return bom;
        }
        
        Double pareggioPrezzoLordo = (costoScheda + costiGenerali) / denominatorePareggio;
        Float pareggioProvvSconti = (float)(pareggioPrezzoLordo * (provv + scontoPremio));
        Double pareggioPrezzoNetto = pareggioPrezzoLordo - pareggioProvvSconti;
        Double pareggioMargine = 0.0; // Il margine di pareggio è sempre 0 per definizione
        Double pareggioMargineContrib = pareggioPrezzoNetto - costoScheda;
        Double pareggioMcMinuto = pareggioMargineContrib / minutiTotali;
        
        logger.debug("Pareggio - Lordo: {}, Netto: {}, Margine Contrib: {}, MC/min: {}", 
                    pareggioPrezzoLordo, pareggioPrezzoNetto, pareggioMargineContrib, pareggioMcMinuto);
        
        // 6. CALCOLO OBIETTIVO
        logger.debug("Calcolo prezzi obiettivo...");
        // Formula: (costo scheda + costi generali) / (1 - provv% - scontoPremio% - (margineObiett% * (1 - provv% - scontoPremio%)))
        Double denominatoreObiettivo = 1 - provv - scontoPremio - (margineObiett * (1 - provv - scontoPremio));
        if (denominatoreObiettivo <= 0) {
            String errore = "DENOMINATORE OBIETTIVO NON VALIDO (margine troppo alto)";
            bom.setEsitoCalcolo(errore);
            bom.setBandierina("R");
            try {
                Bom bomEntity = articoliService.findAssociatedBoms(articoliService.getById(idArticolo).getId(), Pageable.unpaged()).getContent().getFirst();
                bomEntity.setEsitoCalcolo(errore);
                bomEntity.setBandierina("R");
                bomEntity.setStatoPreventivo("IN CORSO");
                bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
                bomService.update(bomEntity);
                upsertArticoloStato(idArticolo, "IN CORSO", currentUsernameOrSystem());
            } catch (Exception ex) { logger.error("Errore salvataggio esito", ex); }
            return bom;
        }
        
        Double obiettivoPrezzoLordo = (costoScheda + costiGenerali) / denominatoreObiettivo;
        Float obiettivoProvvSconti = (float)(obiettivoPrezzoLordo * (provv + scontoPremio));
        Double obiettivoPrezzoNetto = obiettivoPrezzoLordo - obiettivoProvvSconti;
        Double obiettivoMargine = obiettivoPrezzoNetto * margineObiett;
        Double obiettivoMargineContrib = obiettivoPrezzoNetto - costoScheda;
        Double obiettivoMcMinuto = obiettivoMargineContrib / minutiTotali;
        
        logger.debug("Obiettivo - Lordo: {}, Netto: {}, Margine: {}, Margine Contrib: {}, MC/min: {}", 
                    obiettivoPrezzoLordo, obiettivoPrezzoNetto, obiettivoMargine, obiettivoMargineContrib, obiettivoMcMinuto);
        
        // 7. CALCOLO PROPOSTO (solo se propostoPrezzoLordo è fornito)
        Float propostoProvvSconti = null;
        Double propostoPrezzoNetto = null;
        Double propostoMargine = null;
        Double propostoMargineContrib = null;
        Double propostoMcMinuto = null;
        
        if (propostoPrezzoLordo != null && propostoPrezzoLordo > 0) {
            logger.debug("Calcolo prezzi proposto...");
            propostoProvvSconti = (float)(propostoPrezzoLordo * (provv + scontoPremio));
            propostoPrezzoNetto = propostoPrezzoLordo - propostoProvvSconti;
            propostoMargine = propostoPrezzoNetto - costoScheda - costiGenerali;
            propostoMargineContrib = propostoPrezzoNetto - costoScheda;
            propostoMcMinuto = propostoMargineContrib / minutiTotali;
            
            logger.debug("Proposto - Lordo: {}, Netto: {}, Margine: {}, Margine Contrib: {}, MC/min: {}", 
                        propostoPrezzoLordo, propostoPrezzoNetto, propostoMargine, propostoMargineContrib, propostoMcMinuto);
        }
        
        // 8. CALCOLO AS400 (solo se as400PrezzoLordo è fornito)
        Float as400ProvvSconti = null;
        Double as400PrezzoNetto = null;
        Double as400Margine = null;
        Double as400MargineContrib = null;
        Double as400McMinuto = null;
        
        if (as400PrezzoLordo != null && as400PrezzoLordo > 0) {
            logger.debug("Calcolo prezzi AS400...");
            as400ProvvSconti = (float)(as400PrezzoLordo * (provv + scontoPremio));
            as400PrezzoNetto = as400PrezzoLordo - as400ProvvSconti;
            as400Margine = as400PrezzoNetto - costoScheda - costiGenerali;
            as400MargineContrib = as400PrezzoNetto - costoScheda;
            as400McMinuto = as400MargineContrib / minutiTotali;
            
            logger.debug("AS400 - Lordo: {}, Netto: {}, Margine: {}, Margine Contrib: {}, MC/min: {}", 
                        as400PrezzoLordo, as400PrezzoNetto, as400Margine, as400MargineContrib, as400McMinuto);
        }
        
        // 9. CALCOLA INCIDENZA PERCENTUALE RIGHE AGGIUNTIVE
        // L'incidenza si calcola come: costo totale righe aggiuntive / prezzo netto proposto
        if (righeAggiuntive != null && !righeAggiuntive.isEmpty() && propostoPrezzoNetto != null && propostoPrezzoNetto > 0) {
            double incidenzaPerc = (costoRigheAggiuntive / propostoPrezzoNetto) * 100.0;
            logger.debug("Incidenza percentuale righe aggiuntive: {}%", incidenzaPerc);
            
            // Aggiorna l'incidenza percentuale per ogni riga aggiuntiva e salva nel DB
            for (com.oneclickapp.giglioli.giglioli_preventivi.RigheAggiuntiveBom riga : righeAggiuntive) {
                riga.setIncidenzaPerc(incidenzaPerc);
                try {
                    righeAggiuntiveBomService.update(riga);
                    logger.debug("Aggiornata riga aggiuntiva {} - costoTot: {}, incidenzaPerc: {}%", 
                        riga.getCodice(), riga.getCostoTot(), riga.getIncidenzaPerc());
                } catch (Exception e) {
                    logger.error("Errore aggiornamento riga aggiuntiva {}: {}", riga.getCodice(), e.getMessage());
                }
            }
        }
        
        // 10. AGGIORNA BOM CON I VALORI CALCOLATI
        // Riscrive le liste override (con costUnit aggiornati) nel BOM di ritorno
        bom.setMateriali(materiali);
        bom.setLavorazioniInterne(lavInt);
        bom.setLavorazioniEsterne(lavEst);
        
        costoScheda = round3(costoScheda);
        costiGenerali = round3(costiGenerali);
        minutiTotali = round3(minutiTotali);
        costoLavInterne = round3(costoLavInterne);
        Double costoComponenti = round3(costoScheda - costoLavInterne);
        pareggioPrezzoLordo = round3(pareggioPrezzoLordo);
        pareggioProvvSconti = round3f(pareggioProvvSconti);
        pareggioPrezzoNetto = round3(pareggioPrezzoNetto);
        pareggioMargine = round3(pareggioMargine);
        pareggioMargineContrib = round3(pareggioMargineContrib);
        pareggioMcMinuto = round3(pareggioMcMinuto);
        obiettivoPrezzoLordo = round3(obiettivoPrezzoLordo);
        obiettivoProvvSconti = round3f(obiettivoProvvSconti);
        obiettivoPrezzoNetto = round3(obiettivoPrezzoNetto);
        obiettivoMargine = round3(obiettivoMargine);
        obiettivoMargineContrib = round3(obiettivoMargineContrib);
        obiettivoMcMinuto = round3(obiettivoMcMinuto);
        if (propostoPrezzoLordo != null) {
            propostoPrezzoLordo = round3(propostoPrezzoLordo);
            propostoProvvSconti = round3f(propostoProvvSconti);
            propostoPrezzoNetto = round3(propostoPrezzoNetto);
            propostoMargine = round3(propostoMargine);
            propostoMargineContrib = round3(propostoMargineContrib);
            propostoMcMinuto = round3(propostoMcMinuto);
        }
        if (as400PrezzoLordo != null) {
            as400PrezzoLordo = round3(as400PrezzoLordo);
            as400ProvvSconti = round3f(as400ProvvSconti);
            as400PrezzoNetto = round3(as400PrezzoNetto);
            as400Margine = round3(as400Margine);
            as400MargineContrib = round3(as400MargineContrib);
            as400McMinuto = round3(as400McMinuto);
        }
        
        bom.setCostoScheda(costoScheda);
        bom.setCostiGenerali(costiGenerali);
        bom.setCostoTotale(round3(costoScheda + costiGenerali));
        bom.setCostoComponenti(costoComponenti);
        bom.setConsumoCuoioMq(round3(consumoCuoioMq));
        bom.setLavorazioniInterneValore(costoLavInterne);
        bom.setMinutiLavorazione(minutiTotali);
        bom.setManovia(round3(minutiManovia));
        
        // Pareggio
        bom.setPareggioPrezzoLordo(pareggioPrezzoLordo);
        bom.setPareggioProvvSconti(pareggioProvvSconti);
        bom.setPareggioPrezzoNetto(pareggioPrezzoNetto);
        bom.setPareggioMargine(pareggioMargine);
        bom.setPareggioMargineContrib(pareggioMargineContrib);
        bom.setPareggioMcMinuto(pareggioMcMinuto);
        
        // Obiettivo
        bom.setObiettivoPrezzoLordo(obiettivoPrezzoLordo);
        bom.setObiettivoProvvSconti(obiettivoProvvSconti);
        bom.setObiettivoPrezzoNetto(obiettivoPrezzoNetto);
        bom.setObiettivoMargine(obiettivoMargine);
        bom.setObiettivoMargineContrib(obiettivoMargineContrib);
        bom.setObiettivoMcMinuto(obiettivoMcMinuto);
        
        // Proposto
        if (propostoPrezzoLordo != null) {
            bom.setPropostoPrezzoLordo(propostoPrezzoLordo);
            bom.setPropostoProvvSconti(propostoProvvSconti);
            bom.setPropostoPrezzoNetto(propostoPrezzoNetto);
            bom.setPropostoMargine(propostoMargine);
            bom.setPropostoMargineContrib(propostoMargineContrib);
            bom.setPropostoMcMinuto(propostoMcMinuto);
        }
        
        // AS400
        if (as400PrezzoLordo != null) {
            bom.setAs400PrezzoLordo(as400PrezzoLordo);
            bom.setAs400ProvvSconti(as400ProvvSconti);
            bom.setAs400PrezzoNetto(as400PrezzoNetto);
            bom.setAs400Margine(as400Margine);
            bom.setAs400MargineContrib(as400MargineContrib);
            bom.setAs400McMinuto(as400McMinuto);
        }
        
        // Popola i campi stagione nel BOM
        ParametroInfo cmopInfo = parametriCalcolo.get("CMOP");
        ParametroInfo cgenInfo = parametriCalcolo.get("CGEN");
        ParametroInfo provInfo = parametriCalcolo.get("PROV");
        ParametroInfo mobbInfo = parametriCalcolo.get("MOBB");
        ParametroInfo scontoPremioInfo = parametriCalcolo.get("SCONTO_PREMIO_DEFAULT");
        
        bom.setCmopStagione(cmopInfo != null ? cmopInfo.getStagione() : "");
        bom.setCgenStagione(cgenInfo != null ? cgenInfo.getStagione() : "");
        bom.setProvStagione(provInfo != null ? provInfo.getStagione() : "");
        bom.setMobbStagione(mobbInfo != null ? mobbInfo.getStagione() : "");
        bom.setScontoPremioStagione(scontoPremioInfo != null ? scontoPremioInfo.getStagione() : "");
        bom.setMatAccessoriStagione(stagioneRifCalcolo != null ? stagioneRifCalcolo : "");
        
        // CRITICO: Imposta le liste override nel BOM prima di salvare nel DB
        // Così il database contiene i valori modificati manualmente (costUnit, tipoC='M')
        if (materialiOverride != null && materiali != null) {
            bom.setMateriali(materiali);
            logger.debug("Impostati {} materiali override nel BOM", materiali.size());
        }
        if (lavorazioniInterneOverride != null && lavInt != null) {
            bom.setLavorazioniInterne(lavInt);
            logger.debug("Impostate {} lavorazioni interne override nel BOM", lavInt.size());
        }
        if (lavorazioniEsterneOverride != null && lavEst != null) {
            bom.setLavorazioniEsterne(lavEst);
            logger.debug("Impostate {} lavorazioni esterne override nel BOM", lavEst.size());
        }
        
        // Testata coerente con i valori usati nel calcolo (il JSON persistito deve rifletterli)
        // Manteniamo in BOM il valore "human-readable" inserito dall'utente (es. 1 = 1%),
        // mentre i calcoli usano la frazione decimale normalizzata.
        bom.setScontoPremio(scontoPremioRaw);
        bom.setMargineObiett(String.valueOf(margineObiett));
        bom.setCostoMinMop(String.valueOf(costoMinMop));
        bom.setCostoMinCge(String.valueOf(costoMinCge));
        bom.setProvv(String.valueOf(provv));
        
        // 10. SALVA NEL DB (SEMPRE) - DOPO aver impostato gli override
        try {
            aggiornaAnalizzatoDopoCalcoloMateriali(bom.getMateriali(), snapMatPreCalcolo);
            aggiornaAnalizzatoDopoCalcoloLavEst(bom.getLavorazioniEsterne(), snapLavEstPreCalcolo);
            // Calcolo completato senza errori di validazione: azzera eventuali esiti storici
            // e persiste sempre "OK" per evitare warning obsoleti.
            bom.setEsitoCalcolo("OK");
            salvaBomNelDB(bom, idArticolo, "IN CORSO");
            upsertArticoloStato(idArticolo, "IN CORSO", currentUsernameOrSystem());
            logger.debug("BOM salvata nel DB con override applicati");
        } catch (Exception e) {
            logger.error("Errore durante il salvataggio della BOM calcolata", e);
            bom.setEsitoCalcolo("ERRORE SALVATAGGIO: " + e.getMessage());
        }
        
        logger.debug("Calcolo BOM completato con successo per articolo ID: {}", idArticolo);
        return bom;
    }
    
    /**
     * Calcola il BOM per una lista di articoli (senza override).
     * Per ogni articolo chiama calcolaBom con tutti gli override a null,
     * quindi il calcolo viene salvato automaticamente nel DB.
     *
     * @param idArticoli Lista di ID articoli da calcolare
     * @return JSON string con la lista di risultati
     */
    public String calcolaBomMultiplo(List<Integer> idArticoli, String prezziPropostiJson) {
        logger.debug("Inizio calcolo BOM multiplo per {} articoli", idArticoli.size());
        List<Map<String, Object>> risultati = new java.util.ArrayList<>();

        Map<String, Double> prezziProposti = new java.util.HashMap<>();
        if (prezziPropostiJson != null && !prezziPropostiJson.isEmpty()) {
            try {
                com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
                prezziProposti = mapper.readValue(prezziPropostiJson, new com.fasterxml.jackson.core.type.TypeReference<Map<String, Double>>() {});
                logger.debug("Prezzi proposti ricevuti: {}", prezziProposti);
            } catch (Exception e) {
                logger.warn("Errore parsing prezziPropostiJson: {}", e.getMessage());
            }
        }

        for (Integer idArticolo : idArticoli) {
            Map<String, Object> risultato = new java.util.HashMap<>();
            risultato.put("idArticolo", idArticolo);
            try {
                Double propostoPrezzoLordo = prezziProposti.get(String.valueOf(idArticolo));
                BOMArticolo bom = calcolaBom(idArticolo, null, null, null, null, null, null, null, null, null, propostoPrezzoLordo, null);
                risultato.put("esito", bom.getEsitoCalcolo());
                risultato.put("successo", true);
                logger.debug("Calcolo BOM completato per articolo ID: {} - Esito: {}", idArticolo, bom.getEsitoCalcolo());
            } catch (Exception e) {
                risultato.put("esito", e.getMessage());
                risultato.put("successo", false);
                logger.error("Errore calcolo BOM per articolo ID: {}: {}", idArticolo, e.getMessage());
            }
            risultati.add(risultato);
        }
        
        logger.debug("Calcolo BOM multiplo completato: {} articoli processati", risultati.size());
        try {
            return new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(risultati);
        } catch (Exception e) {
            logger.error("Errore serializzazione risultati: {}", e.getMessage());
            return "[]";
        }
    }
    
    /**
     * Auto-popola i listini mancanti per materiali e lavorazioni esterne.
     * Cerca nei listini validi (fine_validita >= oggi) e popola costUnit se mancante.
     * Salta i valori già presenti e quelli manuali (tipoC='M').
     * 
     * @param bom BOMArticolo da popolare
     * @param codiceArticolo Codice articolo (per lavorazioni esterne)
     * @param stagioneArticolo Stagione per ricerca listini (riferimento BOM o anagrafica articolo)
     */
    private void popolaListiniMancanti(BOMArticolo bom, String codiceArticolo, String stagioneArticolo) {
        logger.debug("Auto-popolamento listini mancanti per articolo {} stagione {}", codiceArticolo, stagioneArticolo);
        
        if (stagioneArticolo == null || stagioneArticolo.isEmpty()) {
            logger.warn("Stagione articolo non disponibile, skip auto-popolamento listini");
            return;
        }
        
        int materialiPopolati = 0;
        int lavorazioniPopolate = 0;
        
        // 1. MATERIALI - usa query SQL nativa via queryExecutor
        if (bom.getMateriali() != null) {
            for (Materiali m : bom.getMateriali()) {
                logger.debug("DEBUG materiale: elemento={} fornitoreTerzista={} fornitoreTerzistaCodice={} costUnit={} tipoC={}",
                    m.getElemento(), m.getFornitTerz(), m.getFornitoreTerzistaCodice(), m.getCostUnit(), m.getTipoC());
                if ((m.getCostUnit() > 0) || "M".equals(m.getTipoC())) {
                    continue;
                }
                
                String elemento = m.getElemento();
                String fornitoreCodice = m.getFornitoreTerzistaCodice();
                
                if (elemento == null) {
                    continue;
                }
                
                // Fallback: se fornitoreTerzistaCodice è null, cerca codice dal nome fornitore
                if (fornitoreCodice == null || fornitoreCodice.trim().isEmpty()) {
                    String nomeFornitore = m.getFornitTerz();
                    if (nomeFornitore == null || nomeFornitore.trim().isEmpty()) {
                        continue;
                    }
                    try {
                        Map<String, Object> lookupParams = new java.util.HashMap<>();
                        lookupParams.put("descrizione_fornitore", nomeFornitore.trim());
                        Page<java.util.Map> lookupResult = wmQueryExecutor.executeNamedQuery(
                            "getCodiceFornitoreMaterialiByNomeFornitore", lookupParams, java.util.Map.class, PageRequest.of(0, 1));
                        if (lookupResult.hasContent()) {
                            Object codObj = lookupResult.getContent().get(0).get("fornitore");
                            fornitoreCodice = codObj != null ? codObj.toString() : null;
                            logger.debug("Risolto codice fornitore per materiale {} nome '{}': {}", elemento, nomeFornitore, fornitoreCodice);
                        }
                    } catch (Exception ex) {
                        logger.warn("Errore lookup codice fornitore per materiale {} nome '{}': {}", elemento, nomeFornitore, ex.getMessage());
                    }
                }
                
                if (fornitoreCodice == null || fornitoreCodice.trim().isEmpty()) {
                    continue;
                }
                
                Integer fornitore = null;
                try {
                    fornitore = Integer.parseInt(fornitoreCodice.trim());
                } catch (NumberFormatException e) {
                    logger.warn("Codice fornitore non numerico per materiale {}: {}", elemento, fornitoreCodice);
                    continue;
                }
                
                try {
                    Map<String, Object> params = new java.util.HashMap<>();
                    params.put("elemento", elemento);
                    params.put("fornitore", String.valueOf(fornitore));
                    params.put("stagione", stagioneArticolo);
                    
                    Page<com.oneclickapp.giglioli.giglioli_preventivi.models.query.LoadStoricoListinoMaterialiResponse> risultati =
                        wmQueryExecutor.executeNamedQuery("getListinoMaterialeValido", params,
                            com.oneclickapp.giglioli.giglioli_preventivi.models.query.LoadStoricoListinoMaterialiResponse.class,
                            PageRequest.of(0, 1));
                    
                    if (risultati.hasContent()) {
                        com.oneclickapp.giglioli.giglioli_preventivi.models.query.LoadStoricoListinoMaterialiResponse listino = risultati.getContent().get(0);
                        if (listino.getPrezzo() != null && listino.getPrezzo() > 0) {
                            m.setCostUnit(listino.getPrezzo());
                            if (listino.getStagione() != null) {
                                m.setTipoC(listino.getStagione());
                            }
                            materialiPopolati++;
                            logger.debug("Popolato materiale {} fornitore {} con prezzo {} stagione {}", elemento, fornitore, listino.getPrezzo(), listino.getStagione());
                        }
                    }
                } catch (Exception e) {
                    logger.warn("Errore ricerca listino materiale {} fornitore {}: {}", elemento, fornitore, e.getMessage());
                }
            }
        }
        
        // 2. LAVORAZIONI ESTERNE - usa query SQL nativa via queryExecutor
        if (bom.getLavorazioniEsterne() != null) {
            for (LavorazioniEsterne le : bom.getLavorazioniEsterne()) {
                if ((le.getCostUnit() > 0) || "M".equals(le.getTipoC())) {
                    continue;
                }
                
                String codiceFase = le.getElemento();
                String fornitoreCodice = le.getFornitoreTerzistaCodice();
                String codiceProdotto = null;
                if (le.getCodiceSl() != null && !String.valueOf(le.getCodiceSl()).trim().isEmpty()) {
                    codiceProdotto = String.valueOf(le.getCodiceSl()).trim();
                } else if (codiceArticolo != null && !codiceArticolo.trim().isEmpty()) {
                    codiceProdotto = codiceArticolo.trim();
                }
                
                if (codiceFase == null || codiceProdotto == null) {
                    continue;
                }
                
                // Fallback: se fornitoreTerzistaCodice è null, cerca codice dal nome fornitore
                if (fornitoreCodice == null || fornitoreCodice.trim().isEmpty()) {
                    String nomeFornitore = le.getFornitTerz();
                    if (nomeFornitore == null || nomeFornitore.trim().isEmpty()) {
                        continue;
                    }
                    try {
                        Map<String, Object> lookupParams = new java.util.HashMap<>();
                        lookupParams.put("descrizione_fornitore", nomeFornitore.trim());
                        Page<java.util.Map> lookupResult = wmQueryExecutor.executeNamedQuery(
                            "getCodiceFornitoreLavEstByNomeFornitore", lookupParams, java.util.Map.class, PageRequest.of(0, 1));
                        if (lookupResult.hasContent()) {
                            Object codObj = lookupResult.getContent().get(0).get("fornitore");
                            fornitoreCodice = codObj != null ? codObj.toString() : null;
                            logger.debug("Risolto codice fornitore per lavorazione esterna fase {} nome '{}': {}", codiceFase, nomeFornitore, fornitoreCodice);
                        }
                    } catch (Exception ex) {
                        logger.warn("Errore lookup codice fornitore per lavorazione esterna fase {} nome '{}': {}", codiceFase, nomeFornitore, ex.getMessage());
                    }
                }
                
                if (fornitoreCodice == null || fornitoreCodice.trim().isEmpty()) {
                    continue;
                }
                
                Integer fornitore = null;
                try {
                    fornitore = Integer.parseInt(fornitoreCodice.trim());
                } catch (NumberFormatException e) {
                    logger.warn("Codice fornitore non numerico per lavorazione esterna fase {}: {}", codiceFase, fornitoreCodice);
                    continue;
                }
                
                try {
                    Map<String, Object> params = new java.util.HashMap<>();
                    params.put("codice_prodotto", codiceProdotto);
                    params.put("codice_fase", codiceFase);
                    params.put("fornitore", String.valueOf(fornitore));
                    params.put("stagione", stagioneArticolo);
                    
                    Page<com.oneclickapp.giglioli.giglioli_preventivi.models.query.LoadListinoContoLavoroResponse> risultati =
                        wmQueryExecutor.executeNamedQuery("getListinoLavorazioneEsternaValido", params,
                            com.oneclickapp.giglioli.giglioli_preventivi.models.query.LoadListinoContoLavoroResponse.class,
                            PageRequest.of(0, 1));
                    
                    if (risultati.hasContent()) {
                        com.oneclickapp.giglioli.giglioli_preventivi.models.query.LoadListinoContoLavoroResponse listino = risultati.getContent().get(0);
                        if (listino.getPrezzo() != null && listino.getPrezzo() > 0) {
                            le.setCostUnit(listino.getPrezzo());
                            if (listino.getStagione() != null) {
                                le.setTipoC(listino.getStagione());
                            }
                            lavorazioniPopolate++;
                            logger.debug("Popolata lavorazione esterna prodotto {} fase {} fornitore {} con prezzo {} stagione {}",
                                      codiceProdotto, codiceFase, fornitore, listino.getPrezzo(), listino.getStagione());
                        }
                    }
                } catch (Exception e) {
                    logger.warn("Errore ricerca listino lavorazione esterna prodotto {} fase {} fornitore {}: {}",
                              codiceProdotto, codiceFase, fornitore, e.getMessage());
                }
            }
        }
        
        logger.debug("Auto-popolamento completato: {} materiali, {} lavorazioni esterne", materialiPopolati, lavorazioniPopolate);
    }
    
    /**
     * Metodo privato per salvare il BOM nel DB.
     * Estrae la logica comune di salvataggio usata da calcolaBom e salvaBom.
     * 
     * @param bomArticolo BOMArticolo da salvare
     * @param idArticolo ID dell'articolo
     * @param statoPreventivo Stato da impostare (es. "IN CORSO", "STORICIZZATO")
     * @throws Exception se il salvataggio fallisce
     */
    private void salvaBomNelDB(BOMArticolo bomArticolo, Integer idArticolo, String statoPreventivo) throws Exception {
        logger.debug("Salvataggio BOM nel DB per articolo ID: {} con stato: {}", idArticolo, statoPreventivo);
        
        Bom bomEntity = articoliService.findAssociatedBoms(
            articoliService.getById(idArticolo).getId(), 
            Pageable.unpaged()
        ).getContent().getFirst();
        // Per coda integrazione: prezzo AS400 già persistito prima di questa scrittura (non il nuovo proposto)
        Double oldAs400PrezzoPerQueue = bomEntity.getAs400PrezzoLordo();
        
        // Aggiorna stato
        bomEntity.setStatoPreventivo(statoPreventivo);
        bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
        bomEntity.setEsitoCalcolo(bomArticolo.getEsitoCalcolo() != null ? bomArticolo.getEsitoCalcolo() : "OK");
        
        // Aggiorna valori calcolati
        bomEntity.setCostoScheda(bomArticolo.getCostoScheda());
        bomEntity.setCostiGenerali(bomArticolo.getCostiGenerali());
        bomEntity.setCostoTotale(bomArticolo.getCostoTotale());
        bomEntity.setMinutiLavorazione(bomArticolo.getMinutiLavorazione());
        bomEntity.setManovia(bomArticolo.getManovia());
        bomEntity.setLavorazioniInterne(bomArticolo.getLavorazioniInterneValore());
        bomEntity.setConsumoCuoioMq(bomArticolo.getConsumoCuoioMq());
        bomEntity.setCostoComponenti(bomArticolo.getCostoComponenti());
        bomEntity.setMatAccessori(bomArticolo.getMatAccessori());
        bomEntity.setScontoPremio(bomArticolo.getScontoPremio());
        
        // Pareggio
        bomEntity.setPareggioPrezzoLordo(bomArticolo.getPareggioPrezzoLordo());
        bomEntity.setPareggioProvvSconti(clampProvvScontiForBomColumn(bomArticolo.getPareggioProvvSconti()));
        bomEntity.setPareggioPrezzoNetto(bomArticolo.getPareggioPrezzoNetto());
        bomEntity.setPareggioMargine(bomArticolo.getPareggioMargine());
        bomEntity.setPareggioMargineContrib(bomArticolo.getPareggioMargineContrib());
        bomEntity.setPareggioMcMinuto(bomArticolo.getPareggioMcMinuto());
        
        // Obiettivo
        bomEntity.setObiettivoPrezzoLordo(bomArticolo.getObiettivoPrezzoLordo());
        bomEntity.setObiettivoProvvSconti(clampProvvScontiForBomColumn(bomArticolo.getObiettivoProvvSconti()));
        bomEntity.setObiettivoPrezzoNetto(bomArticolo.getObiettivoPrezzoNetto());
        bomEntity.setObiettivoMargine(bomArticolo.getObiettivoMargine());
        bomEntity.setObiettivoMargineContrib(bomArticolo.getObiettivoMargineContrib());
        bomEntity.setObiettivoMcMinuto(bomArticolo.getObiettivoMcMinuto());
        
        // Proposto (solo colonne proposto: AS400 resta l'ultimo valore di riferimento calcolato sul lordo AS400 in BOM, non il nuovo proposto)
        if (bomArticolo.getPropostoPrezzoLordo() != null) {
            bomEntity.setPropostoPrezzoLordo(bomArticolo.getPropostoPrezzoLordo());
            bomEntity.setPropostoProvvSconti(clampProvvScontiForBomColumn(bomArticolo.getPropostoProvvSconti()));
            bomEntity.setPropostoPrezzoNetto(bomArticolo.getPropostoPrezzoNetto());
            bomEntity.setPropostoMargine(bomArticolo.getPropostoMargine());
            bomEntity.setPropostoMargineContrib(bomArticolo.getPropostoMargineContrib());
            bomEntity.setPropostoMcMinuto(bomArticolo.getPropostoMcMinuto());
        }
        
        // AS400 su tabella bom: allineati al calcolo in BOMArticolo (lordo/margini sul prezzo AS400 persistito o da override)
        if (bomArticolo.getAs400PrezzoLordo() != null) {
            bomEntity.setAs400PrezzoLordo(bomArticolo.getAs400PrezzoLordo());
            bomEntity.setAs400ProvvSconti(clampProvvScontiForBomColumn(bomArticolo.getAs400ProvvSconti()));
            bomEntity.setAs400PrezzoNetto(bomArticolo.getAs400PrezzoNetto());
            bomEntity.setAs400Margine(bomArticolo.getAs400Margine());
            bomEntity.setAs400MargineContrib(bomArticolo.getAs400MargineContrib());
            bomEntity.setAs400McMinuto(bomArticolo.getAs400McMinuto());
        }
        
        // Serializza e persiste PRIMA la riga bom (campo JSON + colonne): non dipendere dalla coda integrazione
        ObjectMapper mapper = new ObjectMapper();
        String bomJson = mapper.writeValueAsString(bomArticolo);
        bomEntity.setBom(bomJson);
        logger.debug("BOM JSON serializzato, lunghezza: {} caratteri", bomJson.length());
        
        // Se è storicizzato, aggiorna anche il flag
        if ("STORICIZZATO".equals(statoPreventivo)) {
            bomEntity.setStoricizzato(true);
        }
        
        bomService.update(bomEntity);
        logger.debug("BOM salvata nel DB con stato: {}", statoPreventivo);
        
        if (bomArticolo.getPropostoPrezzoLordo() != null) {
            try {
                com.oneclickapp.giglioli.giglioli_preventivi.IntegrationChangeQueue queueRecord =
                        new com.oneclickapp.giglioli.giglioli_preventivi.IntegrationChangeQueue();
                queueRecord.setScope("prezzo_articolo");
                queueRecord.setOperationType(oldAs400PrezzoPerQueue != null && oldAs400PrezzoPerQueue > 0 ? "UPDATE" : "INSERT");
                queueRecord.setOldValues(null);
                queueRecord.setNewValues(bomJson);
                queueRecord.setCreationTimestamp(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
                queueRecord.setModificationTimestamp(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
                integrationChangeQueueService.create(queueRecord);
                logger.debug("Record inserito in integration_change_queue per prezzo articolo - Prezzo Proposto: {}",
                        bomArticolo.getPropostoPrezzoLordo());
            } catch (Exception e) {
                logger.error("Errore inserimento record in integration_change_queue: {}", e.getMessage(), e);
            }
        }
        
        // Aggiorna anche il BOMArticolo di ritorno
        bomArticolo.setStatoPreventivo(statoPreventivo);
        bomArticolo.setDataStatoPreventivo(java.time.LocalDateTime.now().toString());
        if ("STORICIZZATO".equals(statoPreventivo)) {
            bomArticolo.setStoricizzato(true);
        }
    }
    
    /**
     * Salva (storicizza) il BOM calcolato nel DB.
     * Riceve l'idArticolo e il JSON BOM completo dal frontend (già calcolato),
     * aggiorna il campo bom JSON + tutti i campi calcolati + stato STORICIZZATO.
     *
     * @param idArticolo ID dell'articolo
     * @param bomJson JSON completo del BOM calcolato dal frontend
     * @return BOMArticolo aggiornato
     */
    public BOMArticolo salvaBom(Integer idArticolo, String bomJson) {
        logger.debug("Inizio salvataggio (storicizzazione) BOM per articolo ID: {}", idArticolo);
        
        try {
            // Deserializza il JSON dal frontend
            ObjectMapper mapper = new ObjectMapper();
            BOMArticolo bomArticolo = mapper.readValue(bomJson, BOMArticolo.class);
            
            // Usa il metodo comune per salvare nel DB
            salvaBomNelDB(bomArticolo, idArticolo, "STORICIZZATO");
            
            return bomArticolo;
            
        } catch (Exception e) {
            logger.error("Errore durante la storicizzazione della BOM per articolo ID: {}", idArticolo, e);
            throw new RuntimeException("Errore durante la storicizzazione della distinta: " + e.getMessage(), e);
        }
    }
    
    /**
     * Storicizza il BOM corrente salvandolo nella tabella bom_history
     * @param idArticolo ID dell'articolo
     * @param bomJson JSON BOM lato client (campi maschera), stesso uso di {@code clientBomJson}; se valorizzato ha priorità (WaveMaker invia entrambi come form field).
     * @param clientBomJson JSON inviato dal client (opzionale): flag {@code analizzato} su materiali/lav., ecc.
     * @return BOMArticolo aggiornato con flag storicizzato
     */
    public BOMArticolo storicizzaBom(Integer idArticolo, String bomJson, String clientBomJson, Double propostoPrezzoLordo) {
        logger.debug("Inizio storicizzazione BOM in bom_history per articolo ID: {}", idArticolo);
        
        try {
            String mergePayload = (bomJson != null && !bomJson.isBlank()) ? bomJson : clientBomJson;
            // 1. Recupera il BOM corrente calcolato
            BOMArticolo bomArticolo = getBomArticoloById(idArticolo);
            ObjectMapper mapper = new ObjectMapper();
            if (mergePayload != null && !mergePayload.isBlank()) {
                logger.debug("storicizzaBom merge JSON length: {}", mergePayload.length());
                try {
                    JsonNode clientRoot = mapper.readTree(mergePayload);
                    mergeAnalizzatoFlagsFromClientJson(bomArticolo, clientRoot);
                    mergePropostoPrezzoLordoFromClientJson(bomArticolo, clientRoot);
                } catch (Exception parseEx) {
                    logger.warn("clientBomJson non parsabile, validazione solo su BOM server: {}", parseEx.getMessage());
                }
            } else {
                logger.debug("storicizzaBom senza merge client (payload vuoto)");
            }
            // Parametro query esplicito: il merge JSON a volte non include il prezzo (campo non flushato / WM).
            if (propostoPrezzoLordo != null) {
                bomArticolo.setPropostoPrezzoLordo(propostoPrezzoLordo);
            }
            assertDistintaAnalizzataPerStoricizzazione(bomArticolo);
            
            // 2. Serializza il BOM completo in JSON
            String bomJsonPersistito = mapper.writeValueAsString(bomArticolo);
            
            // 3. Crea un nuovo record in bom_history
            com.oneclickapp.giglioli.giglioli_preventivi.BomHistory bomHistory = 
                new com.oneclickapp.giglioli.giglioli_preventivi.BomHistory();
            
            bomHistory.setArticoloId(idArticolo);
            bomHistory.setBomJson(bomJsonPersistito);
            bomHistory.setDataVersione(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
            
            // Popola i campi numerici dall'analisi (consumo non esiste in BOMArticolo, lo lasciamo a 0)
            bomHistory.setConsumo(0.0);
            bomHistory.setCostoComponenti(bomArticolo.getCostoScheda() != null ? bomArticolo.getCostoScheda() : 0.0);
            bomHistory.setMinutiTotali(bomArticolo.getMinutiLavorazione() != null ? bomArticolo.getMinutiLavorazione() : 0.0);
            bomHistory.setCostoScheda(bomArticolo.getCostoScheda() != null ? bomArticolo.getCostoScheda() : 0.0);
            bomHistory.setCostoTotale(bomArticolo.getCostoTotale() != null ? bomArticolo.getCostoTotale() : 0.0);
            bomHistory.setPuntoPareggioLordo(bomArticolo.getPareggioPrezzoLordo() != null ? bomArticolo.getPareggioPrezzoLordo() : 0.0);
            bomHistory.setPrezzoObiettivoNetto(bomArticolo.getObiettivoPrezzoNetto() != null ? bomArticolo.getObiettivoPrezzoNetto() : 0.0);
            bomHistory.setPrezzoObiettivoLordo(bomArticolo.getObiettivoPrezzoLordo() != null ? bomArticolo.getObiettivoPrezzoLordo() : 0.0);
            bomHistory.setPrezzoPropostoLordo(bomArticolo.getPropostoPrezzoLordo());
            bomHistory.setCostoMinMop(parseDoubleOrDefault(bomArticolo.getCostoMinMop(), 0.0));
            bomHistory.setCostoMinCge(parseDoubleOrDefault(bomArticolo.getCostoMinCge(), 0.0));
            
            // TODO: Recuperare l'utente corrente dal SecurityService
            bomHistory.setUtente("SYSTEM");
            
            bomHistory.setModificationTimestamp(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
            
            // 4. Salva in bom_history usando il service ottenuto da ApplicationContext
            com.oneclickapp.giglioli.giglioli_preventivi.service.BomHistoryService bomHistoryService = 
                applicationContext.getBean("GIGLIOLI_PREVENTIVI.BomHistoryService", 
                    com.oneclickapp.giglioli.giglioli_preventivi.service.BomHistoryService.class);
            bomHistoryService.create(bomHistory);
            
            logger.debug("BOM storicizzato con successo in bom_history per articolo ID: {}", idArticolo);
            
            // 5. Tabella bom: persistere anche il JSON (come in bom_history), così al rientro in scheda
            //    i flag analizzato restano coerenti con la distinta validata. Prima solo bom_history
            //    veniva aggiornata e bom.bom restava senza gli analizzato=true → checkbox tutte spente.
            Bom bomEntity = articoliService.findAssociatedBoms(
                articoliService.getById(idArticolo).getId(), Pageable.unpaged()
            ).getContent().getFirst();
            bomEntity.setBom(bomJsonPersistito);
            // Sempre marcare storicizzato; allineare stato_preventivo se mancante (prima si aggiornava solo se
            // storicizzato era false → righe con storicizzato=true e stato IN CORSO bloccavano il comunicato).
            bomEntity.setStoricizzato(true);
            if (!"STORICIZZATO".equals(bomEntity.getStatoPreventivo())) {
                bomEntity.setStatoPreventivo("STORICIZZATO");
                bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
            }
            bomService.update(bomEntity);
            logger.debug("BOM aggiornata in tabella bom (json + flag storicizzazione) per articolo ID: {}", idArticolo);
            
            // 6. Aggiorna il BOMArticolo di ritorno
            bomArticolo.setStoricizzato(true);
            bomArticolo.setStatoPreventivo("STORICIZZATO");
            
            return bomArticolo;
            
        } catch (Exception e) {
            logger.error("Errore durante la storicizzazione in bom_history per articolo ID: {}", idArticolo, e);
            throw new RuntimeException("Errore durante la storicizzazione: " + e.getMessage(), e);
        }
    }

    /**
     * Registra un comunicato: nota con prefisso (data, prezzo proposto, COMUNICATO), proprietà articolo COMUNICATO,
     * riga {@code articoli_comunicazioni} (aggiorna anche {@code modification_timestamp} usato in master come data comunicazione).
     * <p>
     * TODO successivo: generazione PDF comunicato e salvataggio su file system.
     */
    @Transactional(rollbackFor = Exception.class, value = "GIGLIOLI_PREVENTIVITransactionManager")
    public String registraComunicato(Integer idArticolo, String testoNota) {
        if (idArticolo == null) {
            throw new RuntimeException("idArticolo obbligatorio");
        }
        String userText = testoNota != null ? testoNota.trim() : "";
        if (userText.isEmpty()) {
            throw new RuntimeException("Inserire il testo obbligatorio della nota");
        }

        Bom bomEntity = articoliService.findAssociatedBoms(
                articoliService.getById(idArticolo).getId(),
                Pageable.unpaged()
        ).getContent().getFirst();

        if (!Boolean.TRUE.equals(bomEntity.getStoricizzato())) {
            throw new RuntimeException("La distinta deve essere storicizzata prima del comunicato");
        }
        if (!"STORICIZZATO".equals(bomEntity.getStatoPreventivo())) {
            logger.warn(
                    "registraComunicato: BOM già storicizzato ma stato_preventivo={} (articolo_id={}) — allineamento a STORICIZZATO",
                    bomEntity.getStatoPreventivo(), idArticolo);
            bomEntity.setStatoPreventivo("STORICIZZATO");
            if (bomEntity.getDataStatoPreventivo() == null) {
                bomEntity.setDataStatoPreventivo(java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
            }
            bomService.update(bomEntity);
        }
        Double prezzo = bomEntity.getPropostoPrezzoLordo();
        if (prezzo == null || prezzo <= 0) {
            throw new RuntimeException("Prezzo proposto obbligatorio e maggiore di zero");
        }

        String dataStr = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")
                .format(java.time.LocalDate.now());
        String prefisso = dataStr + " — prezzo proposto " + formatEuroIt(prezzo) + " € — COMUNICATO\n";
        String bloccoNota = prefisso + userText;

        NoteId noteId = new NoteId();
        noteId.setIdRefTabella(idArticolo);
        noteId.setTabella("articoli");

        Note existingNote = noteService.findById(noteId);
        if (existingNote == null) {
            Note n = new Note();
            n.setIdRefTabella(idArticolo);
            n.setTabella("articoli");
            n.setTitolo("COMUNICATO");
            n.setAnnotazione(bloccoNota);
            noteService.create(n);
        } else {
            // Manteniamo nel campo nota solo l'ultimo comunicato:
            // lo storico comunicati è già tracciato in articoli_comunicazioni.
            existingNote.setAnnotazione(bloccoNota);
            noteService.update(existingNote);
        }

        String utente = currentUsernameOrSystem();

        // Molti articoli hanno la proprietà solo via JOIN in query master senza riga dedicata in articoli_propieta:
        // in quel caso creiamo la riga (uk su articolo_id) invece di fallire.
        Page<ArticoliPropieta> props = articoliPropietaService.findAll("articoloId = " + idArticolo, Pageable.unpaged());
        if (props != null && props.hasContent()) {
            ArticoliPropieta ap = props.getContent().get(0);
            ap.setPropieta("COMUNICATO");
            ap.setUtenteCambioPropieta(utente);
            articoliPropietaService.update(ap);
        } else {
            ArticoliPropieta nuova = new ArticoliPropieta();
            nuova.setArticoloId(idArticolo);
            nuova.setPropieta("COMUNICATO");
            nuova.setUtenteCambioPropieta(utente);
            articoliPropietaService.create(nuova);
            logger.warn("registraComunicato: creato record articoli_propieta mancante per articolo_id={}", idArticolo);
        }

        String comText = bloccoNota.length() > 2048 ? bloccoNota.substring(0, 2048) : bloccoNota;
        Page<ArticoliComunicazioni> coms = articoliComunicazioniService.findAll("articoloId = " + idArticolo, Pageable.unpaged());
        if (coms == null || !coms.hasContent()) {
            ArticoliComunicazioni ac = new ArticoliComunicazioni();
            ac.setArticoloId(idArticolo);
            ac.setComunicazione(comText);
            ac.setUtenteCambioComunicazione(utente);
            articoliComunicazioniService.create(ac);
        } else {
            ArticoliComunicazioni ac = coms.getContent().get(0);
            ac.setComunicazione(comText);
            ac.setUtenteCambioComunicazione(utente);
            articoliComunicazioniService.update(ac);
        }

        // TODO: generazione PDF comunicato e dialog salvataggio file (integrazione successiva).

        return "OK";
    }

    private static String formatEuroIt(double value) {
        DecimalFormatSymbols sym = DecimalFormatSymbols.getInstance(Locale.ITALY);
        DecimalFormat df = new DecimalFormat("#,##0.00", sym);
        return df.format(value);
    }

    private static String currentUsernameOrSystem() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getName() != null && !auth.getName().isEmpty()
                    && !"anonymousUser".equalsIgnoreCase(auth.getName())) {
                return auth.getName();
            }
        } catch (Exception ignored) {
            // resta SYSTEM
        }
        return "SYSTEM";
    }

    private void upsertArticoloStato(Integer idArticolo, String stato, String utente) {
        if (idArticolo == null || stato == null || stato.trim().isEmpty()) {
            return;
        }
        String utenteEffettivo = (utente == null || utente.trim().isEmpty()) ? "SYSTEM" : utente.trim();
        try {
            Page<ArticoliStati> statiPage = articoliStatiService.findAll("articoloId = " + idArticolo, Pageable.unpaged());
            if (statiPage != null && statiPage.hasContent()) {
                ArticoliStati esistente = statiPage.getContent().get(0);
                esistente.setStato(stato);
                esistente.setUtenteCambioStato(utenteEffettivo);
                articoliStatiService.update(esistente);
            } else {
                ArticoliStati nuovo = new ArticoliStati();
                nuovo.setArticoloId(idArticolo);
                nuovo.setStato(stato);
                nuovo.setUtenteCambioStato(utenteEffettivo);
                articoliStatiService.create(nuovo);
                logger.warn("upsertArticoloStato: creato record articoli_stati mancante per articolo_id={}", idArticolo);
            }
        } catch (Exception e) {
            logger.error("upsertArticoloStato: errore aggiornamento articoli_stati per articolo_id={} stato={}", idArticolo, stato, e);
        }
    }
    
    /**
     * Recupera il costo unitario di un materiale dal listino
     * @param elemento - Codice elemento
     * @param fornitore - Codice fornitore
     * @param stagione - Stagione listino (es. "E26")
     * @return Double - Costo unitario (prezzo), null se non trovato
     */
    public Double getCostoFromListino(String elemento, String fornitore, String stagione) {
        logger.debug("Recupero costo dal listino per elemento: {}, fornitore: {}, stagione: {}", elemento, fornitore, stagione);
        
        if (elemento == null || fornitore == null || stagione == null) {
            logger.warn("Parametri mancanti per recupero costo: elemento={}, fornitore={}, stagione={}", elemento, fornitore, stagione);
            return null;
        }
        
        try {
            // Usa il service per cercare nel listino materiali
            // Assumendo che ListinoMateriali abbia i campi: elemento, fornitore, stagione, prezzo
            Page<com.oneclickapp.giglioli.giglioli_preventivi.ListinoMateriali> results = 
                listinoMaterialiService.findAll(
                    "elemento = '" + elemento.trim() + "' AND fornitore = '" + fornitore.trim() + "' AND stagione = '" + stagione.trim() + "'",
                    Pageable.unpaged()
                );
            
            if (results != null && results.hasContent()) {
                com.oneclickapp.giglioli.giglioli_preventivi.ListinoMateriali listino = results.getContent().get(0);
                Double costoUnitario = listino.getPrezzo();
                logger.debug("Costo trovato: {} per elemento: {}", costoUnitario, elemento);
                return costoUnitario;
            }
            
            logger.warn("Nessun costo trovato nel listino per elemento: {}, fornitore: {}, stagione: {}", elemento, fornitore, stagione);
            return null;
            
        } catch (Exception ex) {
            logger.error("Errore durante il recupero del costo dal listino per elemento: {}", elemento, ex);
            return null;
        }
    }
    
    /**
     * Recupera il costo unitario di una lavorazione esterna dal listino lavorazioni esterne.
     * @param codiceFase - Codice fase (elemento nel BOM)
     * @param fornitore - Codice fornitore terzista
     * @param stagione - Stagione listino (es. "E26")
     * @return Double - Costo unitario (prezzo), null se non trovato
     */
    public Double getCostoFromListinoLavEst(String codiceFase, String fornitore, String stagione) {
        logger.debug("Recupero costo dal listino lav. esterne per codiceFase: {}, fornitore: {}, stagione: {}", codiceFase, fornitore, stagione);
        
        if (codiceFase == null || fornitore == null || stagione == null) {
            logger.warn("Parametri mancanti per recupero costo lav. esterne: codiceFase={}, fornitore={}, stagione={}", codiceFase, fornitore, stagione);
            return null;
        }
        
        try {
            Page<com.oneclickapp.giglioli.giglioli_preventivi.ListinoLavorazioniEsterne> results = 
                listinoLavorazioniEsterneService.findAll(
                    "codiceFase = '" + codiceFase.trim() + "' AND fornitore = '" + fornitore.trim() + "' AND stagione = '" + stagione.trim() + "'",
                    Pageable.unpaged()
                );
            
            if (results != null && results.hasContent()) {
                com.oneclickapp.giglioli.giglioli_preventivi.ListinoLavorazioniEsterne listino = results.getContent().get(0);
                Double costoUnitario = listino.getPrezzo();
                logger.debug("Costo lav. esterne trovato: {} per codiceFase: {}", costoUnitario, codiceFase);
                return costoUnitario;
            }
            
            logger.warn("Nessun costo trovato nel listino lav. esterne per codiceFase: {}, fornitore: {}, stagione: {}", codiceFase, fornitore, stagione);
            return null;
            
        } catch (Exception ex) {
            logger.error("Errore durante il recupero del costo dal listino lav. esterne per codiceFase: {}", codiceFase, ex);
            return null;
        }
    }

    /**
     * Helper method per parsare String a Double con valore di default
     */
    private double round3(double value) {
        return Math.round(value * 1000.0) / 1000.0;
    }
    
    private float round3f(float value) {
        return Math.round(value * 1000.0f) / 1000.0f;
    }

    /**
     * Colonne {@code pareggio_provv_sconti}, {@code obiettivo_provv_sconti}, ecc. su tabella {@code bom}
     * sono DECIMAL(5,3): oltre ~±99.999 MariaDB risponde 1264 Out of range.
     */
    private static Float clampProvvScontiForBomColumn(Float v) {
        if (v == null || !Float.isFinite(v)) {
            return null;
        }
        final float max = 99.999f;
        if (v > max) {
            return max;
        }
        if (v < -max) {
            return -max;
        }
        return v;
    }

    private Double sumLavorazioniInterneConsumo(List<LavorazioniInterne> lavorazioniInterne) {
        if (lavorazioniInterne == null || lavorazioniInterne.isEmpty()) {
            return 0.0;
        }
        double total = 0.0;
        for (LavorazioniInterne li : lavorazioniInterne) {
            total += li != null && li.getConsUnit() != null ? li.getConsUnit() : 0.0;
        }
        return total;
    }

    private boolean isManoviaLavorazioneInterna(LavorazioniInterne lavorazione) {
        if (lavorazione == null) {
            return false;
        }
        String descrizione = lavorazione.getDescrizione();
        if (descrizione != null && descrizione.trim().toUpperCase(Locale.ROOT).contains("MANOVIA")) {
            return true;
        }
        String elemento = lavorazione.getElemento();
        if (elemento == null) {
            return false;
        }
        String codice = elemento.trim().toUpperCase(Locale.ROOT);
        return codice.contains("MANOVIA") || codice.startsWith("M");
    }

    private Double sumManoviaConsumo(List<LavorazioniInterne> lavorazioniInterne) {
        if (lavorazioniInterne == null || lavorazioniInterne.isEmpty()) {
            return 0.0;
        }
        double total = 0.0;
        for (LavorazioniInterne li : lavorazioniInterne) {
            if (isManoviaLavorazioneInterna(li)) {
                total += li != null && li.getConsUnit() != null ? li.getConsUnit() : 0.0;
            }
        }
        return total;
    }

    private boolean isCuoioMaterialCode(Materiali materiale) {
        if (materiale == null) {
            return false;
        }
        String elemento = materiale.getElemento();
        if (elemento != null && elemento.trim().toUpperCase(Locale.ROOT).startsWith("CU")) {
            return true;
        }
        Object codiceSl = materiale.getCodiceSl();
        if (codiceSl == null) {
            return false;
        }
        return String.valueOf(codiceSl).trim().toUpperCase(Locale.ROOT).startsWith("CU");
    }

    private Double computeConsumoCuoioMq(List<Materiali> materiali) {
        if (materiali == null || materiali.isEmpty()) {
            return 0.0;
        }
        double total = 0.0;
        for (Materiali materiale : materiali) {
            if (isCuoioMaterialCode(materiale)) {
                total += materiale != null && materiale.getConsumo() != null ? materiale.getConsumo() : 0.0;
            }
        }
        return total;
    }
    
    private Double parseDoubleOrDefault(String value, Double defaultValue) {
        if (value == null || value.trim().isEmpty()) {
            return defaultValue;
        }
        String s = value.trim();
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException ignored) {
            // Valori da UI/DB locale IT (es. "0,4"): Double.parseDouble accetta solo il punto.
            if (s.indexOf(',') >= 0 && s.indexOf('.') < 0) {
                try {
                    return Double.parseDouble(s.replace(',', '.'));
                } catch (NumberFormatException e2) {
                    logger.warn("Impossibile parsare '{}' a Double (né diretto né con virgola→punto), uso default: {}", value, defaultValue);
                    return defaultValue;
                }
            }
            logger.warn("Impossibile parsare '{}' a Double, uso valore di default: {}", value, defaultValue);
            return defaultValue;
        }
    }

    private Double normalizePercentFraction(Double value) {
        if (value == null) {
            return null;
        }
        // Convenzione input UI: 0.01 = 1%, 1 = 1%, 65 = 65%.
        if (value >= 1.0) {
            return value / 100.0;
        }
        return value;
    }

    private boolean sameParametroValue(String currentValue, String parameterValue) {
        if (currentValue == null && parameterValue == null) {
            return true;
        }
        if (currentValue == null || parameterValue == null) {
            return false;
        }
        Double currNum = parseDoubleOrDefault(currentValue, null);
        Double paramNum = parseDoubleOrDefault(parameterValue, null);
        if (currNum != null && paramNum != null) {
            return Math.abs(currNum - paramNum) < 0.000001d;
        }
        return currentValue.trim().equalsIgnoreCase(parameterValue.trim());
    }
    
    /**
     * Classe interna per rappresentare un parametro con valore e stagione
     */
    private static class ParametroInfo {
        private final String valore;
        private final String stagione;
        
        public ParametroInfo(String valore, String stagione) {
            this.valore = valore;
            this.stagione = stagione != null ? stagione : "";
        }
        
        public String getValore() {
            return valore;
        }
        
        public String getStagione() {
            return stagione;
        }
    }

    private static String sqlEscape(String value) {
        return value == null ? "" : value.replace("'", "''");
    }

    /**
     * Recupera MACC specifico per GroupTech con fallback:
     * 1) stagione richiesta, 2) stagione vuota/null.
     */
    private ParametroInfo resolveMaccByGroupTechAndSeason(String groupTech, String stagione) {
        if (groupTech == null || groupTech.trim().isEmpty()) {
            return null;
        }
        String key = "MACC-" + groupTech.trim().toUpperCase(Locale.ROOT);
        String keyEscaped = sqlEscape(key);
        String stagioneEscaped = sqlEscape(stagione);

        try {
            if (stagione != null && !stagione.trim().isEmpty()) {
                String queryBySeason = "(scope='materiali accessori' or scope='calcolo') and isActive=true and paramKey='" + keyEscaped + "' and stagione='" + stagioneEscaped + "'";
                Page<com.oneclickapp.giglioli.giglioli_preventivi.Parameters> bySeason = parametersService.findAll(
                        queryBySeason, PageRequest.of(0, 1, Sort.by(Sort.Direction.DESC, "modificationTimestamp")));
                if (bySeason != null && !bySeason.getContent().isEmpty()) {
                    com.oneclickapp.giglioli.giglioli_preventivi.Parameters p = bySeason.getContent().getFirst();
                    return new ParametroInfo(p.getParamValue(), p.getStagione());
                }
            }

            String queryFallback = "(scope='materiali accessori' or scope='calcolo') and isActive=true and paramKey='" + keyEscaped + "' and (stagione is null or stagione='')";
            Page<com.oneclickapp.giglioli.giglioli_preventivi.Parameters> fallback = parametersService.findAll(
                    queryFallback, PageRequest.of(0, 1, Sort.by(Sort.Direction.DESC, "modificationTimestamp")));
            if (fallback != null && !fallback.getContent().isEmpty()) {
                com.oneclickapp.giglioli.giglioli_preventivi.Parameters p = fallback.getContent().getFirst();
                return new ParametroInfo(p.getParamValue(), p.getStagione());
            }
        } catch (Exception e) {
            logger.warn("Errore recupero MACC per key={} stagione={}", key, stagione, e);
        }
        return null;
    }
    
    /**
     * Carica tutti i parametri attivi di un dato scope dalla tabella parameters.
     * Restituisce una mappa param_key -> ParametroInfo (con valore e stagione).
     * Per lo scope {@code calcolo} con stagione valorizzata: solo righe con quella stagione (niente fallback su
     * parametri senza stagione), così non si calcola usando default globali quando manca il set per l'anno/tipo.
     *
     * @param scope Lo scope dei parametri da caricare (es. "calcolo")
     * @param stagione La stagione per filtrare i parametri (es. "2025E"), può essere null
     * @return Mappa chiave -> ParametroInfo dei parametri
     */
    private Map<String, ParametroInfo> getParametriByScope(String scope, String stagione) {
        Map<String, ParametroInfo> params = new HashMap<>();
        try {
            String query = "scope='" + scope + "' and isActive=true";
            if (stagione != null && !stagione.isEmpty()) {
                if ("calcolo".equals(scope)) {
                    query += " and stagione='" + stagione + "'";
                } else {
                    query += " and (stagione='" + stagione + "' or stagione is null or stagione='')";
                }
            }
            
            Page<com.oneclickapp.giglioli.giglioli_preventivi.Parameters> page = parametersService.findAll(
                query, Pageable.unpaged());
            for (com.oneclickapp.giglioli.giglioli_preventivi.Parameters p : page.getContent()) {
                params.put(p.getParamKey(), new ParametroInfo(p.getParamValue(), p.getStagione()));
            }
            logger.debug("Caricati {} parametri per scope '{}' e stagione '{}'", params.size(), scope, stagione);
        } catch (Exception e) {
            logger.error("Errore nel caricamento parametri per scope '{}' e stagione '{}': {}", scope, stagione, e.getMessage());
        }
        return params;
    }
}
