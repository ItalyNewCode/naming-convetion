/*Copyright (c) 2022–2023 oneclickapp.com – Tutti i diritti riservati. 

Il presente software è da considerarsi a tutti gli effetti un’opera intellettuale riservata, contenente informazioni strettamente confidenziali e di esclusiva titolarità di oneclickapp.com, marchio e divisione operativa di Plumma S.R.L.. Qualsiasi utilizzo, riproduzione, distribuzione, comunicazione o divulgazione, totale o parziale, del software o della relativa documentazione, in qualunque forma o modalità, è espressamente vietato se non previamente autorizzato per iscritto da oneclickapp.com o regolato da uno specifico accordo di licenza.

L’utente o licenziatario è vincolato a trattare tutte le informazioni contenute nel software come strettamente confidenziali e a non utilizzarle per scopi diversi da quelli esplicitamente consentiti nel contratto di licenza del codice sorgente sottoscritto con oneclickapp.com, impegnandosi altresì a non divulgarle a terzi senza il previo consenso scritto della stessa.

La proprietà intellettuale del so*/
package com.oneclickapp.giglioli.note;

import com.fasterxml.jackson.core.type.TypeReference;
import com.oneclickapp.giglioli.giglioli_preventivi.NoteStoriche;
import com.oneclickapp.giglioli.giglioli_preventivi.NoteStoricheId;
import com.oneclickapp.giglioli.giglioli_preventivi.service.NoteService;
import com.oneclickapp.giglioli.giglioli_preventivi.service.NoteStoricheService;
import com.oneclickapp.giglioli.note.model.NotaStorica;
import com.wavemaker.commons.json.JSONUtils;
import com.wavemaker.runtime.data.event.EntityPostCreateEvent;
import com.wavemaker.runtime.data.event.EntityPostUpdateEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;


import com.wavemaker.runtime.security.SecurityService;
import com.wavemaker.runtime.service.annotations.ExposeToClient;
import org.springframework.context.event.EventListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

//import com.oneclickapp.giglioli.note.model.*;

/**
 * This is a singleton class with all its public methods exposed as REST APIs via generated controller class.
 * To avoid exposing an API for a particular public method, annotate it with @HideFromClient.
 * <p>
 * Method names will play a major role in defining the Http Method for the generated APIs. For example, a method name
 * that starts with delete/remove, will make the API exposed as Http Method "DELETE".
 * <p>
 * Method Parameters of type primitives (including java.lang.String) will be exposed as Query Parameters &
 * Complex Types/Objects will become part of the Request body in the generated API.
 * <p>
 * NOTE: We do not recommend using method overloading on client exposed methods.
 */
@ExposeToClient
public class Note {

    private static final Logger logger = LoggerFactory.getLogger(Note.class);
    @Autowired
    private NoteService noteService;

    @Autowired
    private NoteStoricheService noteStoricheService;
    @Autowired
    private SecurityService securityService;

    @EventListener

    public void afterNoteEntityCreate(EntityPostCreateEvent<com.oneclickapp.giglioli.giglioli_preventivi.Note> entityPostCreateEvent) throws Exception {

        com.oneclickapp.giglioli.giglioli_preventivi.Note note = entityPostCreateEvent.getEntity();
        logger.info("Nota in creazione con id_ref: {} per tabella {}", note.getIdRefTabella(), note.getTabella());
        NotaStorica notaStorica = new NotaStorica();
        notaStorica.setAnnotazione(note.getAnnotazione());
        notaStorica.setTimestamp(System.currentTimeMillis());
        List<NotaStorica> noteStoricheList = new ArrayList<>();
        noteStoricheList.add(notaStorica);
        NoteStoriche noteStoriche = new NoteStoriche();
        noteStoriche.setIdRefTabella(note.getIdRefTabella());
        noteStoriche.setTabella(note.getTabella());
        noteStoriche.setStorico(JSONUtils.toJSON(noteStoricheList));
        noteStoricheService.create(noteStoriche);

    }


    @EventListener
    public void postNoteEntityUpdate(EntityPostUpdateEvent<com.oneclickapp.giglioli.giglioli_preventivi.Note> entityPostUpdateEvent) throws Exception {
        com.oneclickapp.giglioli.giglioli_preventivi.Note note = entityPostUpdateEvent.getEntity();
        logger.info("Nota in aggiornamento con id_ref: {} per tabella {}", note.getIdRefTabella(), note.getTabella());
        NoteStoricheId noteStoricheId = new NoteStoricheId();
        noteStoricheId.setIdRefTabella(note.getIdRefTabella());
        noteStoricheId.setTabella(note.getTabella());
        NoteStoriche storico = noteStoricheService.findById(noteStoricheId);
        logger.info("Recuperato storico note con id_ref: {} per tabella {}", noteStoricheId.getIdRefTabella(), noteStoricheId.getTabella());
        logger.info("STIRCO {}", storico);
        List<NotaStorica> noteStoricheList = new ArrayList<>();
        if (!Objects.isNull(storico)) {
            noteStoricheList = JSONUtils.toObject(storico.getStorico(), new TypeReference<List<NotaStorica>>() {
            });
            noteStoricheList.add(new NotaStorica() {{
                setAnnotazione(note.getAnnotazione());
                setTimestamp(System.currentTimeMillis());
            }});
            storico.setStorico(JSONUtils.toJSON(noteStoricheList));
            noteStoricheService.update(storico);
        } else {
            storico = new NoteStoriche();
            storico.setIdRefTabella(note.getIdRefTabella());
            storico.setTabella(note.getTabella());
            noteStoricheList.add(new NotaStorica() {{
                setAnnotazione(note.getAnnotazione());
                setTimestamp(System.currentTimeMillis());
            }});
            storico.setStorico(JSONUtils.toJSON(noteStoricheList));
            noteStoricheService.create(storico);
        }

    }


    public List<NotaStorica> getStoricoNote(NoteStoricheId noteStoricheId) throws Exception {
        logger.info("getStoricoNote chiamato per tabella: {}, idRefTabella: {}", noteStoricheId.getTabella(), noteStoricheId.getIdRefTabella());
        NoteStoriche storico = noteStoricheService.findById(noteStoricheId);
        if (!Objects.isNull(storico)) {
            logger.info("Storico trovato, JSON: {}", storico.getStorico());
            List<NotaStorica> noteStoricheList = JSONUtils.toObject(storico.getStorico(), new TypeReference<List<NotaStorica>>() {
            });
            logger.info("Deserializzate {} note", noteStoricheList.size());
            // Popola tabella e idRefTabella in ogni NotaStorica
            noteStoricheList.forEach(nota -> {
                nota.setTabella(noteStoricheId.getTabella());
                nota.setIdRefTabella(noteStoricheId.getIdRefTabella());
            });
            List<NotaStorica> result = noteStoricheList.stream().sorted(Comparator.comparingLong(NotaStorica::getTimestamp).reversed()).toList();
            logger.info("Restituite {} note ordinate", result.size());
            return result;
        } else {
            logger.warn("Nessuno storico trovato per tabella: {}, idRefTabella: {}", noteStoricheId.getTabella(), noteStoricheId.getIdRefTabella());
            return new ArrayList<>();
        }
    }

    public boolean deleteNotaStorica(String tabella, Integer idRefTabella, Long timestamp) throws Exception {
        logger.info("Eliminazione nota storica - tabella: {}, idRefTabella: {}, timestamp: {}", tabella, idRefTabella, timestamp);
        
        NoteStoricheId noteStoricheId = new NoteStoricheId();
        noteStoricheId.setTabella(tabella);
        noteStoricheId.setIdRefTabella(idRefTabella);
        
        NoteStoriche storico = noteStoricheService.findById(noteStoricheId);
        if (Objects.isNull(storico)) {
            logger.warn("Nessuno storico trovato per tabella: {}, idRefTabella: {}", tabella, idRefTabella);
            return false;
        }
        
        // Deserializza lo storico JSON
        List<NotaStorica> noteStoricheList = JSONUtils.toObject(storico.getStorico(), new TypeReference<List<NotaStorica>>() {
        });
        
        // Rimuovi solo la nota con il timestamp specificato
        boolean removed = noteStoricheList.removeIf(nota -> nota.getTimestamp().equals(timestamp));
        
        if (removed) {
            if (noteStoricheList.isEmpty()) {
                // Se non ci sono più note, elimina l'intero record
                noteStoricheService.delete(noteStoricheId);
                logger.info("Eliminato record NoteStoriche completo (nessuna nota rimanente)");
            } else {
                // Altrimenti aggiorna lo storico senza la nota eliminata
                storico.setStorico(JSONUtils.toJSON(noteStoricheList));
                noteStoricheService.update(storico);
                logger.info("Aggiornato storico note - rimangono {} note", noteStoricheList.size());
            }
            return true;
        } else {
            logger.warn("Nota con timestamp {} non trovata nello storico", timestamp);
            return false;
        }
    }
}
