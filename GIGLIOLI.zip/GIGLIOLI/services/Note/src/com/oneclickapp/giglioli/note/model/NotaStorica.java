/*Copyright (c) 2022–2023 oneclickapp.com – Tutti i diritti riservati.

Il presente software è da considerarsi a tutti gli effetti un’opera intellettuale riservata, contenente informazioni strettamente confidenziali e di esclusiva titolarità di oneclickapp.com, marchio e divisione operativa di Plumma S.R.L.. Qualsiasi utilizzo, riproduzione, distribuzione, comunicazione o divulgazione, totale o parziale, del software o della relativa documentazione, in qualunque forma o modalità, è espressamente vietato se non previamente autorizzato per iscritto da oneclickapp.com o regolato da uno specifico accordo di licenza.

L’utente o licenziatario è vincolato a trattare tutte le informazioni contenute nel software come strettamente confidenziali e a non utilizzarle per scopi diversi da quelli esplicitamente consentiti nel contratto di licenza del codice sorgente sottoscritto con oneclickapp.com, impegnandosi altresì a non divulgarle a terzi senza il previo consenso scritto della stessa.

La proprietà intellettuale del so*/
package com.oneclickapp.giglioli.note.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "tabella",
        "idRefTabella",
        "timestamp",
        "annotazione"
})
public class NotaStorica {

    @JsonProperty("tabella")
    public String tabella;
    @JsonProperty("idRefTabella")
    public Integer idRefTabella;
    @JsonProperty("timestamp")
    public Long timestamp;
    @JsonProperty("annotazione")
    public String annotazione;
    
    @JsonProperty("tabella")
    public String getTabella() {
        return tabella;
    }
    @JsonProperty("tabella")
    public void setTabella(String tabella) {
        this.tabella = tabella;
    }
    @JsonProperty("idRefTabella")
    public Integer getIdRefTabella() {
        return idRefTabella;
    }
    @JsonProperty("idRefTabella")
    public void setIdRefTabella(Integer idRefTabella) {
        this.idRefTabella = idRefTabella;
    }
    @JsonProperty("timestamp")
    public Long getTimestamp() {
        return timestamp;
    }
    @JsonProperty("timestamp")
    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
    @JsonProperty("annotazione")
    public String getAnnotazione() {
        return annotazione;
    }
    @JsonProperty("annotazione")
    public void setAnnotazione(String annotazione) {
        this.annotazione = annotazione;
    }
}
