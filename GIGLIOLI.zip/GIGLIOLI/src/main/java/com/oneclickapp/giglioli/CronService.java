package com.oneclickapp.giglioli;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.oneclickapp.giglioli.ana01.model.ResponseDatiEntryItem;
import com.oneclickapp.giglioli.ana01.service.Ana01Service;
import com.oneclickapp.giglioli.eventi.QueueMessages;
import com.oneclickapp.giglioli.eventi.service.QueueMessagesService;
import com.oneclickapp.giglioli.giglioli_preventivi.Articoli;
import com.oneclickapp.giglioli.giglioli_preventivi.Bom;
import com.oneclickapp.giglioli.giglioli_preventivi.Schede;
import com.oneclickapp.giglioli.giglioli_preventivi.ListinoMateriali;
import com.oneclickapp.giglioli.giglioli_preventivi.service.ArticoliService;
import com.oneclickapp.giglioli.giglioli_preventivi.service.BomService;
import com.oneclickapp.giglioli.giglioli_preventivi.service.ListinoMaterialiService;
import com.oneclickapp.giglioli.giglioli_preventivi.service.SchedeService;
import com.oneclickapp.giglioli.ste01.model.ResponseMaterialiEntryItem;
import com.wavemaker.commons.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;


import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@EnableScheduling
public class CronService {
    private static final Logger logger = LoggerFactory.getLogger(CronService.class);
    @Autowired
    private QueueMessagesService queueMessagesService;

    @Autowired
    private Ana01Service ana01Service;

    @Autowired
    private BomService bomDBService;


    @Autowired
    private com.oneclickapp.giglioli.ste01.service.Ste01Service ste01RestService;

    @Autowired
    private ArticoliService articoliService;
    @Autowired
    private SchedeService schedeService;
    @Autowired
    private ListinoMaterialiService listinoMaterialiService;

    /**
     * Job schedulato che processa i messaggi in coda relativi alle schede tecniche.
     *
     * <p>
     * Il metodo viene eseguito periodicamente e svolge le seguenti operazioni:
     * </p>
     * <ul>
     *     <li>Recupera il primo messaggio non processato e non bloccato dalla coda {@link QueueMessages}</li>
     *     <li>Applica un lock temporaneo al messaggio per evitare elaborazioni concorrenti</li>
     *     <li>Invoca il servizio ANA01 per ottenere i dati dell'articolo</li>
     *     <li>Crea e persiste l'entità {@link Articoli}</li>
     *     <li>Invoca il servizio STE01 per recuperare la BOM associata</li>
     *     <li>Serializza la BOM in formato JSON e la persiste su database</li>
     *     <li>Marca il messaggio come processato e rimuove il lock</li>
     * </ul>
     *
     * <p>
     * Il metodo è eseguito all'interno di una transazione sul transaction manager
     * {@code GIGLIOLI_PREVENTIVITransactionManager}.
     * </p>
     *
     * <p>
     * In caso di risorsa non trovata, l'errore viene loggato come warning.
     * Eventuali errori di serializzazione JSON vengono rilanciati come {@link RuntimeException}.
     * </p>
     */
    @Scheduled(fixedRate = 30000) //milliseconds
    @Transactional(value = "GIGLIOLI_PREVENTIVITransactionManager")
    public void run() {
        logger.info("CronService.run() called");

        try {
            // ── 1. TIMESTAMP ──────────────────────────────────────────────────────────
            // Calcola il timestamp corrente e quello di scadenza del lock (+ 120 secondi).
            // Il lock serve a evitare che due istanze concorrenti elaborino lo stesso messaggio.
            long currentMillis = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            String currentTime = sdf.format(new Date(currentMillis));
            // Calcola il timestamp di scadenza del lock (120 secondi dopo)
            String lockExpiresTime = sdf.format(new Date(currentMillis + 120000L));
            Timestamp currentTimestamp = Timestamp.valueOf(currentTime);

            // ── 2. LETTURA MESSAGGIO DALLA CODA ───────────────────────────────────────
            // Prende il messaggio più vecchio non ancora processato e senza lock attivo
            // (o con lock scaduto). Il filtro codiceSchedaTecnica>100000 esclude codici non validi.
            Sort sort = Sort.by(Sort.Direction.ASC, "createdTimestamp");
            Pageable pageable = PageRequest.of(0, 1, sort);

            QueueMessages queueMessages = queueMessagesService.findAll("(lockedTimestamp is null or lockExpiresTimestamp < '" + currentTimestamp + "') and processedTimestamp is null and codiceSchedaTecnica>100000", pageable).getContent().getFirst();
            String codiceSchedaTecnica = queueMessages.getCodiceSchedaTecnica().trim();
            String tipoModifica = queueMessages.getTipoModifica().trim();

            // ── 3. ACQUISIZIONE LOCK ──────────────────────────────────────────────────
            // Blocca il messaggio impostando lockedTimestamp, lockExpiresTimestamp e lockedBy,
            // così altri thread/istanze non lo processeranno contemporaneamente.
            logger.debug("(CronService) Locked timestamp: " + Timestamp.valueOf(currentTime));

            queueMessages.setLockedTimestamp(Timestamp.valueOf(currentTime));
            queueMessages.setLockExpiresTimestamp(Timestamp.valueOf(lockExpiresTime));
            queueMessages.setLockedBy("cronservice");
            queueMessagesService.update(queueMessages);

            // ── 4. CHIAMATA REST ANA01: DATI ANAGRAFICI ARTICOLO ──────────────────────
            // Invoca il servizio esterno ANA01 per ottenere i dati dell'articolo
            // corrispondente al codice scheda tecnica letto dalla coda.

            List<ResponseDatiEntryItem> result = ana01Service.invoke(codiceSchedaTecnica).getDati();

            if (!(result.isEmpty() || result.getFirst() == null)) {

                logger.debug("(Cron Service) Recuperato via rest codiceSchedaTecnica: {} , tipoModifica: {} - lunghezza {}", codiceSchedaTecnica, tipoModifica, result.size());
                logger.debug("(Cron Service) RESULT : {}", result.toString());
                
                // ── 5. CONTROLLO DUPLICATO ────────────────────────────────────────────
                // Se l'articolo è già presente in DB, segna il messaggio come processato
                // e termina senza inserire nulla, evitando duplicati.
                String articoloCodice = result.getFirst().getARTICOLO() != null ? result.getFirst().getARTICOLO() : "---";
                logger.info(" (Cron Service)Processing codiceSchedaTecnica: " + codiceSchedaTecnica + ", tipoModifica: " + tipoModifica+ " articolo {}",articoloCodice);
                List<Articoli> articoliEsistenti = articoliService.findAll("articolo = '" + articoloCodice + "'", null).getContent();
                
                if (!articoliEsistenti.isEmpty()) {
                    // Articolo esiste già, lo salto
                    logger.debug("(Cron Service) Articolo {} già esistente, salto l'elaborazione", articoloCodice);
                    queueMessages.setProcessedTimestamp(Timestamp.valueOf(currentTime));
                    queueMessages.setLockedBy("");
                    queueMessages.setLockedTimestamp(null);
                    queueMessages.setLockExpiresTimestamp(null);
                    queueMessagesService.update(queueMessages);
                    return;
                }
                
                // ── 6. CREAZIONE NUOVO ARTICOLO ───────────────────────────────────────
                // Mappa i campi della risposta ANA01 sull'entità Articoli.
                // Per ogni campo viene usato "---" come valore di fallback se il dato è null.
                logger.info("(Cron Service) Nuovo articolo {}, eseguo CREATE", articoloCodice);
                Articoli articoli = new Articoli();
                articoli.setDescrizione(result.getFirst().getDESCRIZIONE() != null ? result.getFirst().getDESCRIZIONE() : "---");
                articoli.setCampione(result.getFirst().getCAMPIONE() != null ? result.getFirst().getCAMPIONE() : "---");
                articoli.setArticolo(articoloCodice);
                articoli.setClienteArticolo(result.getFirst().getCLIENTEARTICOLO() != null ? result.getFirst().getCLIENTEARTICOLO() : "---");
                articoli.setClienteCodice(result.getFirst().getCLIENTECODICE() != null ? result.getFirst().getCLIENTECODICE() : "---");
                articoli.setScatola(result.getFirst().getSCATOLA() != null ? result.getFirst().getSCATOLA() : "---");
                articoli.setSchedaId(result.getFirst().getSCHEDA() != null ? result.getFirst().getSCHEDA() : 0);
                articoli.setStagioneTipo(result.getFirst().getSTAGIONETIPO() != null ? result.getFirst().getSTAGIONETIPO() : "---");
                // Per l'anno stagione il fallback è l'anno corrente invece di "---"
                articoli.setStagioneAnno(result.getFirst().getSTAGIONANNO() != null ? result.getFirst().getSTAGIONANNO().shortValue() : (short) LocalDate.now().getYear());
                articoli.setBrand(result.getFirst().getLOGO() != null ? result.getFirst().getLOGO() : "---");
                articoli.setDescrizioneInterna(result.getFirst().getDESCRIZIONEINTERNA() != null ? result.getFirst().getDESCRIZIONEINTERNA() : "---");
                articoli.setForma(result.getFirst().getFORMA() != null ? result.getFirst().getFORMA() : "---");
                articoli.setModellistaCodice(result.getFirst().getMODELLISTACODICE() != null ? result.getFirst().getMODELLISTACODICE() : "---");
                articoli.setModellistaNome(result.getFirst().getMODELLISTANOME() != null ? result.getFirst().getMODELLISTANOME() : "---");
                articoli.setGrouptech(result.getFirst().getGROUPTECH() != null ? result.getFirst().getGROUPTECH() : "---");
                articoli.setClienteRagioneSociale(result.getFirst().getCLIENTERAGIONESOCIALE() != null ? result.getFirst().getCLIENTERAGIONESOCIALE() : "---");
                articoli.setIndustrializzato(result.getFirst().getINDUSTRIALIZZATO() != null ? result.getFirst().getINDUSTRIALIZZATO() : "---");
                articoli.setLogo("---");
                
                // ── 7. CHIAMATA REST STE01: SALVATAGGIO BOM ───────────────────────────
                // Invoca STE01, serializza l'intera risposta in JSON (snake_case)
                // e la persiste nella tabella BOM collegata all'articolo appena creato.
                Articoli art = articoliService.create(articoli);
                logger.debug("(Cron Service) Caricamento BOM per articolo :  {} ", codiceSchedaTecnica);
                ObjectWriter ow = new ObjectMapper().setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE).writer();
                String bomJson = ow.writeValueAsString(ste01RestService.invoke(codiceSchedaTecnica).getDati());
                Bom bom = new Bom();
                bom.setBom(bomJson);
                bom.setArticoli(art);
                bomDBService.create(bom);
                logger.debug("(Cron Service) Persistenza BOM per articolo : {} eseguita", codiceSchedaTecnica);
                
                // Aggiorna listino_materiali con i dati da ste01
                // ── 8. AGGIORNAMENTO LISTINO MATERIALI ───────────────────────────────
                // Per ogni materiale nella BOM, se esiste già un record in listino_materiali
                // con lo stesso elemento e fornitore, aggiorna descrizione e unità di misura.
                // Gli errori su singoli materiali vengono loggati senza interrompere il ciclo.
                List<ResponseMaterialiEntryItem> materiali = ste01RestService.invoke(codiceSchedaTecnica).getDati().getMateriali();
                logger.debug("(Cron Service) Aggiornamento listino_materiali per articolo : {} - {} materiali trovati", codiceSchedaTecnica, materiali.size());
                for (ResponseMaterialiEntryItem materiale : materiali) {
                    try {
                        if (materiale.getElemento() != null && materiale.getFornitoreTerzistaCodice() != null) {
                            // Cerca il record esistente per elemento e fornitore
                            String query = "elemento = '" + materiale.getElemento() + "' and fornitore = " + materiale.getFornitoreTerzistaCodice();
                            List<ListinoMateriali> esistenti = listinoMaterialiService.findAll(query, null).getContent();
                            
                            if (!esistenti.isEmpty()) {
                                // partialUpdate: solo campi descrittivi (evita flush su colonne generated come pum2).
                                ListinoMateriali listinoMateriale = esistenti.get(0);
                                Map<String, Object> patch = new HashMap<>();
                                patch.put("descrizioneMateriale", materiale.getDescrizione());
                                patch.put("descrizioneFornitore", materiale.getFornitoreTerzista());
                                patch.put("um1", materiale.getUM());
                                listinoMaterialiService.partialUpdate(listinoMateriale.getId(), patch);
                                logger.debug("(Cron Service) Aggiornato listino_materiali per elemento: {} fornitore: {}", materiale.getElemento(), materiale.getFornitoreTerzistaCodice());
                            } else {
                                logger.info("(Cron Service) Nessun record trovato in listino_materiali per elemento: {} fornitore: {}", materiale.getElemento(), materiale.getFornitoreTerzistaCodice());
                            }
                        }
                    } catch (Exception e) {
                        logger.info("(Cron Service) Errore aggiornamento listino_materiali per elemento: {} - {}", materiale.getElemento(), e);
                    }
                }
                // Fine \ Aggiorna listino_materiali con i dati da ste01

                // ── 9. CREAZIONE SCHEDA TECNICA (SE NON ESISTE) ───────────────────────
                // Verifica se la scheda è già presente in DB usando l'ID ricavato dall'articolo.
                // La descrizione viene troncata a 245 caratteri se troppo lunga.
                // Verifica se la scheda esiste già
                List<Schede> schedeEsistenti = schedeService.findAll("id = " + art.getSchedaId(), null).getContent();
                
                if (schedeEsistenti.isEmpty()) {
                    // CREATE: nuova scheda
                    Schede scheda = new Schede();
                    scheda.setCodice("ARTICOLO-" + art.getArticolo());
                    scheda.setId(art.getSchedaId());
                    scheda.setDescrizione((art.getDescrizione() + " - " + art.getDescrizioneInterna()).length() > 245 ? (art.getDescrizione() + " - " + art.getDescrizioneInterna()).substring(0, 245) : art.getDescrizione() + " - " + art.getDescrizioneInterna() + "...");
                    schedeService.create(scheda);
                    logger.debug("(Cron Service) Persistenza scheda per articolo : {} eseguita", codiceSchedaTecnica);
                } else {
                    logger.info("(Cron Service) Scheda {} già esistente, salto la creazione", art.getSchedaId());
                }

                // ── 10. MARK AS DONE: rimozione lock e marcatura processato ──────────
                // Azzeramento di tutti i campi di lock e impostazione di processedTimestamp:
                // il messaggio non verrà più prelevato dalla coda nei cicli successivi.
                queueMessages.setProcessedTimestamp(Timestamp.valueOf(currentTime));
                queueMessages.setLockedBy("");
                queueMessages.setLockedTimestamp(null);
                queueMessages.setLockExpiresTimestamp(null);
                queueMessagesService.update(queueMessages);
            } else {
                // ANA01 non ha restituito dati validi per questo codice scheda tecnica
                logger.debug("(Cron Service) Empty codiceSchedaTecnica: " + codiceSchedaTecnica + ", tipoModifica: " + tipoModifica);
            }

        // ── 11. GESTIONE ECCEZIONI ────────────────────────────────────────────────
        } catch (DataIntegrityViolationException e) {
            // Violazione di vincolo DB (es. chiave duplicata): non è critico,
            // può accadere in caso di race condition tra istanze concorrenti.
            logger.info("(Cron Service) Warning in CronService.run() duplicate entry {}",e);
        } catch (ResourceNotFoundException e) {
            // Risorsa non trovata: condizione normale quando la coda è vuota
            // o un servizio REST risponde con 404.
            logger.info("(Cron Service) Warning in CronService.run()", e);
        } catch (JsonProcessingException e) {
            // Errore nella serializzazione JSON della BOM.
            logger.info("(Cron Service) Warning in CronService.run()", e);
        } catch (Exception e) {
            // Qualunque altro errore imprevisto: loggato per non bloccare
            // il job, che riprenderà normalmente al prossimo ciclo schedulato.
            logger.info("(Cron Service) Warning in CronService.run()",e);
        }

    }
}
