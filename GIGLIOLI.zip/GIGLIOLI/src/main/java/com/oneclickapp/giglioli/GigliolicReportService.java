package com.oneclickapp.giglioli;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JsonDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;

import java.io.*;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;
import java.util.zip.*;

public class GigliolicReportService {

    public static byte[] generateGiglioliPdf(String jsonData, byte[] jasperZip)
            throws JRException, IOException {

        // 1. Estrai lo ZIP in una directory temporanea
        Path tempDir = Files.createTempDirectory("jasper_giglioli_");

        try {
            // 2. Decomprimi tutti i .jasper flat nella tempDir
            try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(jasperZip))) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    if (entry.isDirectory()) { zis.closeEntry(); continue; }
                    String fileName = new File(entry.getName()).getName();
                    File outFile = tempDir.resolve(fileName).toFile();
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        byte[] buffer = new byte[4096];
                        int len;
                        while ((len = zis.read(buffer)) > 0) fos.write(buffer, 0, len);
                    }
                    zis.closeEntry();
                }
            }

            // 3. URLClassLoader puntato alla tempDir per la risoluzione dei subreport
            URLClassLoader tempClassLoader = new URLClassLoader(
                    new java.net.URL[]{ tempDir.toUri().toURL() },
                    Thread.currentThread().getContextClassLoader()
            );

            ClassLoader originalClassLoader = Thread.currentThread().getContextClassLoader();
            Thread.currentThread().setContextClassLoader(tempClassLoader);

            try {
                // 4. Carica il report principale
                JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile(
                        tempDir.resolve("GIGLIOLI.jasper").toAbsolutePath().toString()
                );

                // 5. Crea il JsonDataSource dalla stringa JSON
                byte[] jsonBytes = jsonData.getBytes(StandardCharsets.UTF_8);
                JsonDataSource dataSource = new JsonDataSource(new ByteArrayInputStream(jsonBytes));

                // 6. CHIAVE: passa il JsonDataSource ESPLICITAMENTE come REPORT_DATA_SOURCE.
                //    Il JRXML fa un cast esplicito:
                //    ((net.sf.jasperreports.engine.data.JsonDataSource)$P{REPORT_DATA_SOURCE}).subDataSource(...)
                //    Se non lo passiamo come parametro, JasperReports lo wrappa internamente
                //    e il cast fallisce silenziosamente — i subreport risultano vuoti.
                Map<String, Object> parameters = new HashMap<>();
                parameters.put(JRParameter.REPORT_DATA_SOURCE, dataSource);

                // 7. Fill — dataSource passato sia come parametro che come terzo argomento
                //    per garantire compatibilità con entrambi i meccanismi interni
                JasperPrint jasperPrint = JasperFillManager.fillReport(
                        jasperReport,
                        parameters,
                        new JsonDataSource(new ByteArrayInputStream(jsonBytes))
                );

                // 8. Export PDF
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                JRPdfExporter exporter = new JRPdfExporter();
                exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
                exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
                SimplePdfExporterConfiguration pdfConfig = new SimplePdfExporterConfiguration();
                pdfConfig.setCompressed(true);
                exporter.setConfiguration(pdfConfig);
                exporter.exportReport();

                return outputStream.toByteArray();

            } finally {
                Thread.currentThread().setContextClassLoader(originalClassLoader);
                tempClassLoader.close();
            }

        } finally {
            // 9. Pulizia tempDir
            try (Stream<Path> walk = Files.walk(tempDir)) {
                walk.sorted(Comparator.reverseOrder())
                        .map(Path::toFile)
                        .forEach(File::delete);
            } catch (IOException ignored) {}
        }
    }
}
