package com.oneclickapp.giglioli;

import com.oneclickapp.giglioli.models.master.ArticoloMaster;
import com.oneclickapp.giglioli.models.master.Master;
import com.oneclickapp.giglioli.models.master.Scheda;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

public class MasterExcelExporter {

    public  byte[] export(List<Master> masters) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Master View");

            // ── Stile header ──────────────────────────────────────────────
            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);

            // ── Intestazioni ──────────────────────────────────────────────
            String[] headers = {
                    // ── Master ──
                    "progetto_index", "progetto", "group_tecnology", "brand",
                    // ── Scheda ──
                    "scheda_numero", "scheda_stagione",
                    // ── Articolo ──
                    "id", "articolo", "cliente_codice", "cliente_articolo",
                    "scatola", "scheda_id", "stagione_tipo", "stagione_anno",
                    "campione", "industrializzato", "logo",
                    "cliente_ragione_sociale", "descrizione", "descrizione_interna",
                    "forma", "modellista_codice", "modellista_nome",
                    "grouptech", "brand_articolo",
                    "euro_proposto",
                    "creation_timestamp", "modification_timestamp",
                    // flags
                    "flag_articolo"
            };

            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // ── Righe dati ────────────────────────────────────────────────
            int rowIndex = 1;

            for (Master master : masters) {
                List<Scheda> schede = master.getSchede();

                if (schede == null || schede.isEmpty()) {
                    Row row = sheet.createRow(rowIndex++);
                    writeMasterCells(row, master);
                    continue;
                }

                for (Scheda scheda : schede) {
                    List<ArticoloMaster> articoli = scheda.getArticoli();

                    if (articoli == null || articoli.isEmpty()) {
                        Row row = sheet.createRow(rowIndex++);
                        writeMasterCells(row, master);
                        writeSchedaCells(row, scheda);
                        continue;
                    }

                    for (ArticoloMaster articolo : articoli) {
                        Row row = sheet.createRow(rowIndex++);
                        writeMasterCells(row, master);
                        writeSchedaCells(row, scheda);
                        writeArticoloCells(row, articolo);
                    }
                }
            }

            // ── Auto-size ─────────────────────────────────────────────────
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            workbook.write(out);
            return out.toByteArray();
        }
    }

    // ── Master: colonne 0-3 ───────────────────────────────────────────────
    private void writeMasterCells(Row row, Master m) {
        set(row, 0, m.getProgettoIndex());
        set(row, 1, m.getProgetto());
        set(row, 2, m.getGroupTecnology());
        set(row, 3, m.getBrand());
    }

    // ── Scheda: colonne 4-5 ───────────────────────────────────────────────
    private void writeSchedaCells(Row row, Scheda s) {
        set(row, 4, s.getNumero());
        set(row, 5, s.getStagione());
    }

    // ── ArticoloMaster: colonne 6-27 ──────────────────────────────────────
    // Adatta il cast al tipo reale di ArticoloMaster nel tuo progetto.
    // Se ArticoloMaster estende/wrappa Articoli, usa i getter diretti.
    private void writeArticoloCells(Row row, ArticoloMaster a) {
        set(row, 6,  "-");
        set(row, 7,  a.getArticolo());
        set(row, 8,  a.getClienteCodice());
        set(row, 9,  a.getClienteArticolo());
        set(row, 10, a.getScatola());
        set(row, 11, "-");
        set(row, 12, a.getStagioneTipo());
        set(row, 13, a.getStagioneAnno());
        set(row, 14, a.getCampione());
        set(row, 15, a.getIndustrializzato());
        set(row, 16, "-");
        set(row, 17, a.getClienteRagioneSociale());
        set(row, 18, a.getDescrizione());
        set(row, 19, a.getDescrizioneInterna());
        set(row, 20, a.getForma());
        set(row, 21, a.getModellistaCodice());
        set(row, 22, a.getModellistaNome());
        set(row, 23, "-");
        set(row, 24, "-");
        set(row, 25, a.getEuroProposto());
        set(row, 26, a.getCreationTimestamp());
        set(row, 27, a.getModificationTimestamp());
        set (row,28, a.getFlagCalcolo());
    }

    // ── Helper overloaded: gestisce String, Number, Object → toString ─────
    private void set(Row row, int col, String val) {
        row.createCell(col).setCellValue(val != null ? val : "");
    }

    private void set(Row row, int col, Number val) {
        Cell cell = row.createCell(col);
        if (val != null) {
            cell.setCellValue(val.doubleValue());
        } else {
            cell.setCellValue("");
        }
    }

    private void set(Row row, int col, Object val) {
        row.createCell(col).setCellValue(val != null ? val.toString() : "");
    }
}
