
package com.oneclickapp.giglioli.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


/**
 * ArticoloPreventivo
 * <p>
 * 
 * 
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "CODICE",
    "TIPO",
    "DESCRIZIONE",
    "CLIENTE",
    "STATO",
    "DATA_STATO",
    "ESITO",
    "FLAG",
    "MINUTI",
    "PAREGGIO",
    "OBIETTIVO",
    "PROPOSTO",
    "ASSORBITO",
    "MARGINE_PERC",
    "MVA",
    "MODIFICHE",
    "DATA_COMUNICAZIONE"
})

public class Articolo {

    public Articolo() {
    }

    public Articolo(String codice, String tipo, String descrizione, String cliente, String stato, String dataStato, String esito, String flag, Double minuti, Double pareggio, Double obiettivo, Double proposto, Double assorbito, Double marginePerc, Double mva, String modifiche, String dataComunicazione) {
        super();
        this.codice = codice;
        this.tipo = tipo;
        this.descrizione = descrizione;
        this.cliente = cliente;
        this.stato = stato;
        this.dataStato = dataStato;
        this.esito = esito;
        this.flag = flag;
        this.minuti = minuti;
        this.pareggio = pareggio;
        this.obiettivo = obiettivo;
        this.proposto = proposto;
        this.assorbito = assorbito;
        this.marginePerc = marginePerc;
        this.mva = mva;
        this.modifiche = modifiche;
        this.dataComunicazione = dataComunicazione;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("CODICE")
    private String codice;
    @JsonProperty("TIPO")
    private String tipo;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("DESCRIZIONE")
    private String descrizione;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("CLIENTE")
    private String cliente;
    @JsonProperty("STATO")
    private String stato;
    @JsonProperty("DATA_STATO")
    private String dataStato;
    @JsonProperty("ESITO")
    private String esito;
    @JsonProperty("FLAG")
    private String flag;
    @JsonProperty("MINUTI")
    private Double minuti;
    @JsonProperty("PAREGGIO")
    private Double pareggio;
    @JsonProperty("OBIETTIVO")
    private Double obiettivo;
    @JsonProperty("PROPOSTO")
    private Double proposto;
    @JsonProperty("ASSORBITO")
    private Double assorbito;
    @JsonProperty("MARGINE_PERC")
    private Double marginePerc;
    @JsonProperty("MVA")
    private Double mva;
    @JsonProperty("MODIFICHE")
    private String modifiche;
    @JsonProperty("DATA_COMUNICAZIONE")
    private String dataComunicazione;

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("CODICE")
    public String getCodice() {
        return codice;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("CODICE")
    public void setCodice(String codice) {
        this.codice = codice;
    }

    @JsonProperty("TIPO")
    public String getTipo() {
        return tipo;
    }

    @JsonProperty("TIPO")
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("DESCRIZIONE")
    public String getDescrizione() {
        return descrizione;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("DESCRIZIONE")
    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("CLIENTE")
    public String getCliente() {
        return cliente;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("CLIENTE")
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    @JsonProperty("STATO")
    public String getStato() {
        return stato;
    }

    @JsonProperty("STATO")
    public void setStato(String stato) {
        this.stato = stato;
    }

    @JsonProperty("DATA_STATO")
    public String getDataStato() {
        return dataStato;
    }

    @JsonProperty("DATA_STATO")
    public void setDataStato(String dataStato) {
        this.dataStato = dataStato;
    }

    @JsonProperty("ESITO")
    public String getEsito() {
        return esito;
    }

    @JsonProperty("ESITO")
    public void setEsito(String esito) {
        this.esito = esito;
    }

    @JsonProperty("FLAG")
    public String getFlag() {
        return flag;
    }

    @JsonProperty("FLAG")
    public void setFlag(String flag) {
        this.flag = flag;
    }

    @JsonProperty("MINUTI")
    public Double getMinuti() {
        return minuti;
    }

    @JsonProperty("MINUTI")
    public void setMinuti(Double minuti) {
        this.minuti = minuti;
    }

    @JsonProperty("PAREGGIO")
    public Double getPareggio() {
        return pareggio;
    }

    @JsonProperty("PAREGGIO")
    public void setPareggio(Double pareggio) {
        this.pareggio = pareggio;
    }

    @JsonProperty("OBIETTIVO")
    public Double getObiettivo() {
        return obiettivo;
    }

    @JsonProperty("OBIETTIVO")
    public void setObiettivo(Double obiettivo) {
        this.obiettivo = obiettivo;
    }

    @JsonProperty("PROPOSTO")
    public Double getProposto() {
        return proposto;
    }

    @JsonProperty("PROPOSTO")
    public void setProposto(Double proposto) {
        this.proposto = proposto;
    }

    @JsonProperty("ASSORBITO")
    public Double getAssorbito() {
        return assorbito;
    }

    @JsonProperty("ASSORBITO")
    public void setAssorbito(Double assorbito) {
        this.assorbito = assorbito;
    }

    @JsonProperty("MARGINE_PERC")
    public Double getMarginePerc() {
        return marginePerc;
    }

    @JsonProperty("MARGINE_PERC")
    public void setMarginePerc(Double marginePerc) {
        this.marginePerc = marginePerc;
    }

    @JsonProperty("MVA")
    public Double getMva() {
        return mva;
    }

    @JsonProperty("MVA")
    public void setMva(Double mva) {
        this.mva = mva;
    }

    @JsonProperty("MODIFICHE")
    public String getModifiche() {
        return modifiche;
    }

    @JsonProperty("MODIFICHE")
    public void setModifiche(String modifiche) {
        this.modifiche = modifiche;
    }

    @JsonProperty("DATA_COMUNICAZIONE")
    public String getDataComunicazione() {
        return dataComunicazione;
    }

    @JsonProperty("DATA_COMUNICAZIONE")
    public void setDataComunicazione(String dataComunicazione) {
        this.dataComunicazione = dataComunicazione;
    }

}
