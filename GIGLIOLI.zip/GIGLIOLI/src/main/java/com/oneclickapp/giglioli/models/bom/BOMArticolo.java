/*Copyright (c) 2022–2023 oneclickapp.com – Tutti i diritti riservati.

Il presente software è da considerarsi a tutti gli effetti un’opera intellettuale riservata, contenente informazioni strettamente confidenziali e di esclusiva titolarità di oneclickapp.com, marchio e divisione operativa di Plumma S.R.L.. Qualsiasi utilizzo, riproduzione, distribuzione, comunicazione o divulgazione, totale o parziale, del software o della relativa documentazione, in qualunque forma o modalità, è espressamente vietato se non previamente autorizzato per iscritto da oneclickapp.com o regolato da uno specifico accordo di licenza.

L’utente o licenziatario è vincolato a trattare tutte le informazioni contenute nel software come strettamente confidenziali e a non utilizzarle per scopi diversi da quelli esplicitamente consentiti nel contratto di licenza del codice sorgente sottoscritto con oneclickapp.com, impegnandosi altresì a non divulgarle a terzi senza il previo consenso scritto della stessa.

La proprietà intellettuale del so*/
package com.oneclickapp.giglioli.models.bom;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "materiali",
    "lavorazioniEsterne",
    "lavorazioniInterne",
    "statoPreventivo",
    "dataStatoPreventivo",
    "esitoCalcolo",
    "bandierina",
    "storicizzato",
    "bloccato",
    "consumoCuoioMq",
    "costoComponenti",
    "minutiLavorazione",
    "manovia",
    "lavorazioniInterneValore",
    "costoScheda",
    "costiGenerali",
    "costoTotale",
    "pareggioPrezzoLordo",
    "pareggioProvvSconti",
    "pareggioPrezzoNetto",
    "pareggioMargine",
    "pareggioMargineContrib",
    "pareggioMcMinuto",
    "obiettivoPrezzoLordo",
    "obiettivoProvvSconti",
    "obiettivoPrezzoNetto",
    "obiettivoMargine",
    "obiettivoMargineContrib",
    "obiettivoMcMinuto",
    "propostoPrezzoLordo",
    "propostoProvvSconti",
    "propostoPrezzoNetto",
    "propostoMargine",
    "propostoMargineContrib",
    "propostoMcMinuto",
    "as400PrezzoLordo",
    "as400ProvvSconti",
    "as400PrezzoNetto",
    "as400Margine",
    "as400MargineContrib",
    "as400McMinuto",
    "defaultListini",
    "matAccessori",
    "costoMinMop",
    "costoMinCge",
    "provv",
    "margineObiett",
    "scontoPremio",
    "matAccessoriStagione",
    "cmopStagione",
    "cgenStagione",
    "provStagione",
    "mobbStagione",
    "scontoPremioStagione"
})

public class BOMArticolo implements Serializable {

    @JsonProperty("materiali")
    private List<Materiali> materiali;
    @JsonProperty("lavorazioniEsterne")
    private List<LavorazioniEsterne> lavorazioniEsterne;
    @JsonProperty("lavorazioniInterne")
    private List<LavorazioniInterne> lavorazioniInterne;
    @JsonProperty("statoPreventivo")
    private String statoPreventivo;
    @JsonProperty("dataStatoPreventivo")
    private String dataStatoPreventivo;
    @JsonProperty("esitoCalcolo")
    private String esitoCalcolo;
    @JsonProperty("bandierina")
    private String bandierina;
    @JsonProperty("storicizzato")
    private Boolean storicizzato;
    @JsonProperty("bloccato")
    private Boolean bloccato;
    @JsonProperty("consumoCuoioMq")
    private Double consumoCuoioMq;
    @JsonProperty("costoComponenti")
    private Double costoComponenti;
    @JsonProperty("minutiLavorazione")
    private Double minutiLavorazione;
    @JsonProperty("manovia")
    private Double manovia;
    @JsonProperty("lavorazioniInterneValore")
    private Double lavorazioniInterneValore;
    @JsonProperty("costoScheda")
    private Double costoScheda;
    @JsonProperty("costiGenerali")
    private Double costiGenerali;
    @JsonProperty("costoTotale")
    private Double costoTotale;
    @JsonProperty("pareggioPrezzoLordo")
    private Double pareggioPrezzoLordo;
    @JsonProperty("pareggioProvvSconti")
    private Float pareggioProvvSconti;
    @JsonProperty("pareggioPrezzoNetto")
    private Double pareggioPrezzoNetto;
    @JsonProperty("pareggioMargine")
    private Double pareggioMargine;
    @JsonProperty("pareggioMargineContrib")
    private Double pareggioMargineContrib;
    @JsonProperty("pareggioMcMinuto")
    private Double pareggioMcMinuto;
    @JsonProperty("obiettivoPrezzoLordo")
    private Double obiettivoPrezzoLordo;
    @JsonProperty("obiettivoProvvSconti")
    private Float obiettivoProvvSconti;
    @JsonProperty("obiettivoPrezzoNetto")
    private Double obiettivoPrezzoNetto;
    @JsonProperty("obiettivoMargine")
    private Double obiettivoMargine;
    @JsonProperty("obiettivoMargineContrib")
    private Double obiettivoMargineContrib;
    @JsonProperty("obiettivoMcMinuto")
    private Double obiettivoMcMinuto;
    @JsonProperty("propostoPrezzoLordo")
    private Double propostoPrezzoLordo;
    @JsonProperty("propostoProvvSconti")
    private Float propostoProvvSconti;
    @JsonProperty("propostoPrezzoNetto")
    private Double propostoPrezzoNetto;
    @JsonProperty("propostoMargine")
    private Double propostoMargine;
    @JsonProperty("propostoMargineContrib")
    private Double propostoMargineContrib;
    @JsonProperty("propostoMcMinuto")
    private Double propostoMcMinuto;
    @JsonProperty("as400PrezzoLordo")
    private Double as400PrezzoLordo;
    @JsonProperty("as400ProvvSconti")
    private Float as400ProvvSconti;
    @JsonProperty("as400PrezzoNetto")
    private Double as400PrezzoNetto;
    @JsonProperty("as400Margine")
    private Double as400Margine;
    @JsonProperty("as400MargineContrib")
    private Double as400MargineContrib;
    @JsonProperty("as400McMinuto")
    private Double as400McMinuto;
    @JsonProperty("defaultListini")
    private String defaultListini;
    @JsonProperty("matAccessori")
    private String matAccessori;
    @JsonProperty("costoMinMop")
    private String costoMinMop;
    @JsonProperty("costoMinCge")
    private String costoMinCge;
    @JsonProperty("provv")
    private String provv;
    @JsonProperty("margineObiett")
    private String margineObiett;
    @JsonProperty("scontoPremio")
    private Double scontoPremio;
    @JsonProperty("matAccessoriStagione")
    private String matAccessoriStagione;
    @JsonProperty("cmopStagione")
    private String cmopStagione;
    @JsonProperty("cgenStagione")
    private String cgenStagione;
    @JsonProperty("provStagione")
    private String provStagione;
    @JsonProperty("mobbStagione")
    private String mobbStagione;
    @JsonProperty("scontoPremioStagione")
    private String scontoPremioStagione;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public BOMArticolo() {
    }

    public BOMArticolo(List<Materiali> materiali, List<LavorazioniEsterne> lavorazioniEsterne, List<LavorazioniInterne> lavorazioniInterne) {
        super();
        this.materiali = materiali;
        this.lavorazioniEsterne = lavorazioniEsterne;
        this.lavorazioniInterne = lavorazioniInterne;
    }

    public BOMArticolo(List<Materiali> materiali, List<LavorazioniEsterne> lavorazioniEsterne, List<LavorazioniInterne> lavorazioniInterne, String statoPreventivo, String dataStatoPreventivo, String esitoCalcolo, String bandierina, Boolean storicizzato, Boolean bloccato, Double consumoCuoioMq, Double costoComponenti, Double minutiLavorazione, Double manovia, Double lavorazioniInterneValore, Double costoScheda, Double costiGenerali, Double costoTotale, Double pareggioPrezzoLordo, Float pareggioProvvSconti, Double pareggioPrezzoNetto, Double pareggioMargine, Double pareggioMargineContrib, Double pareggioMcMinuto, Double obiettivoPrezzoLordo, Float obiettivoProvvSconti, Double obiettivoPrezzoNetto, Double obiettivoMargine, Double obiettivoMargineContrib, Double obiettivoMcMinuto, Double propostoPrezzoLordo, Float propostoProvvSconti, Double propostoPrezzoNetto, Double propostoMargine, Double propostoMargineContrib, Double propostoMcMinuto, Double as400PrezzoLordo, Float as400ProvvSconti, Double as400PrezzoNetto, Double as400Margine, Double as400MargineContrib, Double as400McMinuto, String defaultListini, String matAccessori, String costoMinMop, String costoMinCge, String provv, String margineObiett, Double scontoPremio) {
        super();
        this.materiali = materiali;
        this.lavorazioniEsterne = lavorazioniEsterne;
        this.lavorazioniInterne = lavorazioniInterne;
        this.statoPreventivo = statoPreventivo;
        this.dataStatoPreventivo = dataStatoPreventivo;
        this.esitoCalcolo = esitoCalcolo;
        this.bandierina = bandierina;
        this.storicizzato = storicizzato;
        this.bloccato = bloccato;
        this.consumoCuoioMq = consumoCuoioMq;
        this.costoComponenti = costoComponenti;
        this.minutiLavorazione = minutiLavorazione;
        this.manovia = manovia;
        this.lavorazioniInterneValore = lavorazioniInterneValore;
        this.costoScheda = costoScheda;
        this.costiGenerali = costiGenerali;
        this.costoTotale = costoTotale;
        this.pareggioPrezzoLordo = pareggioPrezzoLordo;
        this.pareggioProvvSconti = pareggioProvvSconti;
        this.pareggioPrezzoNetto = pareggioPrezzoNetto;
        this.pareggioMargine = pareggioMargine;
        this.pareggioMargineContrib = pareggioMargineContrib;
        this.pareggioMcMinuto = pareggioMcMinuto;
        this.obiettivoPrezzoLordo = obiettivoPrezzoLordo;
        this.obiettivoProvvSconti = obiettivoProvvSconti;
        this.obiettivoPrezzoNetto = obiettivoPrezzoNetto;
        this.obiettivoMargine = obiettivoMargine;
        this.obiettivoMargineContrib = obiettivoMargineContrib;
        this.obiettivoMcMinuto = obiettivoMcMinuto;
        this.propostoPrezzoLordo = propostoPrezzoLordo;
        this.propostoProvvSconti = propostoProvvSconti;
        this.propostoPrezzoNetto = propostoPrezzoNetto;
        this.propostoMargine = propostoMargine;
        this.propostoMargineContrib = propostoMargineContrib;
        this.propostoMcMinuto = propostoMcMinuto;
        this.as400PrezzoLordo = as400PrezzoLordo;
        this.as400ProvvSconti = as400ProvvSconti;
        this.as400PrezzoNetto = as400PrezzoNetto;
        this.as400Margine = as400Margine;
        this.as400MargineContrib = as400MargineContrib;
        this.as400McMinuto = as400McMinuto;
        this.defaultListini = defaultListini;
        this.matAccessori = matAccessori;
        this.costoMinMop = costoMinMop;
        this.costoMinCge = costoMinCge;
        this.provv = provv;
        this.margineObiett = margineObiett;
        this.scontoPremio = scontoPremio;
    }

    @JsonProperty("materiali")
    public List<Materiali> getMateriali() {
        return materiali;
    }

    @JsonProperty("materiali")
    public void setMateriali(List<Materiali> materiali) {
        this.materiali = materiali;
    }

    @JsonProperty("lavorazioniEsterne")
    public List<LavorazioniEsterne> getLavorazioniEsterne() {
        return lavorazioniEsterne;
    }

    @JsonProperty("lavorazioniEsterne")
    public void setLavorazioniEsterne(List<LavorazioniEsterne> lavorazioniEsterne) {
        this.lavorazioniEsterne = lavorazioniEsterne;
    }

    @JsonProperty("lavorazioniInterne")
    public List<LavorazioniInterne> getLavorazioniInterne() {
        return lavorazioniInterne;
    }

    @JsonProperty("lavorazioniInterne")
    public void setLavorazioniInterne(List<LavorazioniInterne> lavorazioniInterne) {
        this.lavorazioniInterne = lavorazioniInterne;
    }

    @JsonProperty("statoPreventivo")
    public String getStatoPreventivo() {
        return statoPreventivo;
    }

    @JsonProperty("statoPreventivo")
    public void setStatoPreventivo(String statoPreventivo) {
        this.statoPreventivo = statoPreventivo;
    }

    @JsonProperty("dataStatoPreventivo")
    public String getDataStatoPreventivo() {
        return dataStatoPreventivo;
    }

    @JsonProperty("dataStatoPreventivo")
    public void setDataStatoPreventivo(String dataStatoPreventivo) {
        this.dataStatoPreventivo = dataStatoPreventivo;
    }

    @JsonProperty("esitoCalcolo")
    public String getEsitoCalcolo() {
        return esitoCalcolo;
    }

    @JsonProperty("esitoCalcolo")
    public void setEsitoCalcolo(String esitoCalcolo) {
        this.esitoCalcolo = esitoCalcolo;
    }

    @JsonProperty("bandierina")
    public String getBandierina() {
        return bandierina;
    }

    @JsonProperty("bandierina")
    public void setBandierina(String bandierina) {
        this.bandierina = bandierina;
    }

    @JsonProperty("storicizzato")
    public Boolean getStoricizzato() {
        return storicizzato;
    }

    @JsonProperty("storicizzato")
    public void setStoricizzato(Boolean storicizzato) {
        this.storicizzato = storicizzato;
    }

    @JsonProperty("bloccato")
    public Boolean getBloccato() {
        return bloccato;
    }

    @JsonProperty("bloccato")
    public void setBloccato(Boolean bloccato) {
        this.bloccato = bloccato;
    }

    @JsonProperty("consumoCuoioMq")
    public Double getConsumoCuoioMq() {
        return consumoCuoioMq;
    }

    @JsonProperty("consumoCuoioMq")
    public void setConsumoCuoioMq(Double consumoCuoioMq) {
        this.consumoCuoioMq = consumoCuoioMq;
    }

    @JsonProperty("costoComponenti")
    public Double getCostoComponenti() {
        return costoComponenti;
    }

    @JsonProperty("costoComponenti")
    public void setCostoComponenti(Double costoComponenti) {
        this.costoComponenti = costoComponenti;
    }

    @JsonProperty("minutiLavorazione")
    public Double getMinutiLavorazione() {
        return minutiLavorazione;
    }

    @JsonProperty("minutiLavorazione")
    public void setMinutiLavorazione(Double minutiLavorazione) {
        this.minutiLavorazione = minutiLavorazione;
    }

    @JsonProperty("manovia")
    public Double getManovia() {
        return manovia;
    }

    @JsonProperty("manovia")
    public void setManovia(Double manovia) {
        this.manovia = manovia;
    }

    @JsonProperty("lavorazioniInterneValore")
    public Double getLavorazioniInterneValore() {
        return lavorazioniInterneValore;
    }

    @JsonProperty("lavorazioniInterneValore")
    public void setLavorazioniInterneValore(Double lavorazioniInterneValore) {
        this.lavorazioniInterneValore = lavorazioniInterneValore;
    }

    @JsonProperty("costoScheda")
    public Double getCostoScheda() {
        return costoScheda;
    }

    @JsonProperty("costoScheda")
    public void setCostoScheda(Double costoScheda) {
        this.costoScheda = costoScheda;
    }

    @JsonProperty("costiGenerali")
    public Double getCostiGenerali() {
        return costiGenerali;
    }

    @JsonProperty("costiGenerali")
    public void setCostiGenerali(Double costiGenerali) {
        this.costiGenerali = costiGenerali;
    }

    @JsonProperty("costoTotale")
    public Double getCostoTotale() {
        return costoTotale;
    }

    @JsonProperty("costoTotale")
    public void setCostoTotale(Double costoTotale) {
        this.costoTotale = costoTotale;
    }

    @JsonProperty("pareggioPrezzoLordo")
    public Double getPareggioPrezzoLordo() {
        return pareggioPrezzoLordo;
    }

    @JsonProperty("pareggioPrezzoLordo")
    public void setPareggioPrezzoLordo(Double pareggioPrezzoLordo) {
        this.pareggioPrezzoLordo = pareggioPrezzoLordo;
    }

    @JsonProperty("pareggioProvvSconti")
    public Float getPareggioProvvSconti() {
        return pareggioProvvSconti;
    }

    @JsonProperty("pareggioProvvSconti")
    public void setPareggioProvvSconti(Float pareggioProvvSconti) {
        this.pareggioProvvSconti = pareggioProvvSconti;
    }

    @JsonProperty("pareggioPrezzoNetto")
    public Double getPareggioPrezzoNetto() {
        return pareggioPrezzoNetto;
    }

    @JsonProperty("pareggioPrezzoNetto")
    public void setPareggioPrezzoNetto(Double pareggioPrezzoNetto) {
        this.pareggioPrezzoNetto = pareggioPrezzoNetto;
    }

    @JsonProperty("pareggioMargine")
    public Double getPareggioMargine() {
        return pareggioMargine;
    }

    @JsonProperty("pareggioMargine")
    public void setPareggioMargine(Double pareggioMargine) {
        this.pareggioMargine = pareggioMargine;
    }

    @JsonProperty("pareggioMargineContrib")
    public Double getPareggioMargineContrib() {
        return pareggioMargineContrib;
    }

    @JsonProperty("pareggioMargineContrib")
    public void setPareggioMargineContrib(Double pareggioMargineContrib) {
        this.pareggioMargineContrib = pareggioMargineContrib;
    }

    @JsonProperty("pareggioMcMinuto")
    public Double getPareggioMcMinuto() {
        return pareggioMcMinuto;
    }

    @JsonProperty("pareggioMcMinuto")
    public void setPareggioMcMinuto(Double pareggioMcMinuto) {
        this.pareggioMcMinuto = pareggioMcMinuto;
    }

    @JsonProperty("obiettivoPrezzoLordo")
    public Double getObiettivoPrezzoLordo() {
        return obiettivoPrezzoLordo;
    }

    @JsonProperty("obiettivoPrezzoLordo")
    public void setObiettivoPrezzoLordo(Double obiettivoPrezzoLordo) {
        this.obiettivoPrezzoLordo = obiettivoPrezzoLordo;
    }

    @JsonProperty("obiettivoProvvSconti")
    public Float getObiettivoProvvSconti() {
        return obiettivoProvvSconti;
    }

    @JsonProperty("obiettivoProvvSconti")
    public void setObiettivoProvvSconti(Float obiettivoProvvSconti) {
        this.obiettivoProvvSconti = obiettivoProvvSconti;
    }

    @JsonProperty("obiettivoPrezzoNetto")
    public Double getObiettivoPrezzoNetto() {
        return obiettivoPrezzoNetto;
    }

    @JsonProperty("obiettivoPrezzoNetto")
    public void setObiettivoPrezzoNetto(Double obiettivoPrezzoNetto) {
        this.obiettivoPrezzoNetto = obiettivoPrezzoNetto;
    }

    @JsonProperty("obiettivoMargine")
    public Double getObiettivoMargine() {
        return obiettivoMargine;
    }

    @JsonProperty("obiettivoMargine")
    public void setObiettivoMargine(Double obiettivoMargine) {
        this.obiettivoMargine = obiettivoMargine;
    }

    @JsonProperty("obiettivoMargineContrib")
    public Double getObiettivoMargineContrib() {
        return obiettivoMargineContrib;
    }

    @JsonProperty("obiettivoMargineContrib")
    public void setObiettivoMargineContrib(Double obiettivoMargineContrib) {
        this.obiettivoMargineContrib = obiettivoMargineContrib;
    }

    @JsonProperty("obiettivoMcMinuto")
    public Double getObiettivoMcMinuto() {
        return obiettivoMcMinuto;
    }

    @JsonProperty("obiettivoMcMinuto")
    public void setObiettivoMcMinuto(Double obiettivoMcMinuto) {
        this.obiettivoMcMinuto = obiettivoMcMinuto;
    }

    @JsonProperty("propostoPrezzoLordo")
    public Double getPropostoPrezzoLordo() {
        return propostoPrezzoLordo;
    }

    @JsonProperty("propostoPrezzoLordo")
    public void setPropostoPrezzoLordo(Double propostoPrezzoLordo) {
        this.propostoPrezzoLordo = propostoPrezzoLordo;
    }

    @JsonProperty("propostoProvvSconti")
    public Float getPropostoProvvSconti() {
        return propostoProvvSconti;
    }

    @JsonProperty("propostoProvvSconti")
    public void setPropostoProvvSconti(Float propostoProvvSconti) {
        this.propostoProvvSconti = propostoProvvSconti;
    }

    @JsonProperty("propostoPrezzoNetto")
    public Double getPropostoPrezzoNetto() {
        return propostoPrezzoNetto;
    }

    @JsonProperty("propostoPrezzoNetto")
    public void setPropostoPrezzoNetto(Double propostoPrezzoNetto) {
        this.propostoPrezzoNetto = propostoPrezzoNetto;
    }

    @JsonProperty("propostoMargine")
    public Double getPropostoMargine() {
        return propostoMargine;
    }

    @JsonProperty("propostoMargine")
    public void setPropostoMargine(Double propostoMargine) {
        this.propostoMargine = propostoMargine;
    }

    @JsonProperty("propostoMargineContrib")
    public Double getPropostoMargineContrib() {
        return propostoMargineContrib;
    }

    @JsonProperty("propostoMargineContrib")
    public void setPropostoMargineContrib(Double propostoMargineContrib) {
        this.propostoMargineContrib = propostoMargineContrib;
    }

    @JsonProperty("propostoMcMinuto")
    public Double getPropostoMcMinuto() {
        return propostoMcMinuto;
    }

    @JsonProperty("propostoMcMinuto")
    public void setPropostoMcMinuto(Double propostoMcMinuto) {
        this.propostoMcMinuto = propostoMcMinuto;
    }

    @JsonProperty("as400PrezzoLordo")
    public Double getAs400PrezzoLordo() {
        return as400PrezzoLordo;
    }

    @JsonProperty("as400PrezzoLordo")
    public void setAs400PrezzoLordo(Double as400PrezzoLordo) {
        this.as400PrezzoLordo = as400PrezzoLordo;
    }

    @JsonProperty("as400ProvvSconti")
    public Float getAs400ProvvSconti() {
        return as400ProvvSconti;
    }

    @JsonProperty("as400ProvvSconti")
    public void setAs400ProvvSconti(Float as400ProvvSconti) {
        this.as400ProvvSconti = as400ProvvSconti;
    }

    @JsonProperty("as400PrezzoNetto")
    public Double getAs400PrezzoNetto() {
        return as400PrezzoNetto;
    }

    @JsonProperty("as400PrezzoNetto")
    public void setAs400PrezzoNetto(Double as400PrezzoNetto) {
        this.as400PrezzoNetto = as400PrezzoNetto;
    }

    @JsonProperty("as400Margine")
    public Double getAs400Margine() {
        return as400Margine;
    }

    @JsonProperty("as400Margine")
    public void setAs400Margine(Double as400Margine) {
        this.as400Margine = as400Margine;
    }

    @JsonProperty("as400MargineContrib")
    public Double getAs400MargineContrib() {
        return as400MargineContrib;
    }

    @JsonProperty("as400MargineContrib")
    public void setAs400MargineContrib(Double as400MargineContrib) {
        this.as400MargineContrib = as400MargineContrib;
    }

    @JsonProperty("as400McMinuto")
    public Double getAs400McMinuto() {
        return as400McMinuto;
    }

    @JsonProperty("as400McMinuto")
    public void setAs400McMinuto(Double as400McMinuto) {
        this.as400McMinuto = as400McMinuto;
    }

    @JsonProperty("defaultListini")
    public String getDefaultListini() {
        return defaultListini;
    }

    @JsonProperty("defaultListini")
    public void setDefaultListini(String defaultListini) {
        this.defaultListini = defaultListini;
    }

    @JsonProperty("matAccessori")
    public String getMatAccessori() {
        return matAccessori;
    }

    @JsonProperty("matAccessori")
    public void setMatAccessori(String matAccessori) {
        this.matAccessori = matAccessori;
    }

    @JsonProperty("costoMinMop")
    public String getCostoMinMop() {
        return costoMinMop;
    }

    @JsonProperty("costoMinMop")
    public void setCostoMinMop(String costoMinMop) {
        this.costoMinMop = costoMinMop;
    }

    @JsonProperty("costoMinCge")
    public String getCostoMinCge() {
        return costoMinCge;
    }

    @JsonProperty("costoMinCge")
    public void setCostoMinCge(String costoMinCge) {
        this.costoMinCge = costoMinCge;
    }

    @JsonProperty("provv")
    public String getProvv() {
        return provv;
    }

    @JsonProperty("provv")
    public void setProvv(String provv) {
        this.provv = provv;
    }

    @JsonProperty("margineObiett")
    public String getMargineObiett() {
        return margineObiett;
    }

    @JsonProperty("margineObiett")
    public void setMargineObiett(String margineObiett) {
        this.margineObiett = margineObiett;
    }

    @JsonProperty("scontoPremio")
    public Double getScontoPremio() {
        return scontoPremio;
    }

    @JsonProperty("scontoPremio")
    public void setScontoPremio(Double scontoPremio) {
        this.scontoPremio = scontoPremio;
    }

    @JsonProperty("cmopStagione")
    public String getCmopStagione() {
        return cmopStagione;
    }

    @JsonProperty("cmopStagione")
    public void setCmopStagione(String cmopStagione) {
        this.cmopStagione = cmopStagione;
    }

    @JsonProperty("cgenStagione")
    public String getCgenStagione() {
        return cgenStagione;
    }

    @JsonProperty("cgenStagione")
    public void setCgenStagione(String cgenStagione) {
        this.cgenStagione = cgenStagione;
    }

    @JsonProperty("provStagione")
    public String getProvStagione() {
        return provStagione;
    }

    @JsonProperty("provStagione")
    public void setProvStagione(String provStagione) {
        this.provStagione = provStagione;
    }

    @JsonProperty("mobbStagione")
    public String getMobbStagione() {
        return mobbStagione;
    }

    @JsonProperty("mobbStagione")
    public void setMobbStagione(String mobbStagione) {
        this.mobbStagione = mobbStagione;
    }

    @JsonProperty("matAccessoriStagione")
    public String getMatAccessoriStagione() {
        return matAccessoriStagione;
    }

    @JsonProperty("matAccessoriStagione")
    public void setMatAccessoriStagione(String matAccessoriStagione) {
        this.matAccessoriStagione = matAccessoriStagione;
    }

    @JsonProperty("scontoPremioStagione")
    public String getScontoPremioStagione() {
        return scontoPremioStagione;
    }

    @JsonProperty("scontoPremioStagione")
    public void setScontoPremioStagione(String scontoPremioStagione) {
        this.scontoPremioStagione = scontoPremioStagione;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
