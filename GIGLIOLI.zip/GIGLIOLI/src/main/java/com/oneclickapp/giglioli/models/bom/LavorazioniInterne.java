/*Copyright (c) 2022–2023 oneclickapp.com – Tutti i diritti riservati.

Il presente software è da considerarsi a tutti gli effetti un’opera intellettuale riservata, contenente informazioni strettamente confidenziali e di esclusiva titolarità di oneclickapp.com, marchio e divisione operativa di Plumma S.R.L.. Qualsiasi utilizzo, riproduzione, distribuzione, comunicazione o divulgazione, totale o parziale, del software o della relativa documentazione, in qualunque forma o modalità, è espressamente vietato se non previamente autorizzato per iscritto da oneclickapp.com o regolato da uno specifico accordo di licenza.

L’utente o licenziatario è vincolato a trattare tutte le informazioni contenute nel software come strettamente confidenziali e a non utilizzarle per scopi diversi da quelli esplicitamente consentiti nel contratto di licenza del codice sorgente sottoscritto con oneclickapp.com, impegnandosi altresì a non divulgarle a terzi senza il previo consenso scritto della stessa.

La proprietà intellettuale del so*/
package com.oneclickapp.giglioli.models.bom;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({

        "articolo",
        "elemento",
        "descrizione",
        "um",
        "consumo",
        "codiceSl",
        "fornitoreTerzista",
        "sequenza",
        "sottoelementi",
        "analizzato"
})

public class LavorazioniInterne {

 
    @JsonProperty("articolo")
    private String articolo;
    @JsonProperty("elemento")
    private String elemento;
    @JsonProperty("descrizione")
    private String descrizione;
    @JsonProperty("um")
    private String um;
    @JsonProperty("consumo")
    private Double consumo;
    @JsonProperty("codiceSl")
    private String codiceSl;
    @JsonProperty("fornitoreTerzista")
    private String fornitoreTerzista;
    @JsonProperty("sequenza")
    private String sequenza;
    @JsonProperty("sottoelementi")
    private List<Sottoelementus> sottoelementi;
    /** Flag validazione riga (Analisi OK), persistito nel JSON BOM come per materiali/lav. esterne. */
    @JsonProperty("analizzato")
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private Boolean analizzato;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     *
     */
    public LavorazioniInterne() {
    }

    public LavorazioniInterne(String batchId, String articolo, String elemento, String descrizione, String um, Double consumo, String codiceSl, String fornitTerz, String sequenza, List<Sottoelementus> sottoelementi) {
        super();
        this.elemento = elemento;
        this.descrizione = descrizione;
        this.um = um;
        this.consumo = consumo;
        this.codiceSl = codiceSl;
        this.fornitoreTerzista = fornitTerz;
        this.sequenza = sequenza;
        this.sottoelementi = sottoelementi;
    }



    @JsonProperty("articolo")
    public String getArticolo() {
        return articolo;
    }

    @JsonProperty("articolo")
    public void setArticolo(String articolo) {
        this.articolo = articolo;
    }

    @JsonProperty("elemento")
    public String getElemento() {
        return elemento;
    }

    @JsonProperty("elemento")
    public void setElemento(String elemento) {
        this.elemento = elemento;
    }

    @JsonProperty("descrizione")
    public String getDescrizione() {
        return descrizione;
    }

    @JsonProperty("descrizione")
    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    @JsonProperty("um")
    public String getUm() {
        return um;
    }

    @JsonProperty("um")
    public void setUm(String um) {
        this.um = um;
    }

    @JsonProperty("consumo")
    public Double getConsUnit() {
        return consumo;
    }

    @JsonProperty("consumo")
    public void setConsUnit(Double consumo) {
        this.consumo = consumo;
    }

    @JsonProperty("codiceSl")
    public String getCodiceSl() {
        return codiceSl;
    }

    @JsonProperty("codiceSl")
    public void setCodiceSl(String codiceSl) {
        this.codiceSl = codiceSl;
    }

    @JsonProperty("fornitoreTerzista")
    public String getFornitTerz() {
        return fornitoreTerzista;
    }

    @JsonProperty("fornitoreTerzista")
    public void setFornitTerz(String fornitTerz) {
        this.fornitoreTerzista = fornitTerz;
    }

    @JsonProperty("sequenza")
    public String getSequenza() {
        return sequenza;
    }

    @JsonProperty("sequenza")
    public void setSequenza(String sequenza) {
        this.sequenza = sequenza;
    }

    @JsonProperty("sottoelementi")
    public List<Sottoelementus> getSottoelementi() {
        return sottoelementi;
    }

    @JsonProperty("sottoelementi")
    public void setSottoelementi(List<Sottoelementus> sottoelementi) {
        this.sottoelementi = sottoelementi;
    }

    @JsonProperty("analizzato")
    public Boolean getAnalizzato() {
        return analizzato;
    }

    @JsonProperty("analizzato")
    public void setAnalizzato(Boolean analizzato) {
        this.analizzato = analizzato;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
