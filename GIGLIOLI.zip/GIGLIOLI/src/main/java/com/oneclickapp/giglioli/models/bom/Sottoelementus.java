/*Copyright (c) 2022–2023 oneclickapp.com – Tutti i diritti riservati.

Il presente software è da considerarsi a tutti gli effetti un’opera intellettuale riservata, contenente informazioni strettamente confidenziali e di esclusiva titolarità di oneclickapp.com, marchio e divisione operativa di Plumma S.R.L.. Qualsiasi utilizzo, riproduzione, distribuzione, comunicazione o divulgazione, totale o parziale, del software o della relativa documentazione, in qualunque forma o modalità, è espressamente vietato se non previamente autorizzato per iscritto da oneclickapp.com o regolato da uno specifico accordo di licenza.

L’utente o licenziatario è vincolato a trattare tutte le informazioni contenute nel software come strettamente confidenziali e a non utilizzarle per scopi diversi da quelli esplicitamente consentiti nel contratto di licenza del codice sorgente sottoscritto con oneclickapp.com, impegnandosi altresì a non divulgarle a terzi senza il previo consenso scritto della stessa.

La proprietà intellettuale del so*/
package com.oneclickapp.giglioli.models.bom;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"sottoelDescrizione", "sottoelConsumo", "sottoelUnitaMisura", "sottoelCodiceSl"})

public class Sottoelementus implements Serializable {

    @JsonProperty("sottoelDescrizione")
    private String sottoelDescrizione;
    @JsonProperty("sottoelConsumo")
    private Double sottoelConsumo;
    @JsonProperty("sottoelUnitaMisura")
    private String sottoelUnitaMisura;
    @JsonProperty("sottoelCodiceSl")
    private String sottoelCodiceSl;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     *
     */
    public Sottoelementus() {
    }

    public Sottoelementus(String sottoelDescrizione, Double sottoelConsumo, String unitaMisura, String sottoelCodiceSl) {
        super();
        this.sottoelDescrizione = sottoelDescrizione;
        this.sottoelConsumo = sottoelConsumo;
        this.sottoelUnitaMisura = unitaMisura;
        this.sottoelCodiceSl = sottoelCodiceSl;
    }

    @JsonProperty("sottoelCodiceSl")
    public String getSottoelCodiceSl() {
        return sottoelCodiceSl;
    }

    @JsonProperty("sottoelCodiceSl")
    public void setSottoelCodiceSl(String sottoelCodiceSl) {
        this.sottoelCodiceSl = sottoelCodiceSl;
    }


    @JsonProperty("sottoelDescrizione")
    public String getDescrizione() {
        return sottoelDescrizione;
    }

    @JsonProperty("sottoelDescrizione")
    public void setDescrizione(String sottoelDescrizione) {
        this.sottoelDescrizione = sottoelDescrizione;
    }

    @JsonProperty("sottoelConsumo")
    public Double getConsumo() {
        return sottoelConsumo;
    }

    @JsonProperty("sottoelConsumo")
    public void setConsumo(Double sottoelConsumo) {
        this.sottoelConsumo = sottoelConsumo;
    }

    @JsonProperty("sottoelUnitaMisura")
    public String getUnitaMisura() {
        return sottoelUnitaMisura;
    }

    @JsonProperty("sottoelUnitaMisura")
    public void setUnitaMisura(String unitaMisura) {
        this.sottoelUnitaMisura = unitaMisura;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
