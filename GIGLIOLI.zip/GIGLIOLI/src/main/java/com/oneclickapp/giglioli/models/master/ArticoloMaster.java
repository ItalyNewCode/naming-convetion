package com.oneclickapp.giglioli.models.master;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ArticoloMaster
        extends com.oneclickapp.giglioli.giglioli_preventivi.Articoli {

    @JsonProperty("prop_1")
    private String prop_1;

    @JsonProperty("prop_2")
    private String prop_2;

    @JsonProperty("prop_3")
    private String prop_3;


    @JsonProperty("stato")
    private String stato;

    @JsonProperty("minuti")
    private Double minuti;

    @JsonProperty("consumo")
    private Double consumo;

    @JsonProperty("costo_componenti")
    private Double costo_componenti;

    @JsonProperty("costo_scheda")
    private Double costo_scheda;

    @JsonProperty("costo_totale")
    private Double costo_totale;

    @JsonProperty("euro_pareggio")
    private Double euro_pareggio;

    @JsonProperty("euro_obiettivo")
    private Double euro_obiettivo;

    @JsonProperty("euro_as400")
    private Double euro_as400;

    @JsonProperty("propostoPrezzoLordo")
    private Double propostoPrezzoLordo;

    @JsonProperty("m_percentuale")
    private Double m_percentuale;

    @JsonProperty("m_va")
    private Double m_va;

    @JsonProperty("m_cont")
    private Double m_cont;

    @JsonProperty("m_cont_min")
    private Double m_cont_min;

    @JsonProperty("data_comunicazione")
    private Double data_comunicazione;

    @JsonProperty("flag_calcolo")
    private String flag_calcolo;

    @JsonProperty("flag_storicizzato")
    private String flag_storicizzato;

    // TODO: implementare campo parametri_custom nel BOM per tracciare se l'operatore ha usato parametri non standard
    @JsonProperty("flag_parametri")
    private String flag_parametri;

    @JsonProperty("propieta")
    public String getPropieta() {
        return propieta;
    }

    @JsonProperty("propieta")
    public void setPropieta(String propieta) {
        this.propieta = propieta;
    }

    @JsonProperty("propieta")
    private String propieta;

    // --- GETTER & SETTER ---


    @JsonProperty("stato")
    public String getStato() {
        return stato;
    }

    @JsonProperty("stato")
    public void setStato(String stato) {
        this.stato = stato;
    }


    @JsonProperty("prop_1")
    public String getProp1() {
        return prop_1;
    }

    @JsonProperty("prop_1")
    public void setProp1(String prop_1) {
        this.prop_1 = prop_1;
    }

    @JsonProperty("prop_2")
    public String getProp2() {
        return prop_2;
    }

    @JsonProperty("prop_2")
    public void setProp2(String prop_2) {
        this.prop_2 = prop_2;
    }


    @JsonProperty("prop_3")
    public String getProp3() {
        return prop_3;
    }

    @JsonProperty("prop_3")
    public void setProp3(String prop_3) {
        this.prop_3 = prop_3;
    }

    @JsonProperty("minuti")
    public Double getMinuti() {
        return minuti;
    }

    @JsonProperty("minuti")
    public void setMinuti(Double minuti) {
        this.minuti = minuti;
    }

    @JsonProperty("consumo")
    public Double getConsumo() {
        return consumo;
    }

    @JsonProperty("consumo")
    public void setConsumo(Double consumo) {
        this.consumo = consumo;
    }

    @JsonProperty("costo_componenti")
    public Double getCostoComponenti() {
        return costo_componenti;
    }

    @JsonProperty("costo_componenti")
    public void setCostoComponenti(Double costo_componenti) {
        this.costo_componenti = costo_componenti;
    }

    @JsonProperty("costo_scheda")
    public Double getCostoScheda() {
        return costo_scheda;
    }

    @JsonProperty("costo_scheda")
    public void setCostoScheda(Double costo_scheda) {
        this.costo_scheda = costo_scheda;
    }

    @JsonProperty("costo_totale")
    public Double getCostoTotale() {
        return costo_totale;
    }

    @JsonProperty("costo_totale")
    public void setCostoTotale(Double costo_totale) {
        this.costo_totale = costo_totale;
    }

    @JsonProperty("euro_pareggio")
    public Double getEuroPareggio() {
        return euro_pareggio;
    }

    @JsonProperty("euro_pareggio")
    public void setEuroPareggio(Double euro_pareggio) {
        this.euro_pareggio = euro_pareggio;
    }

    @JsonProperty("euro_obiettivo")
    public Double getEuroObiettivo() {
        return euro_obiettivo;
    }

    @JsonProperty("euro_obiettivo")
    public void setEuroObiettivo(Double euro_obiettivo) {
        this.euro_obiettivo = euro_obiettivo;
    }

    @JsonProperty("euro_as400")
    public Double getEuroAs400() {
        return euro_as400;
    }

    @JsonProperty("euro_as400")
    public void setEuroAs400(Double euro_as400) {
        this.euro_as400 = euro_as400;
    }

    @JsonProperty("propostoPrezzoLordo")
    public Double getPropostoPrezzoLordo() {
        return propostoPrezzoLordo;
    }

    @JsonProperty("propostoPrezzoLordo")
    public void setPropostoPrezzoLordo(Double propostoPrezzoLordo) {
        this.propostoPrezzoLordo = propostoPrezzoLordo;
    }

    @JsonProperty("m_percentuale")
    public Double getMPercentuale() {
        return m_percentuale;
    }

    @JsonProperty("m_percentuale")
    public void setMPercentuale(Double m_percentuale) {
        this.m_percentuale = m_percentuale;
    }

    @JsonProperty("m_va")
    public Double getMVa() {
        return m_va;
    }

    @JsonProperty("m_va")
    public void setMVa(Double m_va) {
        this.m_va = m_va;
    }

    @JsonProperty("m_cont")
    public Double getMCont() {
        return m_cont;
    }

    @JsonProperty("m_cont")
    public void setMCont(Double m_cont) {
        this.m_cont = m_cont;
    }

    @JsonProperty("m_cont_min")
    public Double getMContMin() {
        return m_cont_min;
    }

    @JsonProperty("m_cont_min")
    public void setMContMin(Double m_cont_min) {
        this.m_cont_min = m_cont_min;
    }

    @JsonProperty("data_comunicazione")
    public Double getDataComunicazione() {
        return data_comunicazione;
    }

    @JsonProperty("data_comunicazione")
    public void setDataComunicazione(Double data_comunicazione) {
        this.data_comunicazione = data_comunicazione;
    }

    @JsonProperty("flag_calcolo")
    public String getFlagCalcolo() {
        return flag_calcolo;
    }

    @JsonProperty("flag_calcolo")
    public void setFlagCalcolo(String flag_calcolo) {
        this.flag_calcolo = flag_calcolo;
    }

    @JsonProperty("flag_storicizzato")
    public String getFlagStoricizzato() {
        return flag_storicizzato;
    }

    @JsonProperty("flag_storicizzato")
    public void setFlagStoricizzato(String flag_storicizzato) {
        this.flag_storicizzato = flag_storicizzato;
    }

    @JsonProperty("flag_parametri")
    public String getFlagParametri() {
        return flag_parametri;
    }

    @JsonProperty("flag_parametri")
    public void setFlagParametri(String flag_parametri) {
        this.flag_parametri = flag_parametri;
    }
}
