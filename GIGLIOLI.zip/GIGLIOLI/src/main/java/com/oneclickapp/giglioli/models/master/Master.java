
package com.oneclickapp.giglioli.models.master;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "progetto",
        "group_tecnology",
        "brand",
        "schede",
        "progetto_index"
})

public class Master implements Serializable {


    @JsonProperty("progetto_index")
    public Integer getProgettoIndex() {
        return progettoIndex;
    }

    @JsonProperty("progetto_index")
    public void setProgettoIndex(Integer progettoIndex) {
        this.progettoIndex = progettoIndex;
    }

    @JsonProperty("progetto_index")
    private Integer progettoIndex;
    @JsonProperty("progetto")
    private String progetto;
    @JsonProperty("group_tecnology")
    private String groupTecnology;
    @JsonProperty("brand")
    private String brand;
    @JsonProperty("schede")
    private List<Scheda> schede ;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();
    private final static long serialVersionUID = -2508063417109870110L;

    /**
     * No args constructor for use in serialization
     *
     */
    public Master() {
    }

    public Master(String progetto, String groupTecnology, String brand, List<Scheda> schede) {
        super();
        this.progetto = progetto;
        this.groupTecnology = groupTecnology;
        this.brand = brand;
        this.schede =schede;
    }

    @JsonProperty("progetto")
    public String getProgetto() {
        return progetto;
    }

    @JsonProperty("progetto")
    public void setProgetto(String progetto) {
        this.progetto = progetto;
    }

    public Master withProgetto(String progetto) {
        this.progetto = progetto;
        return this;
    }

    @JsonProperty("group_tecnology")
    public String getGroupTecnology() {
        return groupTecnology;
    }

    @JsonProperty("group_tecnology")
    public void setGroupTecnology(String groupTecnology) {
        this.groupTecnology = groupTecnology;
    }

    public Master withGroupTecnology(String groupTecnology) {
        this.groupTecnology = groupTecnology;
        return this;
    }

    @JsonProperty("brand")
    public String getBrand() {
        return brand;
    }

    @JsonProperty("brand")
    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Master withBrand(String brand) {
        this.brand = brand;
        return this;
    }

    @JsonProperty("schede")
    public List<Scheda> getSchede() {
        return schede ;
    }

    @JsonProperty("schede")
    public void setSchede(List<Scheda> schede) {
        this.schede = schede;
    }

    public Master withSchede(List<Scheda> schedede) {
        this.schede = schede;
        return this;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public Master withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }


}
