
package com.oneclickapp.giglioli.models.master;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "numero",
        "articoli",
        "stagione"
})

public class Scheda implements Serializable {

    @JsonProperty("numero")
    private Integer numero;
    @JsonProperty("stagione")
    private String stagione;
    @JsonProperty("articoli")
    private List<ArticoloMaster> articoli;

    private final static long serialVersionUID = 5962438390198775726L;

    /**
     * No args constructor for use in serialization
     *
     */
    public Scheda() {
    }

    public Scheda(Integer numero, List<ArticoloMaster> articoli,  String stagione) {
        super();
        this.numero = numero;
        this.articoli = articoli;
        this.stagione = stagione;
    }

    @JsonProperty("numero")
    public Integer getNumero() {
        return numero;
    }

    @JsonProperty("numero")
    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public Scheda withNumero(Integer numero) {
        this.numero = numero;
        return this;
    }



    @JsonProperty("stagione")
    public String getStagione() {
        return stagione;
    }

    @JsonProperty("stagione")
    public void setStagione(String stagione) {
        this.stagione = stagione;
    }


    @JsonProperty("articoli")
    public List<ArticoloMaster> getArticoli() {
        return articoli;
    }

    @JsonProperty("articoli")
    public void setArticoli(List<ArticoloMaster> articoli) {
        this.articoli = articoli;
    }

    public Scheda withArticoli(List<ArticoloMaster> articoli) {
        this.articoli = articoli;
        return this;
    }



}
