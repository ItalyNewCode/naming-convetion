/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on the variables within this block(on-page-load) */
App.onAppVariablesReady = function () {
    /*
     * variables can be accessed through 'App.Variables' property here
     * e.g. App.Variables.staticVariable1.getData()
     */
    // Guardia globale anti deep-link non autorizzati:
    // in alcuni casi la pagina può risultare bianca prima del normale onReady pagina.
    App.enforceCurrentPageAccessFromUrl();
};

/* perform any action on session timeout here, e.g clearing some data, etc */
App.onSessionTimeout = function () {
    /*
     * NOTE:
     * On re-login after session timeout:
     * if the same user logs in(through login dialog), app will retain its state
     * if a different user logs in, app will be reloaded and user is redirected to respective landing page configured in Security.
     */
};

/*
 * This application level callback function will be invoked after the invocation of PAGE level onPageReady function.
 * Use this function to write common logic across the pages in the application.
 * activePageName : name of the page
 * activePageScope: scope of the page
 * $activePageEl  : page jQuery element
 */
App.onPageReady = function (activePageName, activePageScope, $activePageEl) {
    // Nessun $watch/$watchCollection qui: lo scope pagina WM non è l’API ufficiale per reagire alle Live Variable.
    // Per confronto_storici vedi Page.scheduleEnrichCrudBomHistoryPrezzo in confronto_storici.js.
    App.enforceCurrentPageAccessByName(activePageName);
};

/**
 * Per confronto storici: espone prezzo proposto lordo della singola storicizzazione (dal JSON salvato in bom_history).
 */
App.enrichBomHistoryRowsPrezzoProposto = function (dataSet) {
    if (!dataSet || !dataSet.length) {
        return;
    }
    dataSet.forEach(function (row) {
        if (!row) {
            return;
        }
        row.prezzoPropostoStorico = null;
        var col = row.prezzoPropostoLordo != null ? row.prezzoPropostoLordo : row.prezzo_proposto_lordo;
        if (col != null && col !== '') {
            row.prezzoPropostoStorico = Number(col);
            if (row.prezzoPropostoLordo == null || row.prezzoPropostoLordo === '') {
                row.prezzoPropostoLordo = row.prezzoPropostoStorico;
            }
            return;
        }
        var bomJsonRaw = row.bomJson || row.bom_json;
        if (!bomJsonRaw) {
            return;
        }
        try {
            var j = JSON.parse(bomJsonRaw);
            var v = j && (j.propostoPrezzoLordo != null && j.propostoPrezzoLordo !== ''
                ? j.propostoPrezzoLordo
                : j.proposto_prezzo_lordo);
            row.prezzoPropostoStorico = v != null && v !== '' ? Number(v) : null;
            if (row.prezzoPropostoStorico != null && (row.prezzoPropostoLordo == null || row.prezzoPropostoLordo === '')) {
                row.prezzoPropostoLordo = row.prezzoPropostoStorico;
            }
        } catch (e) {
            row.prezzoPropostoStorico = null;
        }
    });
};

/*
 * This application level callback function will be invoked after a Variable receives an error from the target service.
 * Use this function to write common error handling logic across the application.
 * errorMsg:    The error message returned by the target service. This message will be displayed through appNotification variable
 *              You can change this though App.Variables.appNotification.setMessage(YOUR_CUSTOM_MESSAGE)
 * xhrObj:      The xhrObject used to make the service call
 *              This object contains useful information like statusCode, url, request/response body.
 */
App.onServiceError = function (errorMsg, xhrObj) {
    console.log(errorMsg, xhrObj);
};


App.loadSchedeByProjectNameonSuccess = function (variable, data) {
    App.__schedeListBase = (App.Variables.loadSchedeByProjectName.dataSet || []).map(function (row) {
        return Object.assign({}, row);
    });
    App.Variables.loadSchedeByProjectName.dataSet.forEach(r => {
        r.selected = false;
    });
};

App.getIdDaCambiare = function () {

    const csvIds = App.Variables.articoliSelezionati.getData()
        .map(item => item.id)
        .join(',');
    if (_.isNil(csvIds)) return false;

    return (csvIds);
};

App.showNotify = function (type, message, title) {
    App.Actions.notify.setMessage(message);
    App.Actions.notify.setAlertType(type);
    App.Actions.notify.dataBinding.title = title;
    App.Actions.notify.invoke();
};

/** Per etichette BOM: boolean / 0-1 / stringhe → Sì / No / trattino. */
App.boolLeggibileIt = function (v) {
    if (v === true || v === 1 || v === '1' || v === 'true' || v === 'TRUE') {
        return 'Sì';
    }
    if (v === false || v === 0 || v === '0' || v === 'false' || v === 'FALSE') {
        return 'No';
    }
    if (v == null || v === '') {
        return '-';
    }
    return String(v);
};

/** Blocco cambio stagione listini: solo BOM bloccato o preventivo ufficialmente STORICIZZATO (non il solo flag tecnico). */
App.bomNonModificabileCambioStagione = function (bom) {
    if (!bom) {
        return false;
    }
    var bloccato = bom.bloccato === true || bom.bloccato === 1 || bom.bloccato === 'true' || bom.bloccato === '1';
    if (bloccato) {
        return true;
    }
    return bom.statoPreventivo === 'STORICIZZATO';
};

/**
 * Messaggio leggibile da errore invoke variabile/servizio WaveMaker (spesso JSON con errors.error[].parameters).
 */
App.formatServiceInvokeError = function (error, fallback) {
    if (error == null) {
        return fallback || 'Errore';
    }
    if (typeof error === 'string') {
        return error;
    }
    var tryParse = function (txt) {
        if (!txt || typeof txt !== 'string') {
            return null;
        }
        try {
            return JSON.parse(txt);
        } catch (e) {
            return null;
        }
    };
    var walk = function (obj) {
        if (!obj || typeof obj !== 'object') {
            return null;
        }
        if (obj.errors && obj.errors.error && obj.errors.error.length) {
            var e0 = obj.errors.error[0];
            if (e0.parameters && e0.parameters.length && e0.parameters[0]) {
                return String(e0.parameters[0]);
            }
            if (e0.message && e0.message !== '{0}' && e0.message.indexOf('UnexpectedError') === -1) {
                return String(e0.message);
            }
        }
        return null;
    };
    var fromObj = walk(error);
    if (fromObj) {
        return fromObj;
    }
    var d = error.data != null ? error.data : error.response;
    if (typeof d === 'string') {
        var parsed = tryParse(d);
        if (parsed) {
            var w = walk(parsed);
            if (w) {
                return w;
            }
        }
        // Corpo testo da REST (es. eccezioni ManagerArticoli): mostra il messaggio completo se è chiaramente in italiano su distinta/BOM.
        if (d.length < 2000 && (d.indexOf('Il BOM') !== -1 || d.indexOf('La distinta') !== -1
                || d.indexOf('VALIDAZIONE DISTINTA') !== -1 || d.indexOf('Nessuna distinta') !== -1
                || d.indexOf('distinta bloccata') !== -1 || d.indexOf('JSON della distinta') !== -1
                || d.indexOf('storicizzazione della distinta') !== -1)) {
            return d;
        }
    }
    if (d && typeof d === 'object') {
        var w2 = walk(d);
        if (w2) {
            return w2;
        }
    }
    if (error.message && error.message !== 'error' && error.message.length > 2) {
        return String(error.message);
    }
    return fallback || 'Errore';
};

/** Valore "analizzato" proveniente da checkbox WM (stringa, numero, ecc.). */
App.bomAnalizzatoIsTrue = function (v) {
    if (v === true || v === 1) {
        return true;
    }
    if (v === false || v === 0 || v === null || v === undefined) {
        return false;
    }
    if (typeof v === 'string') {
        var s = v.trim().toLowerCase();
        return s === 'true' || s === '1' || s === 'yes' || s === 's' || s === 'on';
    }
    return false;
};

App.bomGetMaterialiRows = function (bomVar) {
    if (!bomVar) {
        return [];
    }
    var ds = (bomVar.dataSet && bomVar.dataSet.materiali) || [];
    var gv = [];
    if (typeof bomVar.getValue === 'function') {
        try {
            gv = bomVar.getValue('materiali') || [];
        } catch (e) { /* ignore */ }
    }
    return (Array.isArray(gv) && gv.length >= ds.length && gv.length > 0) ? gv : ds;
};

App.bomGetLavEstRows = function (bomVar) {
    if (!bomVar) {
        return [];
    }
    var ds = (bomVar.dataSet && bomVar.dataSet.lavorazioniEsterne) || [];
    var gv = [];
    if (typeof bomVar.getValue === 'function') {
        try {
            gv = bomVar.getValue('lavorazioniEsterne') || [];
        } catch (e) { /* ignore */ }
    }
    return (Array.isArray(gv) && gv.length >= ds.length && gv.length > 0) ? gv : ds;
};

App.bomGetLavIntRows = function (bomVar) {
    if (!bomVar) {
        return [];
    }
    var ds = (bomVar.dataSet && bomVar.dataSet.lavorazioniInterne) || [];
    var gv = [];
    if (typeof bomVar.getValue === 'function') {
        try {
            gv = bomVar.getValue('lavorazioniInterne') || [];
        } catch (e) { /* ignore */ }
    }
    return (Array.isArray(gv) && gv.length >= ds.length && gv.length > 0) ? gv : ds;
};

/** Validazione pre-storicizza: tutte le righe materiali e lav. esterne con analizzato true. */
App.bomAnalisiRigheComplete = function (bomVar) {
    if (!bomVar) {
        return false;
    }
    var mats = App.bomGetMaterialiRows(bomVar);
    var lav = App.bomGetLavEstRows(bomVar);
    if (mats.length === 0 && lav.length === 0) {
        return true;
    }
    var i;
    for (i = 0; i < mats.length; i++) {
        if (!mats[i] || !App.bomAnalizzatoIsTrue(mats[i].analizzato)) {
            return false;
        }
    }
    for (i = 0; i < lav.length; i++) {
        if (!lav[i] || !App.bomAnalizzatoIsTrue(lav[i].analizzato)) {
            return false;
        }
    }
    return true;
};

/** Etichette righe senza «Analisi OK» (stesso criterio di bomAnalisiRigheComplete). */
App.bomAnalisiRigheEtichetteMancanti = function (bomVar) {
    var missing = [];
    if (!bomVar) {
        return missing;
    }
    var mats = App.bomGetMaterialiRows(bomVar);
    var lav = App.bomGetLavEstRows(bomVar);
    var i, r, el;
    for (i = 0; i < mats.length; i++) {
        r = mats[i];
        if (!r || !App.bomAnalizzatoIsTrue(r.analizzato)) {
            el = (r && r.elemento != null) ? String(r.elemento).trim() : '?';
            missing.push('materiale ' + el);
        }
    }
    for (i = 0; i < lav.length; i++) {
        r = lav[i];
        if (!r || !App.bomAnalizzatoIsTrue(r.analizzato)) {
            el = (r && r.elemento != null) ? String(r.elemento).trim() : '?';
            missing.push('lav.esterna ' + el);
        }
    }
    return missing;
};

/** Messaggio utente con elenco righe da validare (max 10). */
App.bomAnalisiRigheMessaggioUtente = function (bomVar) {
    var labels = App.bomAnalisiRigheEtichetteMancanti(bomVar);
    if (labels.length === 0) {
        return '';
    }
    var max = Math.min(10, labels.length);
    var more = labels.length > max ? ' …' : '';
    return 'Spunta «Analisi OK» su ogni riga materiali e lavorazioni esterne. Mancano: ' + labels.slice(0, max).join(', ') + '.' + more;
};

/**
 * JSON minimale (flag righe + prezzo proposto) per merge server su storicizzaBom.
 * @param {object} bomVar variabile BOM WaveMaker
 * @param {*} [propostoUiOverride] valore grezzo dal widget testo (se il dataSet non è ancora allineato)
 */
App.bomJsonSoloFlagAnalizzato = function (bomVar, propostoUiOverride) {
    if (!bomVar) {
        return null;
    }
    function compatta(rows) {
        if (!Array.isArray(rows)) {
            return [];
        }
        return rows.map(function (r) {
            if (!r) {
                return null;
            }
            var fc = r.fornitoreTerzistaCodice;
            if (fc === undefined || fc === null) {
                fc = r.fornitore_terzista_codice;
            }
            if (fc === undefined || fc === null) {
                fc = '';
            } else {
                fc = String(fc).trim();
            }
            var el = r.elemento;
            if (el === undefined || el === null) {
                el = '';
            } else {
                el = String(el).trim();
            }
            return {
                elemento: el,
                fornitoreTerzistaCodice: fc,
                analizzato: App.bomAnalizzatoIsTrue(r.analizzato)
            };
        }).filter(Boolean);
    }
    function compattaLavInt(rows) {
        if (!Array.isArray(rows)) {
            return [];
        }
        return rows.map(function (r) {
            if (!r) {
                return null;
            }
            var el = r.elemento;
            if (el === undefined || el === null) {
                el = '';
            } else {
                el = String(el).trim();
            }
            var seq = r.sequenza;
            if (seq === undefined || seq === null) {
                seq = '';
            } else {
                seq = String(seq).trim();
            }
            var cs = r.codiceSl;
            if (cs === undefined || cs === null) {
                cs = '';
            } else {
                cs = String(cs).trim();
            }
            return {
                elemento: el,
                sequenza: seq,
                codiceSl: cs,
                analizzato: App.bomAnalizzatoIsTrue(r.analizzato)
            };
        }).filter(Boolean);
    }
    function numPropostoPatch(v) {
        if (v === undefined || v === null || v === '') {
            return null;
        }
        if (typeof v === 'number' && isFinite(v)) {
            return v;
        }
        var n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
        return isNaN(n) ? null : n;
    }
    try {
        var patch = {
            materiali: compatta(App.bomGetMaterialiRows(bomVar)),
            lavorazioniEsterne: compatta(App.bomGetLavEstRows(bomVar)),
            lavorazioniInterne: compattaLavInt(App.bomGetLavIntRows(bomVar))
        };
        var ds = bomVar.dataSet || {};
        var pp = numPropostoPatch(propostoUiOverride);
        if (pp == null) {
            pp = numPropostoPatch(ds.propostoPrezzoLordo);
        }
        if (pp == null && typeof bomVar.getValue === 'function') {
            try {
                pp = numPropostoPatch(bomVar.getValue('propostoPrezzoLordo'));
            } catch (e1) { /* ignore */ }
        }
        if (pp != null) {
            patch.propostoPrezzoLordo = pp;
        }
        return JSON.stringify(patch);
    } catch (e) {
        console.error('App.bomJsonSoloFlagAnalizzato:', e);
        return null;
    }
};





App.isEmpty = function (elm) {
    try {
        // array
        if (Array.isArray(elm)) {
            return elm.length === 0;
        }

        // oggetto (plain object)
        if (typeof elm === "object") {
            return Object.keys(elm).length === 0;
        }

        // stringa
        if (typeof elm === "string") {
            return elm.trim().length === 0;
        }

        // undefined o null
        if (elm === undefined || elm === null) {
            return true;
        }

        return false;
    } catch (error) {
        console.error('isEmpty:', error);
        return false;
    }
};

App.getCSSPerStato = function (stato) {
    switch (stato.toUpperCase()) {
        case 'NESSUNO':
            return 'label label-default';
        case 'COMPLETO':
            return 'label label-success';
        case 'RICHIESTO':
            return 'label label-primary';
        case 'FATTIBILE':
            return 'label label-info';
        case 'IN CORSO':
            return 'label label-warning';
        case 'DA CONFERMARE':
            return 'label label-warning';
        case 'BLOCCATO':
            return 'label label-danger';
        case 'SBLOCCATO':
            return 'label label-success';
        case 'STORICIZZATO':
            return 'label label-default';
        default:
            return 'label label-default';
    }

};

App._roleAccessMatrix = {
    master: ["master", "admin"],
    backoffice: ["backoffice", "admin"],
    management: ["admin"]
};

App._landingByRole = {
    admin: "management",
    master: "master",
    backoffice: "backoffice"
};

App._extractRoleName = function (roleEntry) {
    if (!roleEntry) {
        return "";
    }
    if (typeof roleEntry === "string") {
        return roleEntry.toLowerCase();
    }
    if (typeof roleEntry === "object" && roleEntry.name) {
        return String(roleEntry.name).toLowerCase();
    }
    return "";
};

App.getUserRoles = function () {
    var userData = (App.Variables && App.Variables.loggedInUser && App.Variables.loggedInUser.dataSet) || {};
    var rawRoles = userData.roles;

    if (!Array.isArray(rawRoles)) {
        return [];
    }

    return rawRoles
        .map(App._extractRoleName)
        .filter(function (role) {
            return !!role;
        });
};

App.userHasRole = function (role) {
    var roles = App.getUserRoles();
    var targetRole = String(role || "").toLowerCase();
    return roles.indexOf(targetRole) !== -1;
};

App.getPrimaryRole = function () {
    var roles = App.getUserRoles();
    var priority = ["admin", "master", "backoffice"];
    var i;
    for (i = 0; i < priority.length; i++) {
        if (roles.indexOf(priority[i]) !== -1) {
            return priority[i];
        }
    }
    return roles.length ? roles[0] : "";
};

App.getPrimaryRoleLabel = function () {
    var role = App.getPrimaryRole();
    if (!role) {
        return "-";
    }
    if (role === "admin") {
        return "admin";
    }
    if (role === "master") {
        return "master";
    }
    if (role === "backoffice") {
        return "backoffice";
    }
    return role;
};

App.getLandingPageForCurrentUser = function () {
    var primaryRole = App.getPrimaryRole();
    if (primaryRole && App._landingByRole[primaryRole]) {
        return App._landingByRole[primaryRole];
    }
    return "master";
};

App.navigateToPage = function (pageName) {
    if (!pageName || !App.Actions) {
        return;
    }

    var actionName = "goToPage_" + pageName;
    var action = App.Actions[actionName];
    if (action && typeof action.invoke === "function") {
        action.invoke();
    }
};

App.navigateToLandingPageForCurrentUser = function () {
    var landingPage = App.getLandingPageForCurrentUser();
    App.navigateToPage(landingPage);
};

App.canAccessPage = function (pageName) {
    var normalized = String(pageName || "").toLowerCase();
    var allowedRoles = App._roleAccessMatrix[normalized];
    if (!allowedRoles || !allowedRoles.length) {
        // Se una pagina non è in matrice, non la blocchiamo.
        return true;
    }
    return allowedRoles.some(function (role) {
        return App.userHasRole(role);
    });
};

App.getCurrentPageNameFromUrl = function () {
    try {
        var path = (window.location && window.location.pathname) ? window.location.pathname : "";
        var m = path.match(/\/pages\/([^\/?#]+)/i);
        return m && m[1] ? String(m[1]).toLowerCase() : "";
    } catch (e) {
        return "";
    }
};

App.enforceCurrentPageAccessByName = function (pageName) {
    var p = String(pageName || "").toLowerCase();
    if (!p || p === "login" || p === "main") {
        return true;
    }
    if (!App._roleAccessMatrix[p]) {
        return true;
    }
    if (App.canAccessPage(p)) {
        return true;
    }
    App.navigateToLandingPageForCurrentUser();
    return false;
};

App.enforceCurrentPageAccessFromUrl = function () {
    var maxAttempts = 20;
    var attempts = 0;

    var tryEnforce = function () {
        attempts += 1;
        var currentPage = App.getCurrentPageNameFromUrl();
        if (!currentPage || currentPage === "login" || currentPage === "main") {
            return;
        }
        // aspetta che i ruoli siano disponibili; poi applica la guardia
        var roles = App.getUserRoles();
        if ((!roles || !roles.length) && attempts < maxAttempts) {
            setTimeout(tryEnforce, 150);
            return;
        }
        App.enforceCurrentPageAccessByName(currentPage);
    };

    setTimeout(tryEnforce, 0);
};

App.ensurePageAccess = function (pageName) {
    if (App.canAccessPage(pageName)) {
        return true;
    }

    App.showNotify("error", "Non hai i permessi per questa pagina.");
    App.navigateToLandingPageForCurrentUser();
    return false;
};

App.getRolePermissionMatrixRows = function () {
    return [
        {
            ruolo: "admin",
            landing: App._landingByRole.admin,
            puoVedere: "master, backoffice, management",
            note: "Ruolo con accesso completo"
        },
        {
            ruolo: "master",
            landing: App._landingByRole.master,
            puoVedere: "master",
            note: "Utente operativo area master"
        },
        {
            ruolo: "backoffice",
            landing: App._landingByRole.backoffice,
            puoVedere: "backoffice",
            note: "Utente operativo area backoffice"
        }
    ];
};

/**
 * Ritorna gli articoli visibili nella pagina master indicizzati per id.
 * Utile per eliminare selezioni "fantasma" rimaste in articoliSelezionati dopo refresh/calcola/paginazione.
 */
App.getVisibleMasterArticoliMap = function () {
    var map = {};
    var ds = App.Variables && App.Variables.getMasterView ? App.Variables.getMasterView.dataSet : null;
    var root = Array.isArray(ds) ? ds : (ds && Array.isArray(ds.content) ? ds.content : []);

    root.forEach(function (masterRow) {
        var schede = masterRow && Array.isArray(masterRow.schede) ? masterRow.schede : [];
        schede.forEach(function (scheda) {
            var articoli = scheda && Array.isArray(scheda.articoli) ? scheda.articoli : [];
            articoli.forEach(function (a) {
                if (a && a.id != null) {
                    map[String(a.id)] = a;
                }
            });
        });
    });
    return map;
};

/**
 * Filtra la selezione corrente mantenendo solo articoli visibili in master.
 * Se syncVariable=true aggiorna anche App.Variables.articoliSelezionati per ripulire lo stato.
 */
App.getSelectedArticoliForMasterActions = function (syncVariable) {
    var selected = App.Variables && App.Variables.articoliSelezionati
        ? (App.Variables.articoliSelezionati.getData() || [])
        : [];
    if (!Array.isArray(selected)) {
        selected = [];
    }

    var visibleMap = App.getVisibleMasterArticoliMap();
    var cleaned = [];
    var seen = {};

    selected.forEach(function (a) {
        if (!a || a.id == null) {
            return;
        }
        var key = String(a.id);
        if (!visibleMap[key] || seen[key]) {
            return;
        }
        // usa l'oggetto visibile più aggiornato, non eventuale snapshot vecchio
        cleaned.push(visibleMap[key]);
        seen[key] = true;
    });

    if (syncVariable && App.Variables && App.Variables.articoliSelezionati) {
        App.Variables.articoliSelezionati.setData(cleaned);
    }
    return cleaned;
};


