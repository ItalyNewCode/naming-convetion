/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
    Page.__userInteractingWithLogin = false;
    Page.bindLoginInteractionHandlers();
    // Avoid redirect loops: if we just auto-redirected, let user login manually.
    var lastAutoRedirectTs = Number(sessionStorage.getItem('wm_last_auto_redirect_ts') || '0');
    if (Date.now() - lastAutoRedirectTs < 15000) {
        return;
    }

    // Give user a few seconds to type before auto-check starts.
    setTimeout(function () {
        if (!Page.__userInteractingWithLogin) {
            Page.retrySessionCheckAndRedirect(20, 800);
        }
    }, 4000);
};

Page.bindLoginInteractionHandlers = function () {
    var usernameInput = document.querySelector('input[name="j_username"]');
    var passwordInput = document.querySelector('input[name="j_password"]');
    var loginButton = document.querySelector('button[name="loginButton"]');
    var markInteracting = function () {
        Page.__userInteractingWithLogin = true;
        Page.hideAuthLoadingOverlay();
    };

    [usernameInput, passwordInput].forEach(function (el) {
        if (!el) {
            return;
        }
        el.addEventListener('keydown', markInteracting, { once: true });
        el.addEventListener('input', markInteracting, { once: true });
        el.addEventListener('click', markInteracting, { once: true });
    });

    if (loginButton) {
        loginButton.addEventListener('click', markInteracting, { once: true });
    }
};

Page.showAuthLoadingOverlay = function () {
    if (document.getElementById('auth-check-overlay')) {
        return;
    }

    var style = document.createElement('style');
    style.id = 'auth-check-overlay-style';
    style.textContent = '' +
        '#auth-check-overlay {' +
        'position: fixed; inset: 0; background: #ffffff; z-index: 99999;' +
        'display: flex; flex-direction: column; align-items: center; justify-content: center;' +
        'font-family: Arial, sans-serif; color: #2f3b4a;' +
        '}' +
        '#auth-check-overlay .spinner {' +
        'width: 44px; height: 44px; border: 4px solid #d9dee5; border-top-color: #1976d2;' +
        'border-radius: 50%; animation: authSpin 0.85s linear infinite; margin-bottom: 14px;' +
        '}' +
        '@keyframes authSpin { to { transform: rotate(360deg); } }';
    document.head.appendChild(style);

    var overlay = document.createElement('div');
    overlay.id = 'auth-check-overlay';
    overlay.innerHTML = '<div class="spinner"></div><div>Autenticazione in corso...</div>';
    document.body.appendChild(overlay);
};

Page.hideAuthLoadingOverlay = function () {
    var overlay = document.getElementById('auth-check-overlay');
    if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
    }
    var style = document.getElementById('auth-check-overlay-style');
    if (style && style.parentNode) {
        style.parentNode.removeChild(style);
    }
};

Page.retrySessionCheckAndRedirect = function (maxAttempts, delayMs) {
    var attempts = 0;
    var redirected = false;
    var basePath = window.location.pathname.split('/pages/')[0].replace(/\/+$/, '');
    var checkUrl = window.location.origin + basePath + '/services/managerArticoli/masterView?page=1&size=1';

    function runCheck() {
        if (redirected) {
            return;
        }
        if (Page.__userInteractingWithLogin) {
            Page.hideAuthLoadingOverlay();
            return;
        }

        attempts += 1;
        if (attempts >= 4 && !Page.__userInteractingWithLogin) {
            Page.showAuthLoadingOverlay();
        }

        fetch(checkUrl, {
            method: 'GET',
            credentials: 'include'
        }).then(function (response) {
            if (response && response.status === 200 && !redirected) {
                redirected = true;
                sessionStorage.setItem('wm_last_auto_redirect_ts', String(Date.now()));
                Page.redirectToLandingPage();
                return;
            }

            if (attempts < maxAttempts) {
                setTimeout(runCheck, delayMs);
            } else {
                Page.hideAuthLoadingOverlay();
            }
        }).catch(function () {
            if (attempts < maxAttempts) {
                setTimeout(runCheck, delayMs);
            } else {
                Page.hideAuthLoadingOverlay();
            }
        });
    }

    runCheck();
};

Page.redirectToLandingPage = function () {
    var maxRoleAttempts = 12;
    var roleAttempt = 0;

    function tryNavigate() {
        roleAttempt += 1;
        var roles = (typeof App.getUserRoles === 'function') ? App.getUserRoles() : [];
        if ((roles && roles.length) || roleAttempt >= maxRoleAttempts) {
            if (typeof App.navigateToLandingPageForCurrentUser === 'function') {
                App.navigateToLandingPageForCurrentUser();
                return;
            }
            App.Actions.goToPage_master.invoke();
            return;
        }
        setTimeout(tryNavigate, 250);
    }

    tryNavigate();
};
