/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
    if (!App.ensurePageAccess('backoffice')) {
        return;
    }
};
Page._setSelectedArticoli = function (rows) {
    App.Variables.articoliSelezionati.setData(_.uniqBy(rows || [], 'id'));
};

Page._removeSelectedArticoloById = function (id) {
    var current = App.Variables.articoliSelezionati.getData() || [];
    Page._setSelectedArticoli(current.filter(function (row) {
        return !(row && row.id === id);
    }));
};

Page._addSelectedArticolo = function (item) {
    var current = App.Variables.articoliSelezionati.getData() || [];
    current.push(item);
    Page._setSelectedArticoli(current);
};
Page.anchor2Click = function ($event, widget, item, currentItemWidgets) {
    // currentItemWidgets.containerDetailsArticoli.show = !currentItemWidgets.containerDetailsArticoli.show;
    // currentItemWidgets.containerRows.show = !currentItemWidgets.containerRows.show;

};
Page.numberEuroPropostoChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {


};




Page.checkboxCodiceArticoloChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    console.log(item);
    if (newVal === false) {
        Page._removeSelectedArticoloById(item && item.id);
    }
    if (newVal === true) {
        Page._addSelectedArticolo(item);
    }

    console.log(App.Variables.articoliSelezionati.getData());
};

Page.checkboxAllArticoliChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    var listWidget = currentItemWidgets && (currentItemWidgets.ArticoliList1 || currentItemWidgets.listArticoli);
    if (!listWidget || !Array.isArray(listWidget.dataset)) {
        return;
    }
    if (newVal === true) {
        listWidget.dataset.forEach(function (articolo, index) {
            listWidget.selectItem(index);
            Page._addSelectedArticolo(articolo);
            listWidget.getItem(index)._currentItemWidgets.checkboxCodiceArticolo.datavalue = true;
        });
    }
    if (newVal === false) {
        listWidget.dataset.forEach(function (articolo, index) {
            listWidget.deselectItem(index);
            Page._removeSelectedArticoloById(articolo && articolo.id);
            listWidget.getItem(index)._currentItemWidgets.checkboxCodiceArticolo.datavalue = false;
        });
    }
};

Page.anchorArticoloClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.articoloSelezionato.setData(item);
    // Pulisci il pageParam storico_id per navigazione normale (non storico)
    // App.Actions.goToPage_bom.navigate({
    //     data: {
    //         "storico_id": null,
    //         "articolo": item.articolo,
    //         "articolo_id": item.id
    //     }
    // });
};


Page.anchorNoteClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.notaSelezionata.setValue("idRefTabella", item.id);
    App.Variables.notaSelezionata.setValue("tabella", "articoli");
    Page.Widgets.pagedialogNote.open();



};
