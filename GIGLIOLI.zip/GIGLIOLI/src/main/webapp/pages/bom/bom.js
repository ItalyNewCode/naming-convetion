/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

function articoloSelezionatoRow() {
    var artVar = App.Variables.articoloSelezionato.getData();
    // if (!artVar) {
    //     return null;
    // }   

    // var gd = (typeof artVar.getData === 'function') ? artVar.getData() : null;
    // function hasId(row) {
    //     return row && row.id != null && row.id !== '';
    // }
    // // La pagina BOM lega i campi a articoloSelezionato.dataSet: ha priorità su getData() che può essere vuoto o non allineato.
    // if (hasId(ds)) {
    //     return ds;
    // }
    // if (hasId(gd)) {
    //     return gd;
    // }
    return artVar || null;
    // if (artVar.length <= 0)
    //     return false;
    // else
    //     return true;
}

/** Sì/No per caption BOM (delega ad App quando disponibile). */
Page.boolLeggibileIt = function (v) {
    if (typeof App === 'object' && App && typeof App.boolLeggibileIt === 'function') {
        return App.boolLeggibileIt(v);
    }
    if (v === true || v === 1 || v === '1' || v === 'true' || v === 'TRUE') {
        return 'Sì';
    }
    if (v === false || v === 0 || v === '0' || v === 'false' || v === 'FALSE') {
        return 'No';
    }
    if (v == null || v === '') {
        return '-';
    }
    return String(v);
};

/** Sincronizza il flag sul modello WaveMaker (getValue/setValue come costo/listino). */
Page.onCheckboxAnalizzatoMatChange = function ($event, widget, item, currentItemWidgets) {
    if (!item) {
        return;
    }
    var coerced = App.bomAnalizzatoIsTrue(widget && widget.datavalue);
    item.analizzato = coerced;
    Page.updateBomItem('materiali', item, 'analizzato', coerced, currentItemWidgets, 'checkboxConf');
};

Page.onCheckboxAnalizzatoLavEstChange = function ($event, widget, item, currentItemWidgets) {
    if (!item) {
        return;
    }
    var coerced = App.bomAnalizzatoIsTrue(widget && widget.datavalue);
    item.analizzato = coerced;
    Page.updateBomItem('lavorazioniEsterne', item, 'analizzato', coerced, currentItemWidgets, 'checkbox2');
};

Page.onCheckboxAnalizzatoLavIntChange = function ($event, widget, item, currentItemWidgets) {
    if (!item) {
        return;
    }
    var coercedLi = App.bomAnalizzatoIsTrue(widget && widget.datavalue);
    item.analizzato = coercedLi;
    Page.updateBomItem('lavorazioniInterne', item, 'analizzato', coercedLi, currentItemWidgets, 'checkbox3');
};

/** Normalizza un valore numerico per gli override inviati a fxCalcola (BOM). */
function bomParseNumericOverride(v) {
    if (v === undefined || v === null || v === '') {
        return null;
    }
    if (typeof v === 'number' && isFinite(v)) {
        return v;
    }
    var n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
    return isNaN(n) ? null : n;
}

Page.bomParseNumber = function (v) {
    if (v === undefined || v === null || v === '') {
        return null;
    }
    if (typeof v === 'number') {
        return isFinite(v) ? v : null;
    }
    var n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
    return isNaN(n) ? null : n;
};

Page.formatDataStato = function (rawValue) {
    if (rawValue === undefined || rawValue === null || rawValue === '') {
        return '-';
    }
    var s = String(rawValue).trim();
    if (typeof moment === 'function') {
        var strictFormats = [
            'YYYY-MM-DD HH:mm:ss.SSS',
            'YYYY-MM-DD HH:mm:ss',
            moment.ISO_8601
        ];
        var m = moment(s, strictFormats, true);
        if (!m.isValid()) {
            m = moment(s);
        }
        if (m.isValid()) {
            // Naive SQL datetime spesso è in UTC: mostra in locale operatore
            if (/^\d{4}-\d{2}-\d{2}/.test(s) && !/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)) {
                var asUtc = moment.utc(s, strictFormats, true);
                if (asUtc.isValid()) {
                    return asUtc.local().format('DD/MM/YYYY HH:mm');
                }
            }
            return m.format('DD/MM/YYYY HH:mm');
        }
    }
    return s;
};

/** Esposto a livello globale per i bind WaveMaker (come bomPercentCaption). */
function formatDataStato(rawValue) {
    return Page.formatDataStato(rawValue);
}

Page.showBandierinaRossa = function (bandierina, esitoCalcolo) {
    var b = (bandierina || '').toString().trim().toUpperCase();
    if (b === 'R' || b === 'RED' || b === 'ROSSA' || b === 'TRUE' || b === '1') {
        return true;
    }
    var e = (esitoCalcolo || '').toString().trim().toUpperCase();
    return !!e && e !== 'OK';
};

Page.bomPercentCaption = function (n, d, decimali = 2) {
    var digits = (decimali === undefined || decimali === null) ? 1 : decimali;

    if (n === null || d === null || d === 0) {
        return '-';
    }
    var value = (n / d) * 100;
    if (!isFinite(value)) {
        return '-';
    }
    return value.toFixed(decimali) + '%';
};

function bomPercentCaption(n, d, decimali) {
    return Page.bomPercentCaption(n, d, decimali);
}

Page._bomDs = function () {
    return (Page.Variables && Page.Variables.bomArticolo && Page.Variables.bomArticolo.dataSet) ? Page.Variables.bomArticolo.dataSet : {};
};

Page.bomCostoCompValue = function (costoComponenti, costoScheda, lavorazioniInterneValore) {
    var costoComp = Page.bomParseNumber(costoComponenti);
    if (costoComp !== null && costoComp !== undefined && costoComp !== 0) {
        return costoComp;
    }
    var costoSchedaNum = Page.bomParseNumber(costoScheda);
    var lavInterne = Page.bomParseNumber(lavorazioniInterneValore);
    if (costoSchedaNum !== null && lavInterne !== null) {
        return costoSchedaNum - lavInterne;
    }
    return costoComp;
};

function bomCostoCompValue(costoComponenti, costoScheda, lavorazioniInterneValore) {
    return Page.bomCostoCompValue(costoComponenti, costoScheda, lavorazioniInterneValore);
}

Page.onMatAccessoriManualChange = function ($event, widget) {
    var ds = Page._bomDs();
    if (ds) {
        ds.matAccessori = widget && widget.datavalue;
        ds.matAccessoriStagione = 'M';
        if (Page.Variables && Page.Variables.bomArticolo) {
            Page.Variables.bomArticolo.setData(ds);
        }
    }
};

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    console.log('=== BOM Page.onReady ===');
    console.log('Page.pageParams:', Page.pageParams);

    // Se presente il pageParam storico_id, siamo in modalità sola lettura storico
    var idStorico = Page.pageParams && Page.pageParams.storico_id;
    console.log('storico_id:', idStorico);

    if (idStorico) {
        // MODALITÀ STORICO: Carica BOM storico da BomHistory
        console.log('Modalità sola lettura attivata - caricamento BOM storico ID:', idStorico);

        // CRITICO: Disabilita autoUpdate e rimuovi dataBinding di bomArticolo per impedire auto-invocazioni
        if (Page.Variables.bomArticolo) {
            Page.Variables.bomArticolo.autoUpdate = false;
            Page.Variables.bomArticolo.startUpdate = false;
            // Rimuovi il dataBinding per impedire che si auto-invochi quando articoloSelezionato cambia
            Page.Variables.bomArticolo.dataBinding = [];
        }

        // Disabilita auto-update delle altre variabili
        if (Page.Variables.crudMateriali) {
            Page.Variables.crudMateriali.autoUpdate = false;
        }
        if (Page.Variables.crudLavorazioniInterne) {
            Page.Variables.crudLavorazioniInterne.autoUpdate = false;
        }
        if (Page.Variables.crudLavorazioniEsterne) {
            Page.Variables.crudLavorazioniEsterne.autoUpdate = false;
        }
        if (Page.Variables.crudRigheAggiuntive) {
            Page.Variables.crudRigheAggiuntive.autoUpdate = false;
        }

        // Carica il BOM storico
        App.Variables.getBomHistoryById.invoke({
            "inputFields": { "id": idStorico }
        }, function (data) {
            try {
                console.log('getBomHistoryById response:', data);

                // La risposta è paginata - i dati sono in data.content
                var bomHistoryRecord = data && data.content && data.content.length > 0 ? data.content[0] : null;
                console.log('bomHistoryRecord:', bomHistoryRecord);

                if (!bomHistoryRecord || !bomHistoryRecord.bomJson) {
                    console.error('BomHistory non trovato - record:', bomHistoryRecord);
                    throw new Error('BomHistory non trovato o bomJson mancante');
                }

                var bomStorico = JSON.parse(bomHistoryRecord.bomJson);
                console.log('BOM storico caricato:', bomStorico);

                // Imposta i dati storici in bomArticolo
                Page.Variables.bomArticolo.setData(bomStorico);
                console.log('BOM storico impostato in bomArticolo');

                Page.disabilitaModifiche();
                App.showNotify('info', 'Visualizzazione storico distinta — modalità sola lettura');
            } catch (error) {
                console.error('Errore parsing bomJson:', error);
                App.showNotify('error', 'Errore nel caricamento dello storico: ' + error.message);
            }
        }, function (error) {
            console.error('Errore caricamento BomHistory:', error);
            App.showNotify('error', 'Errore nel caricamento dello storico');
        });
    } else {
        // Se articoloSelezionato non è valorizzato ma ho il page param articolo_id,
        // recupero l'articolo via query e sincronizzo la variabile App prima di caricare il BOM.        
        var articoloCorrente = articoloSelezionatoRow();
        var articoloParam = Page.pageParams && Page.pageParams.articolo;

        if (articoloCorrente.id !== null && articoloParam) {
            Page.Variables.getArticoloById.invoke({
                inputFields: {
                    articolo: articoloParam
                }
            }, function (data) {
                let articolo = data.content[0]
                App.Variables.articoloSelezionato.setData(articolo);
                // 
                Page.Variables.bomArticolo.setInput('idArticolo', articolo.id);
                Page.Variables.bomArticolo.update();
                //
            }, function (error) {
                console.error('Errore caricamento articolo da page param:', error);
                App.showNotify('error', 'Errore nel caricamento articolo');
            });
            return;
        }

        // MODALITÀ NORMALE: Carica l'ultimo BOM dell'articolo selezionato
        console.log('Modalità normale - caricamento ultimo BOM');

        // Invoca bomArticolo per caricare l'ultimo BOM (autoUpdate è false in Studio)
        if (Page.Variables.bomArticolo) {
            Page.Variables.bomArticolo.update();
        }
    }
};

// Helper per applicare stili CSS a un campo con valore manuale
// Serve per la colorazione IMMEDIATA quando l'utente modifica manualmente il campo
// Il binding condizionale nell'HTML gestisce la colorazione dopo il rendering/reload
Page.applicaStiliValoreManuale = function (element) {
    if (element && element.length) {
        // Aggiungi la classe CSS invece di applicare stili inline
        element.closest('.app-textbox').addClass('input-manuale');
    }
};

// Helper per rimuovere stili manuali quando viene selezionato un prezzo dal listino
Page.rimuoviStiliValoreManuale = function (element) {
    if (element && element.length) {
        // Rimuovi la classe CSS
        element.closest('.app-textbox').removeClass('input-manuale');
    }
};

Page.disabilitaModifiche = function () {
    try {
        console.log('Disabilitazione modifiche - modalità sola lettura');

        // Disabilita i pulsanti principali di azione
        var pulsantiDaDisabilitare = [
            'buttonStoricizza',
            'buttonPulisci',
            'buttonStampe',
            'buttonCambiaStato',
            'buttonCambiaStagioneArticolo',
            'buttonCalcola',
            'buttonListinoMateriali',
            'buttonListinoLavEst',
            'buttonMatAccessoriStagione',
            'buttonCostoMinMOPStagione',
            'buttonCostoMinCGE',
            'buttonProvvStagione',
            'buttonMargineObbietStagione'
        ];

        pulsantiDaDisabilitare.forEach(function (nomePulsante) {
            if (Page.Widgets[nomePulsante]) {
                Page.Widgets[nomePulsante].disabled = true;
            }
        });

        // Disabilita le liste editabili
        var listeEditabili = [
            'MaterialiList',
            'LavorazioniInterneList',
            'LavorazioniEsterneList'
        ];

        listeEditabili.forEach(function (nomeLista) {
            if (Page.Widgets[nomeLista]) {
                Page.Widgets[nomeLista].readonly = true;
            }
        });

        // Disabilita la tabella RigheAggiuntiveBomTable1 completamente
        if (Page.Widgets.RigheAggiuntiveBomTable1) {
            var table = Page.Widgets.RigheAggiuntiveBomTable1;

            // Imposta la tabella in modalità readonly
            table.readonly = true;

            // Cambia editmode a readonly se possibile
            if (table.editmode !== undefined) {
                table.editmode = 'readonly';
            }

            // Nascondi/disabilita tutte le azioni della tabella
            if (table.actions && table.actions.length > 0) {
                table.actions.forEach(function (action) {
                    action.show = false;
                    action.disabled = true;
                });
            }

            // Nascondi i pulsanti delle row actions
            if (table.rowactions && table.rowactions.length > 0) {
                table.rowactions.forEach(function (action) {
                    action.show = false;
                    action.disabled = true;
                });
            }

            console.log('RigheAggiuntiveBomTable1 disabilitata completamente');
        }

        console.log('Modifiche disabilitate con successo');

    } catch (error) {
        console.error('Errore durante la disabilitazione delle modifiche:', error);
    }
};

Page.getNextAggCode = function () {
    const ds = Page.Variables.crudRigheAggiuntive.dataSet || [];
    return "AGG" + (ds.length + 1).toString().padStart(2, "0");
};

Page.getCostoTotaleRiga = function (index) {

    const ds = Page.Variables.crudRigheAggiuntive.dataSet;

    if (!ds || !ds[index]) {
        console.warn("Indice riga non valido:", index);
        return 0;
    }

    const riga = ds[index];

    const cons = Number(riga.consUnit || 0);
    const costo = Number(riga.costoUnit || 0);

    return cons * costo;
};

Page.RigheAggiuntiveBomTable1_addNewRowAction = function ($event) {
    let record = {
        articolo: App.Variables.articoloSelezionato.dataSet.articolo,
        codice: Page.getNextAggCode(),
        consUnit: 1,
        costoUnit: 0,
        creationTimestamp: new Date(),
        descrizione: "",
        tipoC: "M",
        um: "paia"
    };

    Page.Variables.crudRigheAggiuntive.createRecord({ row: record },
        function (data) {
            // Ricargo la CRUD (refresh)
            Page.Variables.crudRigheAggiuntive.update();
            console.log("Riga aggiunta con successo!");
        }, function (err) {
            console.error(err);
            console.log("Errore durante l'inserimento");
        });
};

Page.RigheAggiuntiveBomTable1Beforerowupdate = function ($event, widget, row, options) {
    delete row.costoTot;
};

Page.anchorNoteClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.notaSelezionata.setValue("idRefTabella", App.Variables.articoloSelezionato.getData().id);
    App.Variables.notaSelezionata.setValue("tabella", "articoli");
    Page.Widgets.pagedialogNote.open();
};

/**
 * Aggiorna un campo di un elemento selezionato in una lista del BOM
 * Usa getValue/setValue nativi di WaveMaker Model Variable
 * + aggiorna il widget direttamente per forzare il re-render
 * @param {string} listType - 'materiali', 'lavorazioniInterne', 'lavorazioniEsterne'
 * @param {object} selectedItem - L'item selezionato dalla lista
 * @param {string} fieldName - Nome del campo da aggiornare
 * @param {*} newValue - Nuovo valore da assegnare
 * @param {object} [itemWidgets] - selectedItemWidgets della lista (opzionale)
 * @param {string} [widgetName] - Nome del widget da aggiornare (opzionale)
 */
/** Stessa chiave usata in updateBomItem (elemento + fornitore) per materiali e lav. esterne. */
Page._bomSameRowByElementoFornitore = function (a, b) {
    return !!(a && b && a.elemento === b.elemento &&
        Page._bomFornitoreCodiceRow(a) === Page._bomFornitoreCodiceRow(b));
};

Page._bomFornitoreCodiceRow = function (r) {
    if (!r) {
        return '';
    }
    var v = r.fornitoreTerzistaCodice;
    if (v === undefined || v === null) {
        v = r.fornitore_terzista_codice;
    }
    return String(v == null ? '' : v).trim();
};

Page._bomCodiceSlNorm = function (r) {
    if (!r || r.codiceSl == null) {
        return '';
    }
    return String(r.codiceSl).trim();
};

Page.updateBomItem = function (listType, selectedItem, fieldName, newValue, itemWidgets, widgetName) {
    try {
        if (!selectedItem) {
            console.warn('Nessun item selezionato');
            return false;
        }

        // Stessa array che lega la lista (evita mismatch getValue vs dataSet che fa perdere la spunta lav. esterne).
        var ds = Page.Variables.bomArticolo && Page.Variables.bomArticolo.dataSet;
        var lista = (ds && Array.isArray(ds[listType])) ? ds[listType] : Page.Variables.bomArticolo.getValue(listType);
        if (!lista || !lista.length) {
            console.warn('Lista', listType, 'vuota o non trovata');
            return false;
        }

        var index = lista.findIndex(function (row) {
            return row === selectedItem;
        });
        if (index === -1) {
            index = lista.findIndex(function (row) {
                return row.elemento === selectedItem.elemento &&
                    Page._bomFornitoreCodiceRow(row) === Page._bomFornitoreCodiceRow(selectedItem);
            });
        }
        if (index === -1 && listType === 'lavorazioniEsterne') {
            index = lista.findIndex(function (row) {
                return String(row.sequenza || '') === String(selectedItem.sequenza || '') &&
                    String(row.elemento || '') === String(selectedItem.elemento || '') &&
                    Page._bomCodiceSlNorm(row) === Page._bomCodiceSlNorm(selectedItem);
            });
        }
        if (index === -1 && listType === 'lavorazioniEsterne' && selectedItem.sequenza != null && selectedItem.sequenza !== '') {
            index = lista.findIndex(function (row) {
                return String(row.sequenza || '') === String(selectedItem.sequenza || '');
            });
        }
        if (index === -1 && listType === 'lavorazioniInterne') {
            index = lista.findIndex(function (row) {
                return String(row.sequenza || '') === String(selectedItem.sequenza || '') &&
                    String(row.elemento || '') === String(selectedItem.elemento || '') &&
                    Page._bomCodiceSlNorm(row) === Page._bomCodiceSlNorm(selectedItem);
            });
        }
        if (index === -1 && listType === 'lavorazioniInterne' && selectedItem.sequenza != null && selectedItem.sequenza !== '') {
            index = lista.findIndex(function (row) {
                return String(row.sequenza || '') === String(selectedItem.sequenza || '');
            });
        }

        if (index !== -1) {
            lista[index][fieldName] = newValue;
            Page.Variables.bomArticolo.setValue(listType, lista);

            if (itemWidgets && widgetName && itemWidgets[widgetName]) {
                itemWidgets[widgetName].datavalue = newValue;
            }

            console.log('Campo', fieldName, 'aggiornato a:', newValue, 'per', listType, 'idx=', index, 'elemento:', selectedItem.elemento);
            return true;
        }
        console.warn('Item non trovato nel dataset per', listType, selectedItem);
        return false;
    } catch (error) {
        console.error('updateBomItem:', error);
        return false;
    }
};

/** Backup selezione master prima di aprire cambio stato dalla BOM (ripristinato alla chiusura del dialog). */
Page._articoliSelezionatiBackupForBomCambiaStato = null;

Page.pagedialogCambiaStatoBomCleanup = function () {
    if (Page._articoliSelezionatiBackupForBomCambiaStato === null || Page._articoliSelezionatiBackupForBomCambiaStato === undefined) {
        return;
    }
    App.Variables.articoliSelezionati.setData(Page._articoliSelezionatiBackupForBomCambiaStato);
    Page._articoliSelezionatiBackupForBomCambiaStato = null;
};

Page.pagedialogCambiaStatoBomOnOk = function ($event, widget) {
    Page.pagedialogCambiaStatoBomCleanup();
    if (Page.Widgets.pagedialogCambiaStato && typeof Page.Widgets.pagedialogCambiaStato.close === 'function') {
        Page.Widgets.pagedialogCambiaStato.close();
    }
};

Page.buttonCambiaStatoClick = function ($event, widget) {
    var articolo = articoloSelezionatoRow();
    // if (!articolo || articolo.id == null || articolo.id === '') {
    //     App.showNotify('warning', 'Nessun articolo caricato sulla distinta.');
    //     return;
    // }
    // if (!Page.Widgets.pagedialogCambiaStato) {
    //     App.showNotify('error', 'Dialog cambio stato non disponibile.');
    //     return;
    // }
    // if (widget) {
    //     widget.disabled = true;
    // }
    console.log(articolo);
    var prev = App.Variables.articoliSelezionati.getData();
    Page._articoliSelezionatiBackupForBomCambiaStato = Array.isArray(prev) ? prev.slice() : [];
    App.Variables.articoliSelezionati.setData([articolo]);
    Page.Widgets.pagedialogCambiaStato.open();
    setTimeout(function () {
        if (widget) {
            widget.disabled = false;
        }
    }, 500);
};

Page.buttonCambiaStagioneArticoloClick = function ($event, widget) {
    try {
        var articolo = App.Variables.articoloSelezionato && App.Variables.articoloSelezionato.getData ? App.Variables.articoloSelezionato.getData() : null;
        if (!articolo || !articolo.id) {
            App.showNotify('warning', 'Nessun articolo selezionato');
            return;
        }

        // Blocca solo se BOM bloccato o preventivo ufficialmente STORICIZZATO (il flag storicizzato da solo può restare true con stato IN CORSO su dati legacy).
        var bom = Page.Variables.bomArticolo ? Page.Variables.bomArticolo.dataSet : null;
        if (typeof App.bomNonModificabileCambioStagione === 'function' && App.bomNonModificabileCambioStagione(bom)) {
            App.showNotify('warning', 'Impossibile cambiare stagione: stato preventivo STORICIZZATO o distinta bloccata.');
            return;
        }

        // La partial viene istanziata dopo open: setto i datavalue dopo un micro-delay
        if (Page.Widgets.dialogCambiaStagioneArticolo) {
            Page.Widgets.dialogCambiaStagioneArticolo.open();
            setTimeout(function () {
                if (Page.Widgets.textCambiaStagioneAnno) {
                    Page.Widgets.textCambiaStagioneAnno.datavalue = articolo.stagioneAnno || '';
                }
                if (Page.Widgets.selectCambiaStagioneTipo) {
                    Page.Widgets.selectCambiaStagioneTipo.datavalue = articolo.stagioneTipo || 'E';
                }
            }, 150);
        }
    } catch (error) {
        console.error('buttonCambiaStagioneArticoloClick:', error);
        App.showNotify('error', 'Errore apertura dialog cambio stagione: ' + (error.message || error));
    }
};

Page.buttonAggiornaStagioneArticoloClick = function ($event, widget) {
    try {
        var articolo = App.Variables.articoloSelezionato && App.Variables.articoloSelezionato.getData ? App.Variables.articoloSelezionato.getData() : null;
        var idArticolo = articolo && articolo.id ? articolo.id : null;

        if (!idArticolo) {
            App.showNotify('warning', 'Nessun articolo selezionato');
            return;
        }

        var stagioneAnno = Page.Widgets.textCambiaStagioneAnno ? Page.Widgets.textCambiaStagioneAnno.datavalue : null;
        var stagioneTipo = Page.Widgets.selectCambiaStagioneTipo ? Page.Widgets.selectCambiaStagioneTipo.datavalue : null;

        if (stagioneAnno === null || stagioneAnno === undefined || String(stagioneAnno).trim() === '') {
            App.showNotify('warning', 'Inserisci l\\\'anno della stagione');
            return;
        }
        if (stagioneTipo === null || stagioneTipo === undefined || String(stagioneTipo).trim() === '') {
            App.showNotify('warning', 'Seleziona E oppure I per la stagione');
            return;
        }

        stagioneTipo = String(stagioneTipo).trim().toUpperCase();
        // WaveMaker potrebbe valorizzare il select con indici (0/1) invece che con 'E'/'I'
        if (stagioneTipo === '0') stagioneTipo = 'E';
        if (stagioneTipo === '1') stagioneTipo = 'I';
        if (stagioneTipo !== 'E' && stagioneTipo !== 'I') {
            App.showNotify('warning', 'Stagione non valida. Valori accettati: E oppure I');
            return;
        }

        var bomAgg = Page.Variables.bomArticolo ? Page.Variables.bomArticolo.dataSet : null;
        if (typeof App.bomNonModificabileCambioStagione === 'function' && App.bomNonModificabileCambioStagione(bomAgg)) {
            App.showNotify('warning', 'Impossibile cambiare stagione: stato preventivo STORICIZZATO o distinta bloccata.');
            return;
        }

        App.showNotify('info', 'Aggiornamento stagione in corso...');

        Page.Variables.cambiaStagioneArticolo.invoke({
            inputFields: {
                idArticolo: idArticolo,
                stagioneAnno: parseInt(stagioneAnno, 10),
                stagioneTipo: stagioneTipo
            }
        }, function (data) {
            try {
                // UI: aggiorna subito il dataset articolo (titoli "stagione" e default listini)
                if (data && App.Variables.articoloSelezionato && App.Variables.articoloSelezionato.getData) {
                    var articoloAgg = App.Variables.articoloSelezionato.getData();
                    if (articoloAgg) {
                        articoloAgg.stagioneAnno = parseInt(stagioneAnno, 10);
                        articoloAgg.stagioneTipo = stagioneTipo;
                        App.Variables.articoloSelezionato.setData(articoloAgg);
                    }
                }

                // UI: aggiorna BOM (costi/listini non manuali resettati, pronto per CALCOLA)
                if (data) {
                    Page.Variables.bomArticolo.setData(data);
                }

                if (Page.Widgets.dialogCambiaStagioneArticolo) {
                    Page.Widgets.dialogCambiaStagioneArticolo.close();
                }

                App.showNotify('success', 'Stagione aggiornata. Premi CALCOLA per auto-popolare i listini.');
            } catch (e) {
                console.error('buttonAggiornaStagioneArticoloClick success handler:', e);
                App.showNotify('error', 'Errore aggiornamento UI: ' + (e.message || e));
            }
        }, function (error) {
            console.error('buttonAggiornaStagioneArticoloClick error:', error);
            App.showNotify('error', 'Errore aggiornamento stagione: ' + (error.message || error));
        });
    } catch (error) {
        console.error('buttonAggiornaStagioneArticoloClick:', error);
        App.showNotify('error', 'Errore: ' + (error.message || error));
    }
};

Page.buttonCalcolaClick = function ($event, widget) {
    try {
        var bom = Page.Variables.bomArticolo.dataSet;
        var articolo = articoloSelezionatoRow();
        var idArticolo = articolo && articolo.id;

        if (!bom || idArticolo == null || idArticolo === '') {
            console.error('Nessun BOM o articolo caricato');
            App.showNotify('error', 'Nessuna distinta o articolo selezionato (id mancante). Torna alla master e riapri la distinta.');
            return;
        }

        // Leggi i valori direttamente dai widget (evita ritardi del two-way binding sul dataSet)
        var propostoPrezzoLordo = Page.Widgets.textPropostoPrezzoLordo.datavalue;
        var scontoPremioUi = Page.Widgets.textScontoPremio ? Page.Widgets.textScontoPremio.datavalue : bom.scontoPremio;
        var matAccessoriUi = Page.Widgets.textMatAccessori ? Page.Widgets.textMatAccessori.datavalue : bom.matAccessori;
        var provvUi = Page.Widgets.textProvv ? Page.Widgets.textProvv.datavalue : bom.provv;
        var margineObiettUi = Page.Widgets.textMargineObbiett ? Page.Widgets.textMargineObbiett.datavalue : bom.margineObiett;
        var costoMinMopUi = Page.Widgets.textCostoMinMOP ? Page.Widgets.textCostoMinMOP.datavalue : bom.costoMinMop;
        var costoMinCgeUi = Page.Widgets.textCostoMinCGE ? Page.Widgets.textCostoMinCGE.datavalue : bom.costoMinCge;

        console.log('Avvio calcolo BOM per articolo ID:', idArticolo);
        console.log('Prezzo Proposto Lordo dal widget:', propostoPrezzoLordo);

        // Mostra messaggio di calcolo in corso
        // App.showNotify('info', 'Calcolo in corso...');

        // Disabilita il pulsante durante il calcolo
        if (widget) {
            widget.disabled = true;
        }

        // Solo invoke: setInput sulla variabile servizio accumula parametri QUERY sulla URL; valori vecchi (es. scontoPremio) vincono sui campi nuovi nel multipart e Spring legge cose sbagliate.
        // Non inviare as400PrezzoLordoOverride qui: non c'è campo UI per editarlo; passarlo come eco del BOM bloccava
        // lato server l'aggancio AS400 = ultimo proposto salvato quando cambi solo il prezzo proposto (vedi ManagerArticoli.calcolaBom).
        var scalarInputs = {
            idArticolo: idArticolo,
            matAccessoriOverride: (matAccessoriUi !== undefined && matAccessoriUi !== null) ? String(matAccessoriUi) : null,
            provvOverride: bomParseNumericOverride(provvUi),
            scontoPremioOverride: bomParseNumericOverride(scontoPremioUi),
            margineObiettOverride: bomParseNumericOverride(margineObiettUi),
            costoMinMopOverride: bomParseNumericOverride(costoMinMopUi),
            costoMinCgeOverride: bomParseNumericOverride(costoMinCgeUi),
            propostoPrezzoLordoOverride: bomParseNumericOverride(propostoPrezzoLordo)
        };

        console.log('fxCalcola scalarInputs:', scalarInputs);

        App.Variables.fxCalcola.invoke({
            inputFields: Object.assign({}, scalarInputs, {
                materialiOverride: JSON.stringify(bom.materiali || []),
                lavorazioniInterneOverride: JSON.stringify(bom.lavorazioniInterne || []),
                lavorazioniEsterneOverride: JSON.stringify(bom.lavorazioniEsterne || [])
            })
        }, function (data) {
            console.log('Calcolo completato');

            // Riabilita il pulsante
            if (widget) {
                widget.disabled = false;
            }

            if (data) {
                var bomCalcolato = (typeof data === 'string') ? JSON.parse(data) : data;
                console.log('Prezzo Proposto nel BOM calcolato:', bomCalcolato.propostoPrezzoLordo);
                console.log('AS400 nel BOM calcolato:', bomCalcolato.as400PrezzoLordo);

                Page.Variables.bomArticolo.setData(bomCalcolato);

                // Mostra messaggio di successo
                // App.showNotify('success', 'Calcolo completato con successo!');

                // La colorazione viene applicata automaticamente tramite binding condizionale nell'HTML
            }
        }, function (error) {
            console.error('Errore calcolo BOM:', error);

            // Riabilita il pulsante
            if (widget) {
                widget.disabled = false;
            }

            // Mostra messaggio di errore
            App.showNotify('error', 'Errore durante il calcolo: ' + (error.message || error));
        });
    } catch (error) {
        console.error('buttonCalcolaClick:', error);

        // Mostra messaggio di errore
        App.showNotify('error', 'Errore imprevisto: ' + error.message);
    }
};

Page.buttonStoricizzaClick = function ($event, widget) {
    try {
        var articoloStor = articoloSelezionatoRow();
        var idArticolo = articoloStor && articoloStor.id;

        if (!idArticolo) {
            App.showNotify('warning', 'Nessun articolo selezionato');
            return;
        }

        // Requisito analisi: ogni riga materiali e lav. esterne deve avere "Analisi OK" (analizzato true).
        if (!App.bomAnalisiRigheComplete(Page.Variables.bomArticolo)) {
            var msgAn = (typeof App.bomAnalisiRigheMessaggioUtente === 'function')
                ? App.bomAnalisiRigheMessaggioUtente(Page.Variables.bomArticolo)
                : '';
            App.showNotify('error', msgAn || 'Spunta su ogni riga materiali e lavorazioni esterne prima di storicizzare.');
            return;
        }

        // Allinea dataSet al campo editato (come in CALCOLA), così il patch JSON include sempre il prezzo proposto.
        var twProp = Page.Widgets.textPropostoPrezzoLordo;
        var dsBom = Page.Variables.bomArticolo && Page.Variables.bomArticolo.dataSet;
        if (twProp && dsBom) {
            var pvSt = bomParseNumericOverride(twProp.datavalue);
            if (pvSt != null) {
                dsBom.propostoPrezzoLordo = pvSt;
            }
        }

        var bomJson = App.bomJsonSoloFlagAnalizzato(Page.Variables.bomArticolo, twProp && twProp.datavalue);

        var propostoQuery = bomParseNumericOverride(twProp && twProp.datavalue);
        if (propostoQuery == null && dsBom) {
            propostoQuery = bomParseNumericOverride(dsBom.propostoPrezzoLordo);
        }
        var storicizzaInputs = {
            idArticolo: idArticolo,
            bomJson: bomJson,
            clientBomJson: bomJson
        };
        if (propostoQuery != null) {
            storicizzaInputs.propostoPrezzoLordo = propostoQuery;
        }

        console.log('Storicizzazione BOM in bom_history per articolo ID:', idArticolo);

        // Disabilita il pulsante per evitare click multipli
        Page.Widgets.buttonStoricizza.disabled = true;

        // Usa il nuovo metodo storicizzaBom che salva in bom_history
        App.Variables.fxStoricizzaBom.invoke({
            "inputFields": storicizzaInputs
        }, function (data) {
            console.log('Storicizzazione completata:', data);
            // Re-abilita il pulsante
            Page.Widgets.buttonStoricizza.disabled = false;

            if (data) {
                // Aggiorna il BOM visualizzato con il flag storicizzato
                Page.Variables.bomArticolo.setData(data);
                App.showNotify('success', 'Distinta storicizzata con successo nello storico');

                // Ricarica la master view per aggiornare il flag "S"
                App.Variables.getMasterView.invoke();
            }
        }, function (error) {
            console.error('Errore storicizzazione BOM:', error);
            // Re-abilita il pulsante anche in caso di errore
            Page.Widgets.buttonStoricizza.disabled = false;
            var errSt = (error && (error.message || error.errorMessage)) || (typeof error === 'string' ? error : '') || 'errore sconosciuto';
            App.showNotify('error', 'Errore durante la storicizzazione: ' + errSt);
        });
    } catch (error) {
        console.error('buttonStoricizzaClick:', error);
        // Re-abilita il pulsante anche in caso di eccezione
        Page.Widgets.buttonStoricizza.disabled = false;
        App.showNotify('error', 'Errore: ' + error.message);
    }
};

Page.buttonConfrStoriciClick = function ($event, widget) {
    try {
        var articoloCfr = articoloSelezionatoRow();
        var idArticolo = articoloCfr && articoloCfr.id;

        if (!idArticolo) {
            App.showNotify('warning', 'Nessun articolo selezionato');
            return;
        }

        console.log('Navigazione a confronto_storici per articolo ID:', idArticolo);

        // Naviga alla pagina confronto_storici
        App.Actions.goToPage_confronto_storici.invoke();
    } catch (error) {
        console.error('buttonConfrStoriciClick:', error);
        App.showNotify('error', 'Errore: ' + error.message);
    }
};

Page.dialogSelectListinoLavEstClick = function ($event, widget) {
    try {
        var listSel = Page.Widgets.LavEsterneList.selecteditem;
        var target = Page._bomLavEstListinoTarget;
        var selectedItem = (target && listSel && !Page._bomSameRowByElementoFornitore(target, listSel)) ? target : (listSel || target);
        var itemWidgets = Page._bomSameRowByElementoFornitore(selectedItem, listSel) ? Page.Widgets.LavEsterneList.selectedItemWidgets : null;
        var stagioneSelezionata = Page.Widgets.searchListinoLavEst.datavalue;

        Page._bomLavEstListinoTarget = null;

        // Aggiorna tipoC (dataset + widget)
        Page.updateBomItem('lavorazioniEsterne', selectedItem, 'tipoC', stagioneSelezionata, itemWidgets, 'textLavEsttipoC');

        // Recupera il costo dal listino lavorazioni esterne
        App.Variables.getCostoListinoLavEst.invoke({
            "inputFields": {
                "codiceFase": selectedItem.elemento,
                "fornitore": selectedItem.fornitoreTerzistaCodice,
                "stagione": stagioneSelezionata
            }
        }, function (data) {
            console.log('Costo lav. esterna trovato:', data);
            if (data != null) {
                var costo = parseFloat(data);
                if (!isNaN(costo)) {
                    Page.updateBomItem('lavorazioniEsterne', selectedItem, 'costUnit', costo, itemWidgets, 'textLavEstCostoUnit');
                }
            }
            Page.updateBomItem('lavorazioniEsterne', selectedItem, 'analizzato', false, itemWidgets, 'checkbox2');
            Page.Widgets.dialogSelectLavEst.close();
        }, function (error) {
            console.error('Errore recupero costo lav. esterne:', error);
            Page.Widgets.dialogSelectLavEst.close();
        });
    } catch (error) {
        console.error('dialogSelectListinoLavEstClick:', error);
    }
};


Page.pagedialogListinoMaterialiOk = function ($event, widget) {
    if (!Array.isArray(App.Variables.selectedRows) || App.Variables.selectedRows.length <= 0) {
        App.showNotify("warning", "Seleziona una riga");
        return;
    }

    if (App.Variables.selectedRows.length > 1) {
        App.showNotify("warning", "Puoi selezionare un listino alla volta");
        return;
    }

    try {
        // Recupero il listino selezionato da App.Variables.selectedRows
        var listinoSelezionato = App.Variables.selectedRows[0];
        var listSel = Page.Widgets.MaterialiList.selecteditem;
        var target = Page._bomMatListinoTarget;
        var selectedItem = (target && listSel && !Page._bomSameRowByElementoFornitore(target, listSel)) ? target : (listSel || target);
        var itemWidgets = Page._bomSameRowByElementoFornitore(selectedItem, listSel) ? Page.Widgets.MaterialiList.selectedItemWidgets : null;

        Page._bomMatListinoTarget = null;

        console.log("Listino selezionato:", listinoSelezionato);
        console.log("Materiale BOM:", selectedItem);

        // Aggiorna tipoC (stagione) nel BOM
        Page.updateBomItem('materiali', selectedItem, 'tipoC', listinoSelezionato.stagione, itemWidgets, 'textMattipoC');

        // Aggiorna il costo unitario con il prezzo del listino
        var costo = parseFloat(listinoSelezionato.prezzo);
        if (!isNaN(costo)) {
            Page.updateBomItem('materiali', selectedItem, 'costUnit', costo, itemWidgets, 'textMatCostoUnit');
            console.log("Costo aggiornato:", costo);
        }

        // Rimuovi la colorazione manuale visto che ora il prezzo viene dal listino
        if (itemWidgets && itemWidgets.textMatCostoUnit) {
            Page.rimuoviStiliValoreManuale(itemWidgets.textMatCostoUnit.$element.find('input'));
        }
        if (itemWidgets && itemWidgets.textMattipoC) {
            Page.rimuoviStiliValoreManuale(itemWidgets.textMattipoC.$element.find('input'));
        }

        Page.updateBomItem('materiali', selectedItem, 'analizzato', false, itemWidgets, 'checkboxConf');

        App.showNotify("success", "Listino importato con successo");
        Page.Widgets.pagedialogListinoMateriali.close();
    } catch (error) {
        console.error('pagedialogListinoMaterialiOk:', error);
        Page._bomMatListinoTarget = null;
        App.showNotify("error", "Errore durante l'importazione del listino");
    }
};

Page.buttonListinoMaterialiClick = function ($event, widget, item, currentItemWidgets) {
    // Pulisci selectedRows prima di aprire il dialog per evitare selezioni multiple residue
    App.Variables.selectedRows = [];

    var mat = item || (Page.Widgets.MaterialiList && Page.Widgets.MaterialiList.selecteditem);
    if (!mat || !mat.elemento) {
        App.showNotify("warning", "Riga materiali non disponibile: apri il listino dalla riga desiderata.");
        return;
    }
    Page._bomMatListinoTarget = mat;

    App.Variables.getStoricoListinoMateriali.invoke({
        "inputFields": {
            "ELEMENTO": mat.elemento || null,
            "FORNITORE": mat.fornitoreTerzistaCodice || null
        }
    }, function (data) {
        console.log("Ricerca completata:", data);
        Page.Widgets.pagedialogListinoMateriali.open();
    }, function (error) {
        console.error("Errore durante la ricerca:", error);
        Page._bomMatListinoTarget = null;
    });
};

Page.buttonListinoLavEstClick = function ($event, widget, item, currentItemWidgets) {
    // Parametri corretti per la ricerca in listino_lavorazioni_esterne:
    // - tipo_prodotto: codice scheda (es. "SUOLA") - da recuperare tramite schedaId
    // - codice_prodotto: codice articolo (es. "166306") - da articoloSelezionato
    // - codice_fase: elemento della lavorazione (es. "402") - da selecteditem
    // - fornitore: codice fornitore INTEGER (es. 2030118) - da fornitoreTerzistaCodice

    var lavEsterna = item || Page.Widgets.LavEsterneList.selecteditem;
    if (!lavEsterna || !lavEsterna.elemento) {
        App.showNotify("warning", "Riga lavorazione esterna non disponibile: apri il listino dalla riga desiderata.");
        return;
    }
    Page._bomLavEstListinoTarget = lavEsterna;

    var artRow = articoloSelezionatoRow();
    var codiceProdotto = artRow && artRow.articolo != null && String(artRow.articolo).trim() !== ''
        ? String(artRow.articolo).trim()
        : (lavEsterna.codiceSl != null ? String(lavEsterna.codiceSl).trim() : '');
    var codiceFase = lavEsterna.elemento != null ? String(lavEsterna.elemento).trim() : '';

    console.log("Ricerca listino conto lavoro per:", {
        "codice_prodotto": codiceProdotto,
        "codice_fase": codiceFase,
        "fornitoreCodice": lavEsterna.fornitoreTerzistaCodice
    });

    // Pulisci selectedRows prima di aprire il dialog per evitare selezioni multiple residue
    App.Variables.selectedRows = [];

    App.Variables.getListinoContoLavoro.invoke({
        "inputFields": {
            "codice_prodotto": codiceProdotto || null,
            "codice_fase": codiceFase || null,
            "fornitore": lavEsterna.fornitoreTerzistaCodice != null && lavEsterna.fornitoreTerzistaCodice !== ''
                ? String(lavEsterna.fornitoreTerzistaCodice).trim()
                : null
        }
    }, function (data) {
        console.log("Ricerca listino conto lavoro completata:", data);
        // La risposta è paginata - verifico data.content
        // if (data && data.content && data.content.length > 0) {

            Page.Widgets.pagedialogListinoContoLavoro.open();
        // } else {
        //     App.showNotify("warning", "Nessun listino trovato per i parametri specificati");
        // }
    }, function (error) {
        console.error("Errore durante la ricerca listino conto lavoro:", error);
        Page._bomLavEstListinoTarget = null;
    });
};

Page.pagedialogListinoContoLavoroOk = function ($event, widget) {
    if (!Array.isArray(App.Variables.selectedRows) || App.Variables.selectedRows.length <= 0) {
        App.showNotify("warning", "Seleziona una riga");
        return;
    }

    if (App.Variables.selectedRows.length > 1) {
        App.showNotify("warning", "Puoi selezionare una sola riga alla volta");
        return;
    }

    try {
        const selectedRow = App.Variables.selectedRows[0];
        const listSel = Page.Widgets.LavEsterneList.selecteditem;
        const target = Page._bomLavEstListinoTarget;
        const currentItem = (target && listSel && !Page._bomSameRowByElementoFornitore(target, listSel)) ? target : (listSel || target);
        const itemWidgets = Page._bomSameRowByElementoFornitore(currentItem, listSel) ? Page.Widgets.LavEsterneList.selectedItemWidgets : null;

        Page._bomLavEstListinoTarget = null;

        if (!currentItem) {
            App.showNotify("warning", "Nessuna riga selezionata nella lista lavorazioni esterne");
            return;
        }

        console.log("Importazione listino conto lavoro:", selectedRow);
        console.log("Riga corrente lavorazioni esterne:", currentItem);

        // Importa i dati dal listino selezionato usando updateBomItem
        // tipoC = stagione
        Page.updateBomItem('lavorazioniEsterne', currentItem, 'tipoC', selectedRow.stagione || '', itemWidgets, 'textLavEsttipoC');
        // costUnit = prezzo unitario
        Page.updateBomItem('lavorazioniEsterne', currentItem, 'costUnit', selectedRow.prezzo || 0, itemWidgets, 'textLavEstCostoUnit');

        // Rimuovi la colorazione manuale visto che ora il prezzo viene dal listino
        if (itemWidgets && itemWidgets.textLavEstCostoUnit) {
            Page.rimuoviStiliValoreManuale(itemWidgets.textLavEstCostoUnit.$element.find('input'));
        }
        if (itemWidgets && itemWidgets.textLavEsttipoC) {
            Page.rimuoviStiliValoreManuale(itemWidgets.textLavEsttipoC.$element.find('input'));
        }

        Page.updateBomItem('lavorazioniEsterne', currentItem, 'analizzato', false, itemWidgets, 'checkbox2');

        App.showNotify("success", "Listino importato con successo");
        Page.Widgets.pagedialogListinoContoLavoro.close();
    } catch (error) {
        console.error('pagedialogListinoContoLavoroOk:', error);
        Page._bomLavEstListinoTarget = null;
        App.showNotify("error", "Errore durante l'importazione del listino");
    }
};

// Gestione cambio costUnit per materiali - imposta tipoC = 'M' automaticamente
Page.onMatCostUnitChange = function ($event, widget, item, currentItemWidgets) {
    console.log('onMatCostUnitChange - item:', item, 'nuovo valore:', widget.datavalue);

    if (item) {
        Page.updateBomItem('materiali', item, 'costUnit', widget.datavalue || 0, currentItemWidgets, 'textMatCostoUnit');
        Page.updateBomItem('materiali', item, 'tipoC', 'M', currentItemWidgets, 'textMattipoC');
        Page.updateBomItem('materiali', item, 'analizzato', false, currentItemWidgets, 'checkboxConf');

        if (currentItemWidgets && currentItemWidgets.textMatCostoUnit) {
            Page.applicaStiliValoreManuale(currentItemWidgets.textMatCostoUnit.$element.find('input'));
        }
        if (currentItemWidgets && currentItemWidgets.textMattipoC) {
            Page.applicaStiliValoreManuale(currentItemWidgets.textMattipoC.$element.find('input'));
        }
    }
};

// Gestione cambio costUnit per lavorazioni esterne - imposta tipoC = 'M' automaticamente
Page.onMatTipoCChange = function ($event, widget, item, currentItemWidgets) {
    if (item) {
        Page.updateBomItem('materiali', item, 'analizzato', false, currentItemWidgets, 'checkboxConf');
    }
};

Page.onLavEstTipoCChange = function ($event, widget, item, currentItemWidgets) {
    if (item) {
        Page.updateBomItem('lavorazioniEsterne', item, 'analizzato', false, currentItemWidgets, 'checkbox2');
    }
};

Page.onLavEstCostUnitChange = function ($event, widget, item, currentItemWidgets) {
    console.log('onLavEstCostUnitChange - item:', item, 'nuovo valore:', widget.datavalue);

    if (item) {
        Page.updateBomItem('lavorazioniEsterne', item, 'costUnit', widget.datavalue || 0, currentItemWidgets, 'textLavEstCostoUnit');
        Page.updateBomItem('lavorazioniEsterne', item, 'tipoC', 'M', currentItemWidgets, 'textLavEsttipoC');
        Page.updateBomItem('lavorazioniEsterne', item, 'analizzato', false, currentItemWidgets, 'checkbox2');

        if (currentItemWidgets && currentItemWidgets.textLavEstCostoUnit) {
            Page.applicaStiliValoreManuale(currentItemWidgets.textLavEstCostoUnit.$element.find('input'));
        }
        if (currentItemWidgets && currentItemWidgets.textLavEsttipoC) {
            Page.applicaStiliValoreManuale(currentItemWidgets.textLavEsttipoC.$element.find('input'));
        }
    }
};
