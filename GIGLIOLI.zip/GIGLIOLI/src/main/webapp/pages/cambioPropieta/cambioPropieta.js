/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};
Page.anchor2Click = function ($event, widget, item, currentItemWidgets) {
    currentItemWidgets.containerDetailsArticoli.show = !currentItemWidgets.containerDetailsArticoli.show;
    currentItemWidgets.containerRows.show = !currentItemWidgets.containerRows.show;

};
Page.numberEuroPropostoChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {

};




Page.checkboxCodiceArticoloChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    console.log(item);
    if (newVal == false) {
        App.Variables.articoliSelezionati.removeItem(item);
    }
    if (newVal == true) {
        App.Variables.articoliSelezionati.addItem(item);
    }
    App.Variables.articoliSelezionati.setData(_.uniqBy(App.Variables.articoliSelezionati.getData(), 'id'));

    console.log(App.Variables.articoliSelezionati.getData());
};

Page.anchorArticoloClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.articoloSelezionato.setData(item);
    // Pulisci il pageParam storico_id per navigazione normale (non storico)
    App.Actions.goToPage_bom.navigate({
         data: {
                "storico_id": null,
            "articolo": item.articolo,
            "articolo_id": item.id
            }
    });
};

Page.cambiaProprietaonSuccess = function (variable, data) {
    var updatedRows = data && Array.isArray(data.content) ? data.content.length : 0;
    if (updatedRows <= 0) {
        App.showNotify("error", "Cambio proprietà non applicato: controlla selezione articoli/regole consentite.");
        return;
    }

    App.showNotify("success", "Cambio proprietà applicato a " + updatedRows + " articolo/i.");
    App.Variables.getMasterView.invoke();
};

Page.cambiaProprietaonError = function (variable, error) {
    var message = (error && (error.message || error.error || error.details)) || "Errore durante il cambio proprietà";
    App.showNotify("error", String(message));
};
