/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */
};



Partial.cambiaStatoonBeforeUpdate = function (variable, inputData, options) {
    //debugger;

    // inputData.lista_id_articoli_della_scheda = Partial.getIdDaCambiare();

};

Partial.cambiaStatoonSuccess = function (variable, data) {
    debugger;
    if (data.outSuccesso == 0) {
        App.showNotify("error", data.outMessaggio, "IMPOSSIBILE CAMBIARE STATO");
        return;
    }
    if (data.outSuccesso == 1) {
        if (App.activePageName == 'bom') App.activePage.Variables.bomArticolo.invoke();
        App.showNotify("success", data.outMessaggio, 'CAMBIO STATO AVVENUTO');
        App.Variables.getMasterView.invoke();
        return;
    }
};

Partial.cambiaStatoonError = function (variable, data, options) {
    var message = (data && (data.message || data.error || data.details)) || "Errore durante il cambio stato";
    App.showNotify("error", String(message));
};
