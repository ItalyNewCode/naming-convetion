/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    App.Variables.storiciSelezionati = [];
    Page.clearStoricoCheckboxSelection();
    Page.scheduleEnrichCrudBomHistoryPrezzo();
};

/**
 * Calcola prezzoPropostoStorico sul dataset crudBomHistory (colonna DB o fallback su bom_json).
 * Chiamare dopo ogni load/update della Live Variable, non tramite watch sullo scope Angular.
 */
Page.enrichCrudBomHistoryPrezzo = function () {
    if (typeof App.enrichBomHistoryRowsPrezzoProposto !== 'function' || !Page.Variables.crudBomHistory) {
        return;
    }
    App.enrichBomHistoryRowsPrezzoProposto(Page.Variables.crudBomHistory.dataSet);
};

/** Dopo il tick corrente (stesso pattern usato altrove con $timeout WM) così il dataset è aggiornato. */
Page.scheduleEnrichCrudBomHistoryPrezzo = function () {
    var $timeout = typeof App.getDependency === 'function' ? App.getDependency('$timeout') : null;
    if ($timeout) {
        $timeout(function () {
            Page.enrichCrudBomHistoryPrezzo();
        }, 0);
        return;
    }
    setTimeout(function () {
        Page.enrichCrudBomHistoryPrezzo();
    }, 0);
};

/** WM LiveVariable: dopo ogni read il dataset è popolato; senza questo l'enrich in onReady correva troppo presto. */
Page.crudBomHistoryonSuccess = function (variable, data, options) {
    Page.scheduleEnrichCrudBomHistoryPrezzo();
};

/** Svuota la selezione (come selectedRows nel listino dopo un’azione). */
Page.clearStoricoCheckboxSelection = function () {
    App.Variables.storiciSelezionati = [];
};

Page.getNextAggCode = function () {
    const ds = Page.Variables.crudRigheAggiuntive.dataSet || [];
    return "AGG" + (ds.length + 1).toString().padStart(2, "0");
};

Page.getCostoTotaleRiga = function (index) {

    const ds = Page.Variables.crudRigheAggiuntive.dataSet;

    if (!ds || !ds[index]) {
        console.warn("Indice riga non valido:", index);
        return 0;
    }

    const riga = ds[index];

    const cons = Number(riga.consUnit || 0);
    const costo = Number(riga.costoUnit || 0);

    return cons * costo;
};

Page.RigheAggiuntiveBomTable1_addNewRowAction = function ($event) {
    let record = {
        articolo: App.Variables.articoloSelezionato.dataSet.articolo,
        codice: Page.getNextAggCode(),
        consUnit: 1,
        costoUnit: 0,
        creationTimestamp: new Date(),
        descrizione: "",
        tipoC: "M",
        um: "paia"
    };

    Page.Variables.crudRigheAggiuntive.createRecord({ row: record })
        .then(function (res) {
            // Ricargo la CRUD (refresh)
            Page.Variables.crudRigheAggiuntive.update();
            console.log("Riga aggiunta con successo!");
        })
        .catch(function (err) {
            console.error(err);
            console.log("Errore durante l'inserimento");
        });
};

Page.RigheAggiuntiveBomTable1Beforerowupdate = function ($event, widget, row, options) {
    delete row.costoTot;
};

Page.anchorNoteClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.notaSelezionata.setValue("idRefTabella", App.Variables.articoloSelezionato.getData().id);
    App.Variables.notaSelezionata.setValue("tabella", "articoli");
    Page.Widgets.pagedialogNote.open();
};

/** Come Partial.checkbox2Change: solo App.Variables.storiciSelezionati. */
Page.checkboxStoricoChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    if (!Array.isArray(App.Variables.storiciSelezionati)) {
        App.Variables.storiciSelezionati = [];
    }
    if (!item || item.id == null) {
        return;
    }
    var id = item.id;
    var index = App.Variables.storiciSelezionati.findIndex(function (r) {
        return r && r.id === id;
    });
    if (newVal === true && index === -1) {
        App.Variables.storiciSelezionati.push(item);
    }
    if (newVal === false && index !== -1) {
        App.Variables.storiciSelezionati.splice(index, 1);
    }
};

Page.buttonApriSchedaClick = function ($event, widget) {
    try {
        var selezionati = App.Variables.storiciSelezionati || [];

        if (selezionati.length === 0) {
            App.showNotify('warning', 'Seleziona uno storico da visualizzare');
            return false;
        }

        if (selezionati.length > 1) {
            App.showNotify('warning', 'Puoi aprire solo uno storico alla volta');
            return false;
        }

        var storicoSelezionato = selezionati[0];

        // Verifica che lo storico selezionato sia valido
        if (!storicoSelezionato || !storicoSelezionato.bomJson) {
            console.error('Storico selezionato non valido:', storicoSelezionato);
            App.showNotify('error', 'Storico selezionato non valido');
            return false; // Blocca esecuzione
        }

        console.log('Storico selezionato:', storicoSelezionato);
        console.log('BOM JSON length:', storicoSelezionato.bomJson ? storicoSelezionato.bomJson.length : 0);

        // Naviga alla pagina BOM passando solo l'ID dello storico come pageParam
        App.Actions.goToPage_bom.invoke({
            data: {
                "storico_id": storicoSelezionato.id
            }
        });


    } catch (error) {
        console.error('buttonApriSchedaClick - Errore:', error);
        App.showNotify('error', 'Errore: ' + error.message);
        return false; // Blocca esecuzione
    }
};

Page.buttonEsportaClick = function ($event, widget) {
    try {
        // Prepara i dati per l'export
        var exportData = [];

        // Aggiungi riga header
        exportData.push([
            'Tipo',
            'Data Versione',
            'Consumo',
            'Costo Componenti',
            'Minuti Totali',
            'Costo Scheda',
            'Costo Totale',
            'Pareggio Lordo',
            'Prezzo Obiett. Netto',
            'Prezzo Obiett. Lordo',
            'Prezzo proposto',
            'Costo Min MOP',
            'Costo Min CGE'
        ]);

        // Aggiungi riga BOM attuale
        var bomAttuale = Page.Variables.bomArticolo.dataSet;
        if (bomAttuale) {
            exportData.push([
                'ATTUALE',
                bomAttuale.dataStatoPreventivo ? new Date(bomAttuale.dataStatoPreventivo).toLocaleString('it-IT') : '',
                '-',
                bomAttuale.costoScheda || 0,
                bomAttuale.minutiLavorazione || 0,
                bomAttuale.costoScheda || 0,
                bomAttuale.costoTotale || 0,
                bomAttuale.pareggioPrezzoLordo || 0,
                bomAttuale.obiettivoPrezzoNetto || 0,
                bomAttuale.obiettivoPrezzoLordo || 0,
                bomAttuale.propostoPrezzoLordo != null ? bomAttuale.propostoPrezzoLordo : '',
                bomAttuale.costoMinMop || 0,
                bomAttuale.costoMinCge || 0
            ]);
        }

        // Aggiungi righe storici
        var storici = Page.Variables.crudBomHistory.dataSet || [];
        Page.enrichCrudBomHistoryPrezzo();
        storici.forEach(function (storico) {
            exportData.push([
                'STORICO',
                storico.dataVersione ? new Date(storico.dataVersione).toLocaleString('it-IT') : '',
                storico.consumo || 0,
                storico.costoComponenti || 0,
                storico.minutiTotali || 0,
                storico.costoScheda || 0,
                storico.costoTotale || 0,
                storico.puntoPareggioLordo || 0,
                storico.prezzoObiettivoNetto || 0,
                storico.prezzoObiettivoLordo || 0,
                storico.prezzoPropostoStorico != null ? storico.prezzoPropostoStorico : '',
                storico.costoMinMop || 0,
                storico.costoMinCge || 0
            ]);
        });

        // Converti in CSV
        var csv = exportData.map(function (row) {
            return row.map(function (cell) {
                // Gestisci valori con virgole o virgolette
                var cellStr = String(cell);
                if (cellStr.indexOf(',') !== -1 || cellStr.indexOf('"') !== -1) {
                    return '"' + cellStr.replace(/"/g, '""') + '"';
                }
                return cellStr;
            }).join(',');
        }).join('\n');

        // Download del file
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        var link = document.createElement('a');
        var url = URL.createObjectURL(blob);

        var articolo = App.Variables.articoloSelezionato.dataSet.articolo || 'articolo';
        var filename = 'confronto_storici_' + articolo + '_' + new Date().toISOString().slice(0, 10) + '.csv';

        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        App.showNotify('success', 'Export completato: ' + filename);

    } catch (error) {
        console.error('buttonEsportaClick:', error);
        App.showNotify('error', 'Errore durante l\'export: ' + error.message);
    }
};

Page.buttonEliminaClick = function ($event, widget) {
    try {
        var selezionati = App.Variables.storiciSelezionati || [];

        if (selezionati.length === 0) {
            App.showNotify('warning', 'Seleziona uno storico da eliminare');
            return;
        }

        if (selezionati.length > 1) {
            App.showNotify('warning', 'Puoi eliminare solo uno storico alla volta');
            return;
        }

        Page.Widgets.confirmDeleteDialog.open();
    } catch (error) {
        console.error('buttonEliminaClick:', error);
        App.showNotify('error', 'Errore: ' + error.message);
    }
};

Page.confirmDeleteDialogOk = function ($event, widget) {
    var selezionati = App.Variables.storiciSelezionati || [];
    if (selezionati.length !== 1) {
        Page.Widgets.confirmDeleteDialog.close();
        return;
    }
    var storicoSelezionato = selezionati[0];
    Page.Variables.crudBomHistory.deleteRecord({
        row: storicoSelezionato
    }, function () {
        App.showNotify('success', 'Storico eliminato con successo');
        Page.clearStoricoCheckboxSelection();
        Page.Variables.crudBomHistory.update();
        Page.scheduleEnrichCrudBomHistoryPrezzo();
        Page.Widgets.confirmDeleteDialog.close();
    }, function (error) {
        console.error('Errore eliminazione storico:', error);
        App.showNotify('error', 'Errore durante l\'eliminazione: ' + (error && error.message ? error.message : 'errore sconosciuto'));
        Page.Widgets.confirmDeleteDialog.close();
    });
};

Page.confirmDeleteDialogCancel = function ($event, widget) {
    Page.Widgets.confirmDeleteDialog.close();
};

Page.buttonStoricizzaClick = function ($event, widget) {
    try {
        var bom = Page.Variables.bomArticolo.dataSet;
        var idArticolo = App.Variables.articoloSelezionato.dataSet.id || 18078; //SOlo per il testing hardcodo l'opzione 18078

        if (!bom || !idArticolo) {
            console.error('Nessun BOM o articolo caricato');
            return;
        }

        if (typeof App.bomAnalisiRigheComplete === 'function' && !App.bomAnalisiRigheComplete(Page.Variables.bomArticolo)) {
            var msgCs = (typeof App.bomAnalisiRigheMessaggioUtente === 'function')
                ? App.bomAnalisiRigheMessaggioUtente(Page.Variables.bomArticolo)
                : '';
            App.showNotify('error', msgCs || 'Spunta su ogni riga materiali e lavorazioni esterne prima di storicizzare.');
            return;
        }

        console.log('buttonStoricizzaClick - bom dataSet:', JSON.stringify(bom));
        console.log('buttonStoricizzaClick - pareggioPrezzoLordo:', bom.pareggioPrezzoLordo);
        console.log('buttonStoricizzaClick - esitoCalcolo:', bom.esitoCalcolo);

        console.log('Storicizzazione BOM in bom_history per articolo ID:', idArticolo);

        var bomJson = App.bomJsonSoloFlagAnalizzato(Page.Variables.bomArticolo, bom && bom.propostoPrezzoLordo);

        function parsePropostoStoricizza(v) {
            if (v === undefined || v === null || v === '') {
                return null;
            }
            if (typeof v === 'number' && isFinite(v)) {
                return v;
            }
            var n = parseFloat(String(v).replace(/\s/g, '').replace(',', '.'));
            return isNaN(n) ? null : n;
        }
        var propostoCs = parsePropostoStoricizza(bom && bom.propostoPrezzoLordo);
        var inputsCs = {
            idArticolo: idArticolo,
            bomJson: bomJson,
            clientBomJson: bomJson
        };
        if (propostoCs != null) {
            inputsCs.propostoPrezzoLordo = propostoCs;
        }

        // Usa il nuovo metodo storicizzaBom che salva in bom_history
        App.Variables.fxStoricizzaBom.invoke({
            "inputFields": inputsCs
        }, function (data) {
            console.log('Storicizzazione completata:', data);
            if (data) {
                // Aggiorna il BOM visualizzato con il flag storicizzato
                Page.Variables.bomArticolo.setData(data);
                App.showNotify('success', 'Distinta storicizzata con successo nello storico');

                // Ricarica la lista degli storici per mostrare il nuovo record
                Page.Variables.crudBomHistory.update();
                Page.scheduleEnrichCrudBomHistoryPrezzo();
            }
        }, function (error) {
            console.error('Errore storicizzazione BOM:', error);
            var errCs = (error && (error.message || error.errorMessage)) || (typeof error === 'string' ? error : '') || 'errore sconosciuto';
            App.showNotify('error', 'Errore durante la storicizzazione: ' + errCs);
        });
    } catch (error) {
        console.error('buttonStoricizzaClick:', error);
        App.showNotify('error', 'Errore: ' + error.message);
    }
};

Page.buttonEsciClick = function ($event, widget) {
    App.Variables.articoloSelezionato.setData(App.Variables.articoloSelezionato.dataSet);
    // Pulisci il pageParam storico_id per navigazione normale (non storico)
    App.Actions.goToPage_bom.navigate({
        data: {
           "storico_id": null,
            "articolo": item.articolo,
            "articolo_id": item.id
        }
    });
};
