/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */

    if (!App.__getMasterViewInvokeWrapped) {
        var originalInvoke = App.Variables.getMasterView.invoke.bind(App.Variables.getMasterView);
        App.Variables.getMasterView.invoke = function () {
            if (Partial.syncAutocompleteToGetMasterViewInput) {
                Partial.syncAutocompleteToGetMasterViewInput();
            }
            return originalInvoke.apply(this, arguments);
        };
        App.__getMasterViewInvokeWrapped = true;
    }
};


Partial.getIdDaCambiare = function () {



    const csvIds = App.Variables.articoliSelezionati.getData()
        .map(item => item.id)
        .join(',');
    if (_.isNil(csvIds)) return false;

    return (csvIds);
};


Partial.cambiaProprietaonSuccess = function (variable, data) {
    App.Variables.getMasterView.invoke();
};

Partial.getMasterViewForm1Success = function ($event, widget, $data) {
    App.activePage.Widgets.pagedialogCerca.close();
};

Partial.syncAutocompleteToGetMasterViewInput = function () {
    if (!Partial.Widgets || !Partial.Widgets.getMasterViewForm1 || !Partial.Widgets.getMasterViewForm1.formWidgets) {
        return;
    }

    var formWidgets = Partial.Widgets.getMasterViewForm1.formWidgets;

    function pickAutocompleteValue(fieldWidget) {
        if (!fieldWidget) {
            return null;
        }

        if (!App.isEmpty(fieldWidget.datavalue)) {
            return fieldWidget.datavalue;
        }

        var typedText = fieldWidget.query ||
            fieldWidget.queryModel ||
            fieldWidget.displayvalue ||
            fieldWidget.displayValue ||
            fieldWidget._displayValue ||
            fieldWidget.text;

        if (App.isEmpty(typedText)) {
            try {
                var domInputVal = null;
                if (fieldWidget.$element && fieldWidget.$element.find) {
                    domInputVal = fieldWidget.$element.find('input').val();
                }
                typedText = domInputVal || typedText;
            } catch (e) {
                // noop
            }
        }

        return App.isEmpty(typedText) ? null : typedText;
    }

    var nomeProgetto = pickAutocompleteValue(formWidgets.nomeProgetto);
    var codiceScheda = pickAutocompleteValue(formWidgets.codiceScheda);
    var descArticolo = pickAutocompleteValue(formWidgets.descArticolo);
    var codiceComponentiDistinta = pickAutocompleteValue(formWidgets.codiceComponentiDistinta);

    var campioneRaw = formWidgets.campione ? formWidgets.campione.datavalue : null;
    var campione = null;
    if (campioneRaw !== undefined && campioneRaw !== null && String(campioneRaw).trim() !== '') {
        campione = String(campioneRaw).trim().substring(0, 1).toUpperCase();
    }

    App.Variables.getMasterView.setInput('nomeProgetto', nomeProgetto);
    App.Variables.getMasterView.setInput('codiceScheda', codiceScheda);
    App.Variables.getMasterView.setInput('descArticolo', descArticolo);
    App.Variables.getMasterView.setInput('codiceComponentiDistinta', codiceComponentiDistinta);
    App.Variables.getMasterView.setInput('campione', campione);
};

Partial.getMasterViewForm1Before = function ($event, widget, $data) {
    Partial.syncAutocompleteToGetMasterViewInput();
};
