/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */


/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */
};
Partial.textSeacrhChange = function ($event, widget, newVal, oldVal) {
    App.Variables.getMasterView.setInput("search", newVal);
    App.Variables.getMasterView.invoke();
};

Partial.navigateHomeClick = function ($event, widget) {
    if (typeof App.navigateToLandingPageForCurrentUser === "function") {
        App.navigateToLandingPageForCurrentUser();
        return;
    }
    App.Actions.goToPage_master.invoke();
};
