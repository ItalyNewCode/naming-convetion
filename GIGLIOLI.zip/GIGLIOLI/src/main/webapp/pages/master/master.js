/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 
     * 'Page.Widgets.username.datavalue'
     */
    if (!App.ensurePageAccess('master')) {
        return;
    }

    // Default "no filtro confronto" quando entro in master.
    Page.Variables.getMasterView.setInput("articolo", null);
    Page.Variables.getMasterView.setInput("idsArticoli", [-1]);
    Page.Variables.getMasterView.invoke({
        articolo: null,
        idsArticoli: [-1],
        page: 1,
        size: 1
    });
};
Page.numberEuroPropostoChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    if (item && item.id && newVal !== null && newVal !== undefined) {
        // Aggiorna il valore nell'oggetto item
        item.propostoPrezzoLordo = parseFloat(newVal);

        // Aggiorna anche in articoliSelezionati se l'articolo è selezionato
        var articoliSel = App.Variables.articoliSelezionati.getData();
        if (Array.isArray(articoliSel)) {
            var articoloSel = articoliSel.find(function (a) { return a.id === item.id; });
            if (articoloSel) {
                articoloSel.propostoPrezzoLordo = parseFloat(newVal);
            }
        }
    }
};


Page.ArticoliList1Select = function (widget, $data, item, currentItemWidgets) {

};

Page._setSelectedArticoli = function (rows) {
    App.Variables.articoliSelezionati.setData(_.uniqBy(rows || [], 'id'));
};

Page._removeSelectedArticoloById = function (id) {
    var current = App.Variables.articoliSelezionati.getData() || [];
    Page._setSelectedArticoli(current.filter(function (row) {
        return !(row && row.id === id);
    }));
};

Page._addSelectedArticolo = function (item) {
    var current = App.Variables.articoliSelezionati.getData() || [];
    current.push(item);
    Page._setSelectedArticoli(current);
};


Page.checkboxCodiceArticoloChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    console.log(item);
    if (newVal === false) {
        Page._removeSelectedArticoloById(item && item.id);
    }
    if (newVal === true) {
        Page._addSelectedArticolo(item);
    }

    console.log(App.Variables.articoliSelezionati.getData());
};

Page.anchorArticoloClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.articoloSelezionato.setData(item);
    // Pulisci il pageParam storico_id per navigazione normale (non storico)
    App.Actions.goToPage_bom.navigate({
        data: {
            "storico_id": null,
            "articolo": item.articolo,
            "articolo_id": item.id
        }
    });
};


Page.checkboxAllArticoliChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {

    if (newVal === true) {
        currentItemWidgets.ArticoliList1.dataset.forEach((articolo, index) => {
            currentItemWidgets.ArticoliList1.selectItem(index);
            Page._addSelectedArticolo(articolo);
            currentItemWidgets.ArticoliList1.getItem(index)._currentItemWidgets.checkboxCodiceArticolo.datavalue = true;

        });
    }
    if (newVal === false) {
        currentItemWidgets.ArticoliList1.dataset.forEach((articolo, index) => {
            currentItemWidgets.ArticoliList1.deselectItem(index);
            Page._removeSelectedArticoloById(articolo && articolo.id);
            currentItemWidgets.ArticoliList1.getItem(index)._currentItemWidgets.checkboxCodiceArticolo.datavalue = false;

        });
    }
};


Page.anchorNoteClick = function ($event, widget, item, currentItemWidgets) {
    App.Variables.notaSelezionata.setValue("idRefTabella", item.id);
    App.Variables.notaSelezionata.setValue("tabella", "articoli");
    Page.Widgets.pagedialogNote.open();
};

Page._closeComunicatoNotaDialog = function () {
    var dlg = Page.Widgets.dialogNotaComunicazione;
    if (dlg && typeof dlg.close === "function") {
        dlg.close();
    }
};

Page.comunicatoNotaDialogClosed = function ($event, widget) {
    App.__comunicatoPendente = null;
};

Page.comunicatoNotaDialogAnnulla = function ($event, widget) {
    var ta = Page.Widgets.textareaNotaComunicazione;
    if (ta) {
        ta.datavalue = "";
    }
    Page._closeComunicatoNotaDialog();
    App.__comunicatoPendente = null;
};

Page.comunicatoNotaDialogConferma = function ($event, widget) {
    var pend = App.__comunicatoPendente;
    if (!pend || !pend.idArticolo) {
        App.showNotify("warning", "Sessione comunicato non valida: riprovare da Comunicato");
        Page.comunicatoNotaDialogAnnulla($event, widget);
        return;
    }
    var ta = Page.Widgets.textareaNotaComunicazione;
    var raw = ta ? ta.datavalue : "";
    var testoNota = (raw != null ? String(raw) : "").trim();
    if (!testoNota) {
        App.showNotify("warning", "Il testo della nota è obbligatorio");
        return;
    }

    var btn = typeof Partial !== "undefined" && Partial.Widgets ? Partial.Widgets.anchor7 : null;
    if (btn) {
        btn.disabled = true;
    }
    var preservedPage = pend.preservedPage;
    var preservedSize = pend.preservedSize;
    var idArticolo = pend.idArticolo;
    App.__comunicatoPendente = null;
    if (ta) {
        ta.datavalue = "";
    }
    Page._closeComunicatoNotaDialog();

    App.Variables.fxRegistraComunicato.invoke({
        inputFields: {
            idArticolo: idArticolo,
            testoNota: testoNota
        }
    }, function () {
        // TODO: generazione e salvataggio PDF comunicato (integrazione successiva).
        App.showNotify("success", "Comunicato registrato");
        App.Variables.getMasterView.setInput("page", preservedPage);
        App.Variables.getMasterView.setInput("size", preservedSize);
        App.Variables.getMasterView.invoke({
            page: preservedPage,
            size: preservedSize
        }, function () {
            var listWidget = App.activePage && App.activePage.Widgets ? App.activePage.Widgets.getMasterViewList1 : null;
            if (listWidget) {
                listWidget.currentPage = preservedPage;
            }
            if (btn) {
                btn.disabled = false;
            }
        }, function () {
            if (btn) {
                btn.disabled = false;
            }
        });
    }, function (error) {
        console.error("registraComunicato:", error);
        var msg = typeof App.formatServiceInvokeError === "function"
            ? App.formatServiceInvokeError(error, "errore")
            : (error && error.message ? error.message : "errore");
        App.showNotify("error", "Comunicato: " + msg);
        if (btn) {
            btn.disabled = false;
        }
    });
};

// Navigazione lista master - pulsante Indietro
Page.buttonPrevPageClick = function ($event, widget) {
    var currentPage = Page.Variables.getMasterView.dataSet.pageable ?
        Page.Variables.getMasterView.dataSet.pageable.pageNumber : 0;

    if (currentPage > 0) {
        // Decrementa la pagina e richiama la variabile
        Page.Variables.getMasterView.setInput('page', currentPage - 1);
        Page.Variables.getMasterView.invoke();
    }
};

// Navigazione lista master - pulsante Avanti
Page.buttonNextPageClick = function ($event, widget) {
    var currentPage = Page.Variables.getMasterView.dataSet.pageable ?
        Page.Variables.getMasterView.dataSet.pageable.pageNumber : 0;
    var totalPages = Page.Variables.getMasterView.dataSet.totalPages || 1;

    if (currentPage < totalPages - 1) {
        // Incrementa la pagina e richiama la variabile
        Page.Variables.getMasterView.setInput('page', currentPage + 1);
        Page.Variables.getMasterView.invoke();
    }
};
