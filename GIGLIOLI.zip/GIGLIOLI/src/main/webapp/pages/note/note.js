/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */
};

Partial.NoteLiveForm1Beforeservicecall = function ($event, $operation, $data, options) {
    console.log(App);
    $data.tabella = App.Variables.notaSelezionata.getData().tabella;
    $data.idRefTabella = App.Variables.notaSelezionata.getData().idRefTabella;


};
Partial.NoteLiveForm1Success = function ($event, $operation, $data) {
    var DialogService = App.getDependency('DialogService');
    DialogService.getOpenedDialogs().find(d => d.name === "pagedialogNote").close();
    // App.activePage.Widgets.pagedialogNote.close();
};

Partial.confirmDeleteDialogOk = function () {
    var itemToDelete = Partial.Variables.itemToDelete.getData();
    console.log('Conferma eliminazione, item:', itemToDelete);

    if (!itemToDelete) {
        console.error('Nessun item da eliminare');
        return;
    }

    // Usa tabella, idRefTabella e timestamp dall'item per eliminare solo questa nota specifica
    App.Variables.deleteNotaStoricaService.setInput({
        tabella: itemToDelete.tabella,
        idRefTabella: itemToDelete.idRefTabella,
        timestamp: itemToDelete.timestamp
    });

    App.Variables.deleteNotaStoricaService.invoke({}, function (response) {
        // Successo - ricarica la lista storico note
        Partial.Variables.NoteGetStoricoNote.invoke();
        Partial.Variables.itemToDelete.setData(null); // Reset
        Partial.Widgets.confirmDeleteDialog.close();
    }, function (error) {
        console.error('Errore eliminazione nota:', error);
    });
};
Partial.button1Click = function ($event, widget, item, currentItemWidgets) {
    // Salva l'item da eliminare nella Model Variable
    Partial.Variables.itemToDelete.setData(item);
    console.log('Item da eliminare:', item);
    // Apri il dialog di conferma nativo WaveMaker
    Partial.Widgets.confirmDeleteDialog.open();
};
