/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/**
 * Valore parametro: virgola decimale tipo 12,3 → 12.3 (solo se non c'è già il punto).
 */
function parametriNormalizeParamValue(v) {
    if (v === undefined || v === null || v === '') {
        return v;
    }
    var s = String(v).trim();
    if (s.indexOf('.') < 0 && s.indexOf(',') >= 0) {
        s = s.replace(',', '.');
    }
    return s;
}

/**
 * Riga MACC-X (da DB) → select "MACC" + suffisso nel G.T., così l'elenco resta solo MACC.
 */
function parametriNormalizeMaccRowForSelect(ds) {
    if (!ds || ds.paramKey == null) {
        return;
    }
    var pk = String(ds.paramKey).trim();
    if (pk === 'MACC') {
        return;
    }
    var m = pk.match(/^MACC-(.+)$/i);
    if (!m) {
        return;
    }
    var suff = m[1];
    if (ds.gt === undefined || ds.gt === null || String(ds.gt).trim() === '') {
        ds.gt = suff;
    }
    ds.paramKey = 'MACC';
}

/** All'apertura del dialog modifica/inserimento (select coerente con righe MACC-* già salvate). */
Page.ParametersLiveForm1Show = function ($event, widget) {
    var ds = App.Variables.crudParametri && App.Variables.crudParametri.dataSet;
    parametriNormalizeMaccRowForSelect(ds);
};

/**
 * Prima del salvataggio (insert/update): virgola decimale nel valore; MACC + G.T. → param_key MACC-{GT}.
 */
Page.ParametersLiveForm1Beforeservicecall = function ($event, $operation, $data, options) {
    if (!$data) {
        return true;
    }
    var op = String($operation || '').toLowerCase();
    if (op === 'delete') {
        return true;
    }

    $data.paramValue = parametriNormalizeParamValue($data.paramValue);
    parametriNormalizeMaccRowForSelect($data);

    var pk = $data.paramKey != null ? String($data.paramKey).trim() : '';
    if (!pk) {
        App.showNotify('error', 'Selezionare un parametro dall\'elenco.');
        return false;
    }

    if (pk === 'MACC' || /^MACC-/i.test(pk)) {
        var suffFromKey = null;
        var mm = pk.match(/^MACC-(.+)$/i);
        if (mm) {
            suffFromKey = mm[1];
        }
        var gRaw = $data.gt != null ? String($data.gt).trim() : '';
        var g = gRaw || (suffFromKey || '');
        if (!g) {
            App.showNotify('error', 'Per MACC è obbligatorio il G.T. (es. A, AB, …).');
            return false;
        }
        var gn = g.toUpperCase();
        $data.paramKey = 'MACC-' + gn;
        $data.gt = gn;
        return true;
    }

    return true;
};

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
};

Page.crudParametrionBeforeListRecords = function (variable, dataFilter, options) {

    console.log('variable:', variable);
    console.log('dataFilter:', dataFilter);
    console.log('options:', options);
    try {
        //    inputData.stagione = [{
        //         'value': Page.Widgets.textSearchStagione.datavalue,
        //         'filterCondition': 'CONTAINING',
        //         'type': 'TEXT'
        //     },
        //     {
        //         'value': Page.Widgets.textSearchStagione.datavalue,
        //         'filterCondition': 'IS_NOT_NULL',
        //         'type': 'TEXT'
        //     }];

        //     inputData.isActive = {
        //         'value': Page.Widgets.checkSearchAttive.datavalue,
        //         'filterCondition': 'EQUALS',
        //         'type': 'BOOLEAN'
        //     };
    } catch (Err) {
        console.log(Err);
    }
};

Page.checkSearchTutteChange = function ($event, widget, newVal, oldVal) {
    Page.Variables.crudParametri.invoke();
};

Page.crudParametrionBeforeDatasetReady = function (variable, data) {
    if (!data) {
        return;
    }

    var widgets = Page.Widgets || {};
    var stagioneValue = widgets.textSearchStagione ? widgets.textSearchStagione.datavalue : null;
    var attiveValue = widgets.checkSearchAttive ? widgets.checkSearchAttive.datavalue : null;
    var tutteValue = widgets.checkSearchTutte ? widgets.checkSearchTutte.datavalue : false;

    // "Tutte" means no filters.
    if (tutteValue === true) {
        delete data.stagione;
        delete data.isActive;
        return;
    }

    var hasStagione = !(stagioneValue === undefined || stagioneValue === null || String(stagioneValue).trim() === '');
    if (hasStagione) {
        data.stagione = [{
            'value': stagioneValue,
            'filterCondition': 'CONTAINING',
            'type': 'TEXT'
        }, {
            'value': stagioneValue,
            'filterCondition': 'IS_NOT_NULL',
            'type': 'TEXT'
        }];
    } else {
        delete data.stagione;
    }

    if (attiveValue === true || attiveValue === false) {
        data.isActive = {
            'value': attiveValue,
            'filterCondition': 'EQUALS',
            'type': 'BOOLEAN'
        };
    } else {
        delete data.isActive;
    }
};
