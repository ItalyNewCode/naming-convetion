/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    Partial._clearListinoContoLavoroSelection();
};

Partial._uncheckAllListinoContoLavoroListCheckboxes = function () {
    var list = Partial.Widgets.ListinoList;
    if (!list || !list.dataset) {
        return;
    }
    var n = list.dataset.length;
    var i;
    for (i = 0; i < n; i++) {
        try {
            var rowItem = list.getItem(i);
            if (rowItem && rowItem._currentItemWidgets && rowItem._currentItemWidgets.checkbox2) {
                rowItem._currentItemWidgets.checkbox2.datavalue = false;
            }
        } catch (e) {
            // riga non ancora renderizzata
        }
    }
};

Partial._clearListinoContoLavoroSelection = function () {
    App.Variables.selectedRows = [];
    Partial._uncheckAllListinoContoLavoroListCheckboxes();
    var all = Partial.Widgets.checkbo4All;
    if (all) {
        all.datavalue = false;
    }
};

Partial._upperDbString = function (val) {
    if (val === null || val === undefined) {
        return val;
    }
    var s = String(val);
    if (s === "") {
        return val;
    }
    return s.toUpperCase();
};

Partial._syncTextWidgetUppercase = function (widget) {
    if (!widget || widget.type === "number") {
        return;
    }
    var v = widget.datavalue;
    if (v === null || v === undefined) {
        return;
    }
    var s = String(v);
    var u = s.toUpperCase();
    if (u !== s) {
        widget.datavalue = u;
    }
};

Partial.uppercaseTextFieldNorm = function ($event, widget) {
    Partial._syncTextWidgetUppercase(widget);
};

Partial._normalizeListinoContoLavoroTextWidgets = function () {
    var names = [
        "textStagione",
        "textScheda",
        "textArticolo",
        "textFase",
        "textCodiceFornitore",
        "codSchedaSearchText",
        "articoloSearchText",
        "codiceFaseSearchText",
        "descFaseSearchText",
        "codFornitoreSearchText",
        "descFornitoreSearchText",
        "stagioneSearchText"
    ];
    for (var i = 0; i < names.length; i++) {
        var w = Partial.Widgets[names[i]];
        if (w) {
            Partial._syncTextWidgetUppercase(w);
        }
    }
};

Partial._parseProcedureEsitoBody = function (rawBody) {
    var d = rawBody;
    if (d == null) {
        return {};
    }
    if (typeof d === 'string') {
        try {
            d = JSON.parse(d);
        } catch (e) {
            return {};
        }
    }
    if (d && typeof d === 'object' && d.data !== undefined) {
        d = d.data;
        if (typeof d === 'string') {
            try {
                d = JSON.parse(d);
            } catch (e2) {
                return {};
            }
        }
    }
    return d && typeof d === 'object' ? d : {};
};

Partial._procedureEsitoIsError = function (d) {
    return d.esito === 1 || d.esito === '1';
};

Partial._procedureUserMessage = function (d) {
    if (d.messaggio === undefined || d.messaggio === null) {
        return '';
    }
    return String(d.messaggio);
};

Partial._procedurePresentOutcome = function (d, labels) {
    labels = labels || {};
    var okDefault = labels.ok || 'Operazione completata.';
    var errDefault = labels.err || 'Operazione non completata.';
    var failNoNewRows =
        labels.failNoNewRows ||
        "Non è stata aggiunta nessuna riga al listino. Contatta l'assistenza informatica se il problema si ripete.";

    var raw = Partial._procedureUserMessage(d);
    var err = Partial._procedureEsitoIsError(d);

    var nDup = d.duplicati !== undefined && d.duplicati !== null ? Number(d.duplicati) : NaN;
    var nIns = d.inseriti !== undefined && d.inseriti !== null ? Number(d.inseriti) : NaN;
    var hasRows = (!isNaN(nDup) && nDup > 0) || (!isNaN(nIns) && nIns > 0);

    if (!err) {
        return {
            notifyType: 'success',
            message: raw || okDefault,
            reloadList: true
        };
    }

    if (hasRows) {
        var n = !isNaN(nDup) && nDup > 0 ? nDup : nIns;
        var countTxt = isNaN(n) ? '' : ' Righe elaborate: ' + n + '.';
        return {
            notifyType: 'warning',
            message: (labels.warnWithRows || 'Operazione registrata con un avviso.') + countTxt + ' Controlla la lista.',
            reloadList: true
        };
    }

    var lower = (raw || '').toLowerCase();
    var isGenIgnored =
        lower.indexOf('generated column') >= 0 &&
        (lower.indexOf('has been ignored') >= 0 || lower.indexOf('ignored') >= 0);
    if (isGenIgnored) {
        console.warn('Procedura listino: esito errore e 0 righe. Messaggio server:', raw);
        return {
            notifyType: 'error',
            message: failNoNewRows,
            reloadList: false
        };
    }

    return {
        notifyType: 'error',
        message: raw || errDefault,
        reloadList: false
    };
};

Partial.anchorNoteClick = function ($event, widget, item, currentItemWidgets) {
    console.log($event, widget, item, currentItemWidgets);
    App.Variables.notaSelezionata.setValue("idRefTabella", item.id);
    App.Variables.notaSelezionata.setValue("tabella", "listino_lavorazioni_esterne");
    Partial.Widgets.pagedialogNote.open();
};

Partial.button3Click = function ($event, widget) {
    if (!Array.isArray(App.Variables.selectedRows) || App.Variables.selectedRows.length <= 0) {
        App.showNotify("warning", "Seleziona una riga");
        return;
    }

    if (App.Variables.selectedRows.length > 1) {
        App.showNotify("warning", "Puoi cancellare una riga alla volta");
        return;
    }

    // apro conferma
    Partial.Widgets.confirmDeleteDialog.open();
};

Partial.confirmDeleteDialogOk = function ($event, widget) {
    // Usa la CRUD per cancellare dalla tabella listino_lavorazioni_esterne
    App.Variables.crudLavorazioniEsterne.deleteRecord({
        "row": App.Variables.selectedRows[0]
    }, function (data) {
        console.log("Cancellazione completata:", data);
        App.showNotify("success", "Riga cancellata correttamente");
        Partial._clearListinoContoLavoroSelection();
        App.Variables.getListinoContoLavoro.invoke();
        Partial.Widgets.confirmDeleteDialog.close();
    }, function (error) {
        console.error("Errore durante la cancellazione:", error);
        App.showNotify("error", "Errore durante la cancellazione");
        Partial.Widgets.confirmDeleteDialog.close();
    });
};

Partial.checkbox2Change = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {

    if (!Array.isArray(App.Variables.selectedRows)) {
        App.Variables.selectedRows = [];
    }

    const id = item.id;
    const index = App.Variables.selectedRows.findIndex(r => r.id === id);

    if (newVal === true && index === -1) {
        App.Variables.selectedRows.push(item);
    }

    if (newVal === false && index !== -1) {
        App.Variables.selectedRows.splice(index, 1);
    }
};

Partial.button1Click = function ($event, widget) {
    Partial._normalizeListinoContoLavoroTextWidgets();
    if (!App.isEmpty(Partial.Widgets.textStagione.datavalue) && !App.isEmpty(Partial.Widgets.textDataValidita.datavalue) && App.Variables.selectedRows.length > 0) {
        Partial.Widgets.confirmDuplication.open();
    } else {
        App.showNotify("warning", "La procedura di duplicazione funziona SOLO se sono compilati esclusivamente i campi stagione e data di validità e hai almeno un listino dalla lista selezionato.");
    }
};

Partial.duplica_listino_conto_lavoroonError = function (variable, data) {
    // Gestito in confirmDuplicationOk (invoke con callback).
};

Partial.duplica_listino_conto_lavoroonSuccess = function (variable, data) {
    // Gestito in confirmDuplicationOk (invoke con callback).
};

Partial.button2Click = function ($event, widget) {
    Partial._normalizeListinoContoLavoroTextWidgets();
    if (!App.isEmpty(Partial.Widgets.textStagione.datavalue) && !App.isEmpty(Partial.Widgets.textDataValidita.datavalue) && !App.isEmpty(Partial.Widgets.textPrezzoUm1.datavalue) && App.Variables.selectedRows.length > 0) {
        Partial.Widgets.confirmRinnovo.open();
    } else {
        App.showNotify("warning", "La procedura di rinnovo funziona SOLO se sono compilati esclusivamente i campi stagione, prezzo e data di validità e hai almeno un listino dalla lista selezionato.");
    }
};

Partial.buttonCreaClick = function ($event, widget) {
    Partial._normalizeListinoContoLavoroTextWidgets();
    if (!App.isEmpty(Partial.Widgets.textStagione.datavalue) &&
        !App.isEmpty(Partial.Widgets.textDataValidita.datavalue) &&
        !App.isEmpty(Partial.Widgets.textPrezzoUm1.datavalue) &&
        !App.isEmpty(Partial.Widgets.textScheda.datavalue) &&
        !App.isEmpty(Partial.Widgets.textArticolo.datavalue) &&
        !App.isEmpty(Partial.Widgets.textFase.datavalue) &&
        !App.isEmpty(Partial.Widgets.textCodiceFornitore.datavalue)) {
        Partial.Widgets.confirmCreation.open();
    } else {
        App.showNotify("warning", "La procedura di creazione funziona SOLO se sono compilati tutti i campi: scheda, articolo, fase, fornitore, stagione, prezzo e data di validità.");
    }
};

Partial.rinnovo_listino_conto_lavoroonError = function (variable, data) {
    // Gestito in confirmRinnovoOk (invoke con callback).
};

Partial.rinnovo_listino_conto_lavoroonSuccess = function (variable, data) {
    // Gestito in confirmRinnovoOk (invoke con callback).
};

Partial.confirmDuplicationOk = function ($event, widget) {
    Partial._normalizeListinoContoLavoroTextWidgets();
    let selectedIds = App.Variables.selectedRows.map(r => r.id).filter(id => id !== undefined && id !== null);

    if (selectedIds.length === 0) {
        App.showNotify("warning", "Nessun record selezionato");
        Partial.Widgets.confirmDuplication.close();
        return;
    }

    if (Partial.Widgets.button1) {
        Partial.Widgets.button1.disabled = true;
    }
    if (widget) {
        widget.disabled = true;
    }

    App.Variables.duplica_listino_conto_lavoro.invoke({
        "inputFields": {
            "ID_LIST": selectedIds.join(','),
            "STAGIONE": Partial._upperDbString(Partial.Widgets.textStagione.datavalue),
            "FINE_VALIDITA": Partial.Widgets.textDataValidita.datavalue
        }
    }, function (data) {
        console.log("Duplicazione completata:", data);
        var d = Partial._parseProcedureEsitoBody(data);
        var pres = Partial._procedurePresentOutcome(d, {
            ok: "Duplicazione completata.",
            err: "Duplicazione non completata.",
            failNoNewRows: "Duplicazione non riuscita: nessun listino nuovo. Chiedi all'assistenza (serve verifica su database)."
        });
        App.showNotify(pres.notifyType, pres.message);
        if (pres.reloadList) {
            Partial._clearListinoContoLavoroSelection();
            App.Variables.getListinoContoLavoro.invoke();
        }
        Partial.Widgets.confirmDuplication.close();
        if (Partial.Widgets.button1) {
            Partial.Widgets.button1.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    }, function (error) {
        console.error("Errore durante la duplicazione:", error);
        App.showNotify("error", "Errore di rete o server durante la duplicazione");
        Partial.Widgets.confirmDuplication.close();
        if (Partial.Widgets.button1) {
            Partial.Widgets.button1.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    });
};

Partial.confirmRinnovoOk = function ($event, widget) {
    Partial._normalizeListinoContoLavoroTextWidgets();
    let selectedIds = App.Variables.selectedRows.map(r => r.id).filter(id => id !== undefined && id !== null);

    if (selectedIds.length === 0) {
        App.showNotify("warning", "Nessun record selezionato");
        Partial.Widgets.confirmRinnovo.close();
        return;
    }

    if (Partial.Widgets.button2) {
        Partial.Widgets.button2.disabled = true;
    }
    if (widget) {
        widget.disabled = true;
    }

    App.Variables.rinnovo_listino_conto_lavoro.invoke({
        "inputFields": {
            "ID_LIST": selectedIds.join(','),
            "STAGIONE": Partial._upperDbString(Partial.Widgets.textStagione.datavalue),
            "FINE_VALIDITA": Partial.Widgets.textDataValidita.datavalue,
            "PREZZO": Partial.Widgets.textPrezzoUm1.datavalue
        }
    }, function (data) {
        console.log("Rinnovo completato:", data);
        var d = Partial._parseProcedureEsitoBody(data);
        var pres = Partial._procedurePresentOutcome(d, {
            ok: "Rinnovo completato.",
            err: "Rinnovo non completato.",
            failNoNewRows: "Rinnovo non riuscito: nessuna riga nuova. Chiedi all'assistenza (serve verifica su database)."
        });
        App.showNotify(pres.notifyType, pres.message);
        if (pres.reloadList) {
            Partial._clearListinoContoLavoroSelection();
            App.Variables.getListinoContoLavoro.invoke();
        }
        Partial.Widgets.confirmRinnovo.close();
        if (Partial.Widgets.button2) {
            Partial.Widgets.button2.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    }, function (error) {
        console.error("Errore durante il rinnovo:", error);
        App.showNotify("error", "Errore di rete o server durante il rinnovo");
        Partial.Widgets.confirmRinnovo.close();
        if (Partial.Widgets.button2) {
            Partial.Widgets.button2.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    });
};

Partial.confirmCreationOk = function ($event, widget) {
    console.log("=== INIZIO confirmCreationOk - Listino Conto Lavoro ===");
    Partial._normalizeListinoContoLavoroTextWidgets();

    // Raccolgo i dati dai campi di input
    const scheda = Partial._upperDbString(Partial.Widgets.textScheda.datavalue);
    const articolo = Partial._upperDbString(Partial.Widgets.textArticolo.datavalue);
    const fase = Partial._upperDbString(Partial.Widgets.textFase.datavalue);
    const codiceFornitore = Partial._upperDbString(Partial.Widgets.textCodiceFornitore.datavalue);
    const stagione = Partial._upperDbString(Partial.Widgets.textStagione.datavalue);
    const dataValidita = Partial.Widgets.textDataValidita.datavalue;
    const prezzo = Partial.Widgets.textPrezzoUm1.datavalue;

    console.log("Scheda:", scheda);
    console.log("Articolo:", articolo);
    console.log("Fase:", fase);
    console.log("Codice Fornitore:", codiceFornitore);
    console.log("Stagione:", stagione);
    console.log("Data Validità:", dataValidita);
    console.log("Prezzo:", prezzo);

    if (Partial.Widgets.buttonCrea) {
        Partial.Widgets.buttonCrea.disabled = true;
    }
    if (widget) {
        widget.disabled = true;
    }

    var reenableCrea = function () {
        if (Partial.Widgets.buttonCrea) {
            Partial.Widgets.buttonCrea.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    };

    // Uso la stored procedure crea_listino_conto_lavoro
    App.Variables.crea_listino_conto_lavoro.invoke({
        "inputFields": {
            "TIPO_PRODOTTO": scheda,
            "CODICE_PRODOTTO": articolo,
            "CODICE_FASE": fase,
            "DESCRIZIONE_FASE": Partial._upperDbString("FASE " + fase),
            "FORNITORE": codiceFornitore,
            "DESCRIZIONE_FORNITORE": Partial._upperDbString("FORNITORE " + codiceFornitore),
            "PREZZO": prezzo,
            "FINE_VALIDITA": dataValidita,
            "STAGIONE": stagione
        }
    }, function (data) {
        console.log("Creazione completata:", data);
        var d = Partial._parseProcedureEsitoBody(data);
        var pres = Partial._procedurePresentOutcome(d, {
            ok: "Listino conto lavoro creato con successo.",
            err: "Creazione non completata.",
            failNoNewRows: "Creazione non riuscita. Chiedi all'assistenza se il problema si ripete."
        });
        App.showNotify(pres.notifyType, pres.message);
        if (pres.reloadList) {
            Partial.Widgets.textScheda.datavalue = "";
            Partial.Widgets.textArticolo.datavalue = "";
            Partial.Widgets.textFase.datavalue = "";
            Partial.Widgets.textCodiceFornitore.datavalue = "";
            Partial.Widgets.textStagione.datavalue = "";
            Partial.Widgets.textDataValidita.datavalue = null;
            Partial.Widgets.textPrezzoUm1.datavalue = null;
            Partial._clearListinoContoLavoroSelection();
            App.Variables.getListinoContoLavoro.setInput('codice_prodotto', Partial.pageParams.codice_prodotto);
            App.Variables.getListinoContoLavoro.setInput('codice_fase', Partial.pageParams.codice_fase);
            App.Variables.getListinoContoLavoro.setInput('fornitore', Partial.pageParams.fornitore);
            App.Variables.getListinoContoLavoro.invoke();
        }
        Partial.Widgets.confirmCreation.close();
        reenableCrea();
    }, function (error) {
        console.error("Errore durante la creazione:", error);
        App.showNotify("error", "Errore durante la creazione del listino");
        Partial.Widgets.confirmCreation.close();
        reenableCrea();
    });
};

Partial._cloneRowForUpdate = function (row) {
    if (!row) {
        return {};
    }
    try {
        return JSON.parse(JSON.stringify(row));
    } catch (e) {
        return Object.assign({}, row);
    }
};

Partial._getListinoContoLavoroRowById = function (id) {
    var dataSet = (App.Variables.getListinoContoLavoro && App.Variables.getListinoContoLavoro.dataSet) || [];
    for (var i = 0; i < dataSet.length; i++) {
        if (dataSet[i] && dataSet[i].id === id) {
            return dataSet[i];
        }
    }
    return null;
};

Partial._buildLavorazioniEsterneUpdatePayload = function (sourceRow, id) {
    var allowedFields = [
        "id",
        "tipoProdotto",
        "codiceProdotto",
        "codiceFase",
        "descrizioneFase",
        "fornitore",
        "descrizioneFornitore",
        "prezzo",
        "inizioValidita",
        "fineValidita",
        "stagione"
    ];
    var payload = { id: id };
    if (!sourceRow) {
        return payload;
    }
    var stringUpperFields = {
        tipoProdotto: true,
        codiceProdotto: true,
        codiceFase: true,
        descrizioneFase: true,
        descrizioneFornitore: true,
        stagione: true
    };
    for (var i = 0; i < allowedFields.length; i++) {
        var field = allowedFields[i];
        if (sourceRow[field] !== undefined) {
            var val = sourceRow[field];
            if (stringUpperFields[field] && val !== null && val !== undefined) {
                val = Partial._upperDbString(val);
            }
            payload[field] = val;
        }
    }
    payload.id = id;
    return payload;
};

Partial._toDateValue = function (value) {
    if (App.isEmpty(value)) {
        return null;
    }
    if (value instanceof Date) {
        return value.toISOString().slice(0, 10);
    }
    var strVal = String(value);
    if (strVal.indexOf("T") > -1) {
        return strVal.split("T")[0];
    }
    return strVal;
};

Partial.validitaDateChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    widget.bordercolor = '#0d6efd';
    widget.borderwidth = '2px';
    widget.borderstyle = 'solid';

    if (!item || App.isEmpty(item.id)) {
        return;
    }

    Partial._dirtyListinoContoLavoro = Partial._dirtyListinoContoLavoro || {};
    var dirty = Partial._dirtyListinoContoLavoro[item.id] || { id: item.id };
    if (!dirty.originalRow) {
        dirty.originalRow = Partial._cloneRowForUpdate(item);
    }
    dirty.fineValidita = newVal;
    dirty.validitaWidget = widget;
    if (currentItemWidgets && currentItemWidgets.prezzoText) {
        dirty.prezzoWidget = currentItemWidgets.prezzoText;
    }
    Partial._dirtyListinoContoLavoro[item.id] = dirty;
};

Partial.prezzoTextChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    widget.bordercolor = '#0d6efd';
    widget.borderwidth = '2px';
    widget.borderstyle = 'solid';

    if (!item || App.isEmpty(item.id)) {
        return;
    }

    Partial._dirtyListinoContoLavoro = Partial._dirtyListinoContoLavoro || {};
    var dirty = Partial._dirtyListinoContoLavoro[item.id] || { id: item.id };
    if (!dirty.originalRow) {
        dirty.originalRow = Partial._cloneRowForUpdate(item);
    }
    dirty.prezzo = newVal;
    dirty.prezzoWidget = widget;
    if (currentItemWidgets && currentItemWidgets.date5) {
        dirty.validitaWidget = currentItemWidgets.date5;
    }
    Partial._dirtyListinoContoLavoro[item.id] = dirty;
};

Partial.button7Click = function ($event, widget) {
    Partial._dirtyListinoContoLavoro = Partial._dirtyListinoContoLavoro || {};
    var dirtyRows = Object.keys(Partial._dirtyListinoContoLavoro).map(function (k) { return Partial._dirtyListinoContoLavoro[k]; });

    if (!dirtyRows.length) {
        App.showNotify("warning", "Nessuna modifica da salvare");
        return;
    }

    Partial._normalizeListinoContoLavoroTextWidgets();
    widget.disabled = true;

    var clearBlueBorder = function (wmWidget) {
        if (!wmWidget) {
            return;
        }
        wmWidget.bordercolor = '';
        wmWidget.borderwidth = '';
        wmWidget.borderstyle = '';
    };

    var index = 0;
    var salvati = 0;
    var errori = 0;

    var salvaProssimo = function () {
        if (index >= dirtyRows.length) {
            widget.disabled = false;
            var cp = Partial.pageParams.codice_prodotto;
            var cf = Partial.pageParams.codice_fase;
            var fo = Partial.pageParams.fornitore;
            App.Variables.getListinoContoLavoro.setInput('codice_prodotto', cp ? Partial._upperDbString(cp) : null);
            App.Variables.getListinoContoLavoro.setInput('codice_fase', cf ? Partial._upperDbString(cf) : null);
            App.Variables.getListinoContoLavoro.setInput('fornitore', fo ? Partial._upperDbString(fo) : null);
            if (salvati > 0) {
                Partial._clearListinoContoLavoroSelection();
                App.Variables.getListinoContoLavoro.invoke();
            }
            if (errori === 0) {
                App.showNotify("success", "Modifiche salvate correttamente");
            } else if (salvati > 0) {
                App.showNotify("warning", "Salvataggio parziale: " + salvati + " ok, " + errori + " errori");
            } else {
                App.showNotify("error", "Errore durante il salvataggio");
            }
            return;
        }

        var row = dirtyRows[index++];
        var sourceRow = Partial._getListinoContoLavoroRowById(row.id) || row.originalRow || { id: row.id };
        var payload = Partial._buildLavorazioniEsterneUpdatePayload(sourceRow, row.id);

        if (row.prezzo !== undefined) {
            payload.prezzo = row.prezzo;
        }
        if (row.fineValidita !== undefined) {
            payload.fineValidita = Partial._toDateValue(row.fineValidita);
        }

        App.Variables.crudLavorazioniEsterne.updateRecord({
            "row": payload
        }, function () {
            salvati++;
            clearBlueBorder(row.prezzoWidget);
            clearBlueBorder(row.validitaWidget);
            delete Partial._dirtyListinoContoLavoro[row.id];
            salvaProssimo();
        }, function (error) {
            errori++;
            console.error("Errore salvataggio riga listino conto lavoro id=" + row.id, error);
            salvaProssimo();
        });
    };

    salvaProssimo();
};
Partial.button8_1Click = function ($event, widget) {
    // Binding manuale dei parametri di ricerca alla query
    // IMPORTANTE: tipo_prodotto = scheda (es. "SUOLA"), codice_prodotto = articolo (es. "166306")
    Partial._normalizeListinoContoLavoroTextWidgets();
    Partial._clearListinoContoLavoroSelection();
    App.Variables.getListinoContoLavoro.invoke({
        "inputFields": {
            "tipo_prodotto": Partial._upperDbString(Partial.Widgets.codSchedaSearchText.datavalue) || null,
            "codice_prodotto": Partial._upperDbString(Partial.Widgets.articoloSearchText.datavalue) || null,
            "codice_fase": Partial._upperDbString(Partial.Widgets.codiceFaseSearchText.datavalue) || null,
            "descrizione_fase": Partial._upperDbString(Partial.Widgets.descFaseSearchText.datavalue) || null,
            "fornitore": Partial._upperDbString(Partial.Widgets.codFornitoreSearchText.datavalue) || null,
            "descrizione_fornitore": Partial._upperDbString(Partial.Widgets.descFornitoreSearchText.datavalue) || null,
            "stagione": Partial._upperDbString(Partial.Widgets.stagioneSearchText.datavalue) || null,
            "fine_validita": Partial.Widgets.validitaSearchText.datavalue || null,
            "prezzo": Partial.Widgets.prezzoSearchText.datavalue || null
        }
    }, function (data) {
        console.log("Ricerca completata:", data);
    }, function (error) {
        console.error("Errore durante la ricerca:", error);
        App.showNotify("error", "Errore durante la ricerca");
    });
};
