/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /* Stato coerente ad ogni ingresso nel partial (dialog BOM o pagina listino): niente checkbox “appese” a sessioni precedenti. */
    Partial._clearListinoMaterialiSelection();
};

/** Smarca tutte le checkbox riga del listino (non sono bindate a selectedRows). */
Partial._uncheckAllListinoMaterialiListCheckboxes = function () {
    var list = Partial.Widgets.ListinoList;
    if (!list || !list.dataset) {
        return;
    }
    var n = list.dataset.length;
    var i;
    for (i = 0; i < n; i++) {
        try {
            var rowItem = list.getItem(i);
            if (rowItem && rowItem._currentItemWidgets && rowItem._currentItemWidgets.checkbox2) {
                rowItem._currentItemWidgets.checkbox2.datavalue = false;
            }
        } catch (e) {
            // riga non ancora renderizzata (es. lista on-demand)
        }
    }
};

/** Azzera la selezione manuale e allinea la UI (checkbox + eventuale “seleziona tutti”). */
Partial._clearListinoMaterialiSelection = function () {
    App.Variables.selectedRows = [];
    Partial._uncheckAllListinoMaterialiListCheckboxes();
    var all = Partial.Widgets.checkbo4All;
    if (all) {
        all.datavalue = false;
    }
};

/** Valore stringa per DB/query: sempre maiuscolo. */
Partial._upperDbString = function (val) {
    if (val === null || val === undefined) {
        return val;
    }
    var s = String(val);
    if (s === "") {
        return val;
    }
    return s.toUpperCase();
};

Partial._syncTextWidgetUppercase = function (widget) {
    if (!widget || widget.type === "number") {
        return;
    }
    var v = widget.datavalue;
    if (v === null || v === undefined) {
        return;
    }
    var s = String(v);
    var u = s.toUpperCase();
    if (u !== s) {
        widget.datavalue = u;
    }
};

Partial.uppercaseTextFieldNorm = function ($event, widget) {
    Partial._syncTextWidgetUppercase(widget);
};

Partial._normalizeListinoMaterialiTextWidgets = function () {
    var names = [
        "textStagione",
        "textCodiceMateriale",
        "textCodiceFornitore",
        "codMatSearchText",
        "descMatSearchText",
        "codFornSearchText",
        "descFornSearchText",
        "stagioneSearchText",
        "um1SearchText",
        "um2SearchText"
    ];
    for (var i = 0; i < names.length; i++) {
        var w = Partial.Widgets[names[i]];
        if (w) {
            Partial._syncTextWidgetUppercase(w);
        }
    }
};

/** Normalizza il body delle procedure (JSON stringa, wrapper WaveMaker `data`, ecc.). */
Partial._parseProcedureEsitoBody = function (rawBody) {
    var d = rawBody;
    if (d == null) {
        return {};
    }
    if (typeof d === 'string') {
        try {
            d = JSON.parse(d);
        } catch (e) {
            return {};
        }
    }
    if (d && typeof d === 'object' && d.data !== undefined) {
        d = d.data;
        if (typeof d === 'string') {
            try {
                d = JSON.parse(d);
            } catch (e2) {
                return {};
            }
        }
    }
    return d && typeof d === 'object' ? d : {};
};

Partial._procedureEsitoIsError = function (d) {
    return d.esito === 1 || d.esito === '1';
};

Partial._procedureUserMessage = function (d) {
    if (d.messaggio === undefined || d.messaggio === null) {
        return '';
    }
    return String(d.messaggio);
};

/**
 * Testo notifica da esito procedura. Messaggi brevi per l'utente; dettaglio tecnico solo in console.
 * labels.failNoNewRows: messaggio se esito negativo e 0 righe (opzionale, per duplica/rinnovo/crea).
 */
Partial._procedurePresentOutcome = function (d, labels) {
    labels = labels || {};
    var okDefault = labels.ok || 'Operazione completata.';
    var errDefault = labels.err || 'Operazione non completata.';
    var failNoNewRows =
        labels.failNoNewRows ||
        "Non è stata aggiunta nessuna riga al listino. Contatta l'assistenza informatica se il problema si ripete.";

    var raw = Partial._procedureUserMessage(d);
    var err = Partial._procedureEsitoIsError(d);

    var nDup = d.duplicati !== undefined && d.duplicati !== null ? Number(d.duplicati) : NaN;
    var nIns = d.inseriti !== undefined && d.inseriti !== null ? Number(d.inseriti) : NaN;
    var hasRows = (!isNaN(nDup) && nDup > 0) || (!isNaN(nIns) && nIns > 0);

    if (!err) {
        return {
            notifyType: 'success',
            message: raw || okDefault,
            reloadList: true
        };
    }

    if (hasRows) {
        var n = !isNaN(nDup) && nDup > 0 ? nDup : nIns;
        var countTxt = isNaN(n) ? '' : ' Righe elaborate: ' + n + '.';
        return {
            notifyType: 'warning',
            message: (labels.warnWithRows || 'Operazione registrata con un avviso.') + countTxt + ' Controlla la lista.',
            reloadList: true
        };
    }

    var lower = (raw || '').toLowerCase();
    var isGenIgnored =
        lower.indexOf('generated column') >= 0 &&
        (lower.indexOf('has been ignored') >= 0 || lower.indexOf('ignored') >= 0);
    if (isGenIgnored) {
        console.warn('Procedura listino: esito errore e 0 righe. Messaggio server:', raw);
        return {
            notifyType: 'error',
            message: failNoNewRows,
            reloadList: false
        };
    }

    return {
        notifyType: 'error',
        message: raw || errDefault,
        reloadList: false
    };
};

Partial.anchorNoteClick = function ($event, widget, item, currentItemWidgets) {
    console.log($event, widget, item, currentItemWidgets);
    App.Variables.notaSelezionata.setValue("idRefTabella", item.id);
    App.Variables.notaSelezionata.setValue("tabella", "listino_materiali");
    Partial.Widgets.pagedialogNote.open()
};

Partial.button3Click = function ($event, widget) {
    if (!Array.isArray(App.Variables.selectedRows) || App.Variables.selectedRows.length <= 0) {
        App.showNotify("warning", "Seleziona una riga");
        return;
    }

    if (App.Variables.selectedRows.length > 1) {
        App.showNotify("warning", "Puoi cancellare una riga alla volta");
        return;
    }

    // apro conferma
    Partial.Widgets.confirmDeleteDialog.open();
};

Partial.confirmDeleteDialogOk = function ($event, widget) {

    App.Variables.delete4ListinoMateriali.invoke({
        "inputFields": {
            "id": App.Variables.selectedRows[0].id
        }
    }, function (data) {
        console.log("Cancellazione completata:", data);
        App.showNotify("success", "Riga cancellata correttamente");
        Partial._clearListinoMaterialiSelection();
        App.Variables.getStoricoListinoMateriali.invoke();
        Partial.Widgets.confirmDeleteDialog.close();
    }, function (error) {
        console.error("Errore durante la cancellazione:", error);
        App.showNotify("error", "Errore durante la cancellazione");
        Partial.Widgets.confirmDeleteDialog.close();
    });
};

Partial.checkbox2Change = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {

    if (!Array.isArray(App.Variables.selectedRows)) {
        App.Variables.selectedRows = [];
    }

    const id = item.id;
    const index = App.Variables.selectedRows.findIndex(r => r.id === id);

    if (newVal === true && index === -1) {
        App.Variables.selectedRows.push(item);
    }

    if (newVal === false && index !== -1) {
        App.Variables.selectedRows.splice(index, 1);
    }
};

Partial.button1Click = function ($event, widget) {
    Partial._normalizeListinoMaterialiTextWidgets();
    if (!App.isEmpty(Partial.Widgets.textStagione.datavalue) && !App.isEmpty(Partial.Widgets.textDataValidita.datavalue) && App.Variables.selectedRows.length > 0) {
        Partial.Widgets.confirmDuplication.open();
    } else {
        App.showNotify("warning", "La procedura di duplicazione funziona SOLO se sono compilati esclusivamente i campi stagione e data di validità e hai almeno un listino dalla lista selezionato.");
    }
};

Partial.duplica_listino_materialionError = function (variable, data) {
    // La duplicazione è gestita in confirmDuplicationOk (invoke con callback).
};

Partial.duplica_listino_materialionSuccess = function (variable, data) {
    // La duplicazione è gestita in confirmDuplicationOk (invoke con callback).
};

Partial.button2Click = function ($event, widget) {
    Partial._normalizeListinoMaterialiTextWidgets();
    if (!App.isEmpty(Partial.Widgets.textStagione.datavalue) && !App.isEmpty(Partial.Widgets.textDataValidita.datavalue) && !App.isEmpty(Partial.Widgets.textPrezzoUm1.datavalue) && App.Variables.selectedRows.length > 0) {
        Partial.Widgets.confirmRinnovo.open();
    } else {
        App.showNotify("warning", "La procedura di rinnovo funziona SOLO se sono compilati esclusivamente i campi stagione, prezzo e data di validità e hai almeno un listino dalla lista selezionato.");
    }
};

Partial.buttonCreaClick = function ($event, widget) {
    Partial._normalizeListinoMaterialiTextWidgets();
    if (!App.isEmpty(Partial.Widgets.textStagione.datavalue) && !App.isEmpty(Partial.Widgets.textDataValidita.datavalue) && !App.isEmpty(Partial.Widgets.textPrezzoUm1.datavalue) && !App.isEmpty(Partial.Widgets.textCodiceMateriale.datavalue) && !App.isEmpty(Partial.Widgets.textCodiceFornitore.datavalue)) {
        Partial.Widgets.confirmCreation.open();
    } else {
        App.showNotify("warning", "La procedura di creazione funziona SOLO se sono compilati tutti i campi stagione, prezzo, codice materiale, codice fornitore e data di validità.");
    }
};

Partial.nuovo_listino_materialionError = function (variable, data) {
    // Il rinnovo è gestito in confirmRinnovoOk (invoke con callback).
};

Partial.nuovo_listino_materialionSuccess = function (variable, data) {
    // Il rinnovo è gestito in confirmRinnovoOk (invoke con callback).
};

Partial.confirmDuplicationOk = function ($event, widget) {
    Partial._normalizeListinoMaterialiTextWidgets();
    var selectedIds = App.Variables.selectedRows.map(function (r) { return r.id; }).filter(function (id) { return id !== undefined && id !== null; });
    if (selectedIds.length === 0) {
        App.showNotify("warning", "Nessun record selezionato");
        Partial.Widgets.confirmDuplication.close();
        return;
    }
    App.Variables.duplica_listino_materiali.setInput("ID_LIST", selectedIds.join(','));
    App.Variables.duplica_listino_materiali.setInput("STAGIONE", Partial._upperDbString(Partial.Widgets.textStagione.datavalue));
    App.Variables.duplica_listino_materiali.setInput("FINE_VALIDITA", Partial.Widgets.textDataValidita.datavalue);

    if (Partial.Widgets.button1) {
        Partial.Widgets.button1.disabled = true;
    }
    if (widget) {
        widget.disabled = true;
    }

    App.Variables.duplica_listino_materiali.invoke({}, function (data) {
        var d = Partial._parseProcedureEsitoBody(data);
        var pres = Partial._procedurePresentOutcome(d, {
            ok: "Duplicazione completata.",
            err: "Duplicazione non completata.",
            failNoNewRows: "Duplicazione non riuscita: nessun listino nuovo. Chiedi all'assistenza (serve verifica su database)."
        });
        App.showNotify(pres.notifyType, pres.message);
        if (pres.reloadList) {
            Partial._clearListinoMaterialiSelection();
            App.Variables.getStoricoListinoMateriali.invoke();
        }
        Partial.Widgets.confirmDuplication.close();
        if (Partial.Widgets.button1) {
            Partial.Widgets.button1.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    }, function (error) {
        console.error("duplica_listino_materiali:", error);
        App.showNotify("error", "Errore di rete o server durante la duplicazione");
        Partial.Widgets.confirmDuplication.close();
        if (Partial.Widgets.button1) {
            Partial.Widgets.button1.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    });
};

Partial.confirmRinnovoOk = function ($event, widget) {
    Partial._normalizeListinoMaterialiTextWidgets();
    var selectedIds = App.Variables.selectedRows.map(function (r) { return r.id; }).filter(function (id) { return id !== undefined && id !== null; });
    if (selectedIds.length === 0) {
        App.showNotify("warning", "Nessun record selezionato");
        Partial.Widgets.confirmRinnovo.close();
        return;
    }
    App.Variables.nuovo_listino_materiali.setInput("ID_LIST", selectedIds.join(','));
    App.Variables.nuovo_listino_materiali.setInput("STAGIONE", Partial._upperDbString(Partial.Widgets.textStagione.datavalue));
    App.Variables.nuovo_listino_materiali.setInput("PREZZO", Partial.Widgets.textPrezzoUm1.datavalue);
    App.Variables.nuovo_listino_materiali.setInput("FINE_VALIDITA", Partial.Widgets.textDataValidita.datavalue);

    if (Partial.Widgets.button2) {
        Partial.Widgets.button2.disabled = true;
    }
    if (widget) {
        widget.disabled = true;
    }

    App.Variables.nuovo_listino_materiali.invoke({}, function (data) {
        var d = Partial._parseProcedureEsitoBody(data);
        var pres = Partial._procedurePresentOutcome(d, {
            ok: "Rinnovo completato.",
            err: "Rinnovo non completato.",
            failNoNewRows: "Rinnovo non riuscito: nessuna riga nuova. Chiedi all'assistenza (serve verifica su database)."
        });
        App.showNotify(pres.notifyType, pres.message);
        if (pres.reloadList) {
            Partial._clearListinoMaterialiSelection();
            App.Variables.getStoricoListinoMateriali.invoke();
        }
        Partial.Widgets.confirmRinnovo.close();
        if (Partial.Widgets.button2) {
            Partial.Widgets.button2.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    }, function (error) {
        console.error("nuovo_listino_materiali:", error);
        App.showNotify("error", "Errore di rete o server durante il rinnovo");
        Partial.Widgets.confirmRinnovo.close();
        if (Partial.Widgets.button2) {
            Partial.Widgets.button2.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    });
};

Partial.confirmCreationOk = function ($event, widget) {
    console.log("=== INIZIO confirmCreationOk ===");
    Partial._normalizeListinoMaterialiTextWidgets();

    // Costruisco il parametro per AS400: "ELEMENTO!FORNITORE"
    const codiceMateriale = Partial._upperDbString(Partial.Widgets.textCodiceMateriale.datavalue);
    const codiceFornitore = Partial._upperDbString(Partial.Widgets.textCodiceFornitore.datavalue);
    const parametroAS400 = codiceMateriale + "!" + codiceFornitore;

    console.log("Codice Materiale:", codiceMateriale);
    console.log("Codice Fornitore:", codiceFornitore);
    console.log("Parametro AS400:", parametroAS400);
    console.log("Stagione:", Partial.Widgets.textStagione.datavalue);
    console.log("Data Validità:", Partial.Widgets.textDataValidita.datavalue);
    console.log("Prezzo:", Partial.Widgets.textPrezzoUm1.datavalue);

    if (Partial.Widgets.buttonCrea) {
        Partial.Widgets.buttonCrea.disabled = true;
    }
    if (widget) {
        widget.disabled = true;
    }
    var reenableCreaUi = function () {
        if (Partial.Widgets.buttonCrea) {
            Partial.Widgets.buttonCrea.disabled = false;
        }
        if (widget) {
            widget.disabled = false;
        }
    };

    // Chiamo AS400 per recuperare i dati mancanti
    console.log("Chiamata AS400 in corso...");
    App.Variables.getListinoForAS400.invoke({
        "inputFields": {
            "lis01": parametroAS400
        }
    }, function (dataAS400) {
        console.log("=== RISPOSTA AS400 ===");
        console.log("Dati recuperati da AS400:", dataAS400);

        // I dati sono dentro l'array dati[0]
        const datiAS400 = dataAS400.dati && dataAS400.dati.length > 0 ? dataAS400.dati[0] : null;

        if (!datiAS400) {
            console.error("Nessun dato trovato nella risposta AS400");
            App.showNotify("error", "Materiale non trovato in AS400");
            Partial.Widgets.confirmCreation.close();
            reenableCreaUi();
            return;
        }

        console.log("DESCRIZIONE_COMPONENTE:", datiAS400.DESCRIZIONE_COMPONENTE);
        console.log("UM1:", datiAS400.UM1);
        console.log("UM2:", datiAS400.UM2);
        console.log("UM1DIVISOUM2:", datiAS400.UM1DIVISOUM2);
        console.log("FORNITORE:", datiAS400.FORNITORE);

        // AS400 spesso restituisce UM2 vuoto per articoli a una sola unità; il servizio crea_listino_materiale richiede UM2 valorizzato.
        var um1 = Partial._upperDbString((datiAS400.UM1 != null ? String(datiAS400.UM1) : "").trim());
        var um2Raw = Partial._upperDbString((datiAS400.UM2 != null ? String(datiAS400.UM2) : "").trim());
        var um2 = (um2Raw || um1 || "").trim();
        if (!um2) {
            um2 = "-";
        }
        var convNum = datiAS400.UM1DIVISOUM2 != null && datiAS400.UM1DIVISOUM2 !== "" ? Number(datiAS400.UM1DIVISOUM2) : NaN;
        var conversione;
        if (!um2Raw) {
            conversione = 1;
        } else if (!isNaN(convNum) && convNum > 0) {
            conversione = convNum;
        } else {
            conversione = 1;
        }

        // Preparo i parametri per la creazione
        const parametriCreazione = {
            "CODICE_MAT": codiceMateriale,
            "CODICE_FORN": codiceFornitore,
            "STAGIONE": Partial._upperDbString(Partial.Widgets.textStagione.datavalue),
            "FINE_VALIDITA": Partial.Widgets.textDataValidita.datavalue,
            "PREZZO": Partial.Widgets.textPrezzoUm1.datavalue,
            "DESCRIZIONE_MATERIALE": Partial._upperDbString(datiAS400.DESCRIZIONE_COMPONENTE || ""),
            "UM1": um1,
            "UM2": um2,
            "CONVERSIONE": conversione,
            "DESCRIZIONE_FORNITORE": Partial._upperDbString(datiAS400.FORNITORE || "")
        };

        console.log("=== PARAMETRI CREAZIONE ===");
        console.log("Parametri completi:", parametriCreazione);

        // Invoco la creazione passando tutti i parametri (inclusi quelli da AS400)
        console.log("Invocazione crea_listino_materiale...");
        App.Variables.crea_listino_materiale.invoke({
            "inputFields": parametriCreazione
        }, function (success) {
            console.log("Risultato creazione:", success);
            var d = Partial._parseProcedureEsitoBody(success);
            var pres = Partial._procedurePresentOutcome(d, {
                ok: "Creazione completata.",
                err: "Creazione non completata.",
                failNoNewRows: "Creazione non riuscita. Chiedi all'assistenza se il problema si ripete."
            });
            App.showNotify(pres.notifyType, pres.message);
            if (pres.reloadList) {
                Partial._clearListinoMaterialiSelection();
                App.Variables.getStoricoListinoMateriali.invoke();
            }
            Partial.Widgets.confirmCreation.close();
            reenableCreaUi();
        }, function (error) {
            console.error("Errore durante la creazione:", error);
            var errText = "";
            if (error) {
                if (typeof error === "string") {
                    errText = error;
                } else if (error.message) {
                    errText = String(error.message);
                } else if (error.body && error.body.message) {
                    errText = String(error.body.message);
                }
            }
            App.showNotify("error", errText || "Errore durante la creazione");
            Partial.Widgets.confirmCreation.close();
            reenableCreaUi();
        });

    }, function (errorAS400) {
        console.error("Errore durante il recupero dati da AS400:", errorAS400);
        App.showNotify("error", "Errore durante il recupero dati da AS400");
        Partial.Widgets.confirmCreation.close();
        reenableCreaUi();
    });
};

Partial._cloneRowForUpdate = function (row) {
    if (!row) {
        return {};
    }
    try {
        return JSON.parse(JSON.stringify(row));
    } catch (e) {
        return Object.assign({}, row);
    }
};

Partial._getListinoMaterialiRowById = function (id) {
    var dataSet = (App.Variables.getStoricoListinoMateriali && App.Variables.getStoricoListinoMateriali.dataSet) || [];
    for (var i = 0; i < dataSet.length; i++) {
        if (dataSet[i] && dataSet[i].id === id) {
            return dataSet[i];
        }
    }
    return null;
};

Partial._buildListinoMaterialiUpdatePayload = function (sourceRow, id) {
    // Only DB-updatable columns for ListinoMateriali.
    // NOTE: pum2 is a DB generated column, must never be sent in PUT/UPDATE.
    var allowedFields = [
        "id",
        "elemento",
        "descrizioneMateriale",
        "fornitore",
        "descrizioneFornitore",
        "prezzo",
        "um1",
        "um2",
        "conversione",
        "inizioValidita",
        "fineValidita",
        "stagione"
    ];
    var payload = { id: id };
    if (!sourceRow) {
        return payload;
    }
    var stringUpperFields = {
        elemento: true,
        descrizioneMateriale: true,
        descrizioneFornitore: true,
        um1: true,
        um2: true,
        stagione: true
    };
    for (var i = 0; i < allowedFields.length; i++) {
        var field = allowedFields[i];
        if (sourceRow[field] !== undefined) {
            var val = sourceRow[field];
            if (stringUpperFields[field] && val !== null && val !== undefined) {
                val = Partial._upperDbString(val);
            }
            payload[field] = val;
        }
    }
    payload.id = id;
    return payload;
};

Partial._toPatchDate = function (value) {
    if (App.isEmpty(value)) {
        return null;
    }
    if (value instanceof Date) {
        return value.toISOString().slice(0, 10);
    }
    var strVal = String(value);
    if (strVal.indexOf("T") > -1) {
        return strVal.split("T")[0];
    }
    return strVal;
};

Partial._waveUpdateListinoMateriali = function (id, sourceRow, changedData, onSuccess, onError) {
    var lv = App.Variables.crudListinoMateriali;
    if (!lv) {
        onError({ message: "Variabile crudListinoMateriali non trovata" });
        return;
    }

    // Native Wave updateRecord with full row + overridden changed fields.
    var rowForUpdate = Partial._buildListinoMaterialiUpdatePayload(sourceRow, id);
    if (changedData.prezzo !== undefined) {
        rowForUpdate.prezzo = changedData.prezzo;
    }
    if (changedData.fineValidita !== undefined) {
        rowForUpdate.fineValidita = changedData.fineValidita;
    }
    lv.updateRecord({ row: rowForUpdate }, onSuccess, onError);
};

Partial.validitaDateChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    widget.bordercolor = '#0d6efd';
    widget.borderwidth = '2px';
    widget.borderstyle = 'solid';

    if (!item || App.isEmpty(item.id)) {
        return;
    }

    Partial._dirtyListinoMateriali = Partial._dirtyListinoMateriali || {};
    var dirty = Partial._dirtyListinoMateriali[item.id] || { id: item.id };
    if (!dirty.originalRow) {
        dirty.originalRow = Partial._cloneRowForUpdate(item);
    }
    dirty.fineValidita = newVal;
    dirty.validitaWidget = widget;
    if (currentItemWidgets && currentItemWidgets.prezzoUM1Text) {
        dirty.prezzoWidget = currentItemWidgets.prezzoUM1Text;
    }
    Partial._dirtyListinoMateriali[item.id] = dirty;
};

Partial.prezzoUM1TextChange = function ($event, widget, item, currentItemWidgets, newVal, oldVal) {
    widget.bordercolor = '#0d6efd';
    widget.borderwidth = '2px';
    widget.borderstyle = 'solid';

    if (!item || App.isEmpty(item.id)) {
        return;
    }

    Partial._dirtyListinoMateriali = Partial._dirtyListinoMateriali || {};
    var dirty = Partial._dirtyListinoMateriali[item.id] || { id: item.id };
    if (!dirty.originalRow) {
        dirty.originalRow = Partial._cloneRowForUpdate(item);
    }
    dirty.prezzo = newVal;
    dirty.prezzoWidget = widget;
    if (currentItemWidgets && currentItemWidgets.validitaDate) {
        dirty.validitaWidget = currentItemWidgets.validitaDate;
    }
    Partial._dirtyListinoMateriali[item.id] = dirty;
};

Partial.button7Click = function ($event, widget) {
    Partial._dirtyListinoMateriali = Partial._dirtyListinoMateriali || {};
    var dirtyRows = Object.keys(Partial._dirtyListinoMateriali).map(function (k) { return Partial._dirtyListinoMateriali[k]; });

    if (!dirtyRows.length) {
        App.showNotify("warning", "Nessuna modifica da salvare");
        return;
    }

    Partial._normalizeListinoMaterialiTextWidgets();
    widget.disabled = true;

    var clearBlueBorder = function (wmWidget) {
        if (!wmWidget) {
            return;
        }
        wmWidget.bordercolor = '';
        wmWidget.borderwidth = '';
        wmWidget.borderstyle = '';
    };

    var index = 0;
    var salvati = 0;
    var errori = 0;

    var salvaProssimo = function () {
        if (index >= dirtyRows.length) {
            widget.disabled = false;
            var elParam = Partial.pageParams.elemento || Partial.Widgets.codMatSearchText.datavalue;
            var foParam = Partial.pageParams.fornitore || Partial.Widgets.codFornSearchText.datavalue;
            App.Variables.getStoricoListinoMateriali.setInput('ELEMENTO', elParam ? Partial._upperDbString(elParam) : null);
            App.Variables.getStoricoListinoMateriali.setInput('FORNITORE', foParam ? Partial._upperDbString(foParam) : null);
            if (salvati > 0) {
                Partial._clearListinoMaterialiSelection();
                App.Variables.getStoricoListinoMateriali.invoke();
            }
            if (errori === 0) {
                App.showNotify("success", "Modifiche salvate correttamente");
            } else if (salvati > 0) {
                App.showNotify("warning", "Salvataggio parziale: " + salvati + " ok, " + errori + " errori");
            } else {
                App.showNotify("error", "Errore durante il salvataggio");
            }
            return;
        }

        var row = dirtyRows[index++];
        var sourceRow = Partial._getListinoMaterialiRowById(row.id) || row.originalRow || { id: row.id };
        var changedPayload = {};
        if (row.prezzo !== undefined) {
            changedPayload.prezzo = row.prezzo;
        }
        if (row.fineValidita !== undefined) {
            changedPayload.fineValidita = Partial._toPatchDate(row.fineValidita);
        }

        Partial._waveUpdateListinoMateriali(row.id, sourceRow, changedPayload, function () {
            salvati++;
            clearBlueBorder(row.prezzoWidget);
            clearBlueBorder(row.validitaWidget);
            delete Partial._dirtyListinoMateriali[row.id];
            salvaProssimo();
        }, function (error) {
            errori++;
            console.error("Errore salvataggio riga listino materiali id=" + row.id, error);
            salvaProssimo();
        });
    };

    salvaProssimo();
};
Partial.button10_1Click = function ($event, widget) {
    // Binding manuale dei parametri di ricerca alla query
    Partial._normalizeListinoMaterialiTextWidgets();
    Partial._clearListinoMaterialiSelection();
    App.Variables.getStoricoListinoMateriali.invoke({
        "inputFields": {
            "ELEMENTO": Partial._upperDbString(Partial.Widgets.codMatSearchText.datavalue) || null,
            "DESCRIZIONE_FORNITORE": Partial._upperDbString(Partial.Widgets.descFornSearchText.datavalue) || null,
            "DESCRIZIONE_MATERIALE": Partial._upperDbString(Partial.Widgets.descMatSearchText.datavalue) || null,
            "FORNITORE": Partial._upperDbString(Partial.Widgets.codFornSearchText.datavalue) || null,
            "PREZZO": Partial.Widgets.prezzoUM1SearchText.datavalue || null,
            "UM1": Partial._upperDbString(Partial.Widgets.um1SearchText.datavalue) || null,
            "PUM2": Partial.Widgets.prezzoUM2SearchText.datavalue || null,
            "UM2": Partial._upperDbString(Partial.Widgets.um2SearchText.datavalue) || null,
            "CONVERSIONE": Partial.Widgets.conversioneSearchText.datavalue || null,
            "FINE_VALIDITA": Partial.Widgets.validitaSearchText.datavalue || null,
            "STAGIONE": Partial._upperDbString(Partial.Widgets.stagioneSearchText.datavalue) || null
        }
    }, function (data) {
        console.log("Ricerca completata:", data);
    }, function (error) {
        console.error("Errore durante la ricerca:", error);
        App.showNotify("error", "Errore durante la ricerca");
    });
};
