/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function () {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
};

Page.setButtonDisabled = function (widget, disabled) {
    if (widget) {
        widget.disabled = disabled;
    }
};

Page.buttonAssociaClick = function ($event, widget) {
    Page.setButtonDisabled(widget, true);
    const selectedIds = App.Variables.loadSchedeByProjectName.dataSet
        .filter(s => s.selected)
        .map(s => s.id);

    if (selectedIds.length === 0) {
        Page.setButtonDisabled(widget, false);
        return;
    }

    var selectedProject = Page.Widgets.searchByProjectName && Page.Widgets.searchByProjectName.datavalue;
    if (!selectedProject || !selectedProject.id) {
        Page.setButtonDisabled(widget, false);
        Page.Actions.notificationError.invoke({
            title: "Errore",
            text: "Seleziona un progetto prima di associare",
            alerttype: "error"
        });
        return;
    }

    Page.Variables.associa_schede.invoke({
        inputFields: {
            ids: selectedIds.join(','),
            id_progetto: selectedProject.id
        }
    }, function () {
        Page.setButtonDisabled(widget, false);
    }, function () {
        Page.setButtonDisabled(widget, false);
    });
};

Page.buttonDisassociaClick = function ($event, widget) {
    Page.setButtonDisabled(widget, true);
    const selectedIds = App.Variables.loadSchedeByProjectName.dataSet
        .filter(s => s.selected)
        .map(s => s.id);

    if (selectedIds.length === 0) {
        Page.setButtonDisabled(widget, false);
        return;
    }

    Page.Variables.associa_schede.invoke({
        inputFields: {
            ids: selectedIds.join(','),
            id_progetto: -1
        }
    }, function () {
        Page.setButtonDisabled(widget, false);
    }, function () {
        Page.setButtonDisabled(widget, false);
    });
};

Page.buttonNewProjectClick = function ($event, widget) {
    const nome = Page.Widgets.searchByProjectName.query;
    const desc = "";

    try {
        if (!nome || !nome.trim()) {
            Page.Actions.notificationError.invoke({
                "class": "error",
                "message": "Inserisci un nome progetto valido",
                "position": "bottom right"
            });
            return;
        }

        App.Variables.crudProgetti.createRecord({
            row: {
                nome: nome.trim(),
                descrizione: desc.trim()
            }
        }, function (data) {
            // record creato dal backend
            const nuovoProgetto = data;

            // seleziona automaticamente l'autocomplete
            Page.Widgets.searchByProjectName.datavalue = nuovoProgetto;

            // opzionale: svuota query
            // Page.Widgets.searchByProjectName.query = "";
        }
        );
    } catch (error) { console.error(error); }

};

Page.buttonDelProjectClick = function ($event, widget) {
    Page.setButtonDisabled(widget, true);
    const progetto = Page.Widgets.searchByProjectName.datavalue;

    if (!progetto || !progetto.id) {
        Page.setButtonDisabled(widget, false);
        Page.Actions.notificationError.invoke({
            class: "error",
            message: "Seleziona un progetto da eliminare",
            position: "bottom right"
        });
        return;
    }

    if (!confirm(`Vuoi eliminare il progetto "${progetto.nome}"?`)) {
        Page.setButtonDisabled(widget, false);
        return;
    }

    App.Variables.crudProgetti.deleteRecord(
        {
            row: {
                id: progetto.id
            }
        },
        function success() {

            // svuota la searchbox
            Page.Widgets.searchByProjectName.datavalue = null;
            Page.Widgets.searchByProjectName.query = "";

            // refresh dati
            App.Variables.crudProgetti.listRecords();
            App.Variables.loadSchedeByProjectName.invoke();

            Page.Actions.notificationSuccess.invoke({
                message: "Progetto eliminato correttamente",
                position: "bottom right"
            });
            Page.setButtonDisabled(widget, false);
        },
        function error(err) {
            console.error(err);
            Page.Actions.notificationError.invoke({
                class: "error",
                message: "Errore durante l'eliminazione del progetto",
                position: "bottom right"
            });
            Page.setButtonDisabled(widget, false);
        }
    );
};

Page.buttonEditProjectClick = function ($event, widget) {
    Page.setButtonDisabled(widget, true);
    const hasFile = Page.Widgets.fileupload2.selectedFiles.length > 0;
    // SE C'È FILE → UPLOAD con nuovo metodo
    if (hasFile) {
        Page.Variables.FileServiceUploadImageAsBase64.invoke({}, function () {
            Page.setButtonDisabled(widget, false);
        }, function () {
            Page.setButtonDisabled(widget, false);
        });
    } else {
        // SOLO UPDATE NOME
        Page.updateProject(null, function () {
            Page.setButtonDisabled(widget, false);
        });
    }
};

Page.updateProject = function (base64Image, doneCb) {
    const progetto = Page.Widgets.searchByProjectName.datavalue;
    let nuovoNome = Page.Widgets.textNewProgetto.datavalue;

    if (!progetto || !progetto.id) {
        Page.Actions.notificationError.invoke({
            message: "Seleziona un progetto da modificare",
            class: "error",
            position: "bottom right"
        });
        if (doneCb) doneCb();
        return;
    }

    if (!nuovoNome || !nuovoNome.trim()) {
        Page.Actions.notificationError.invoke({
            message: "Inserisci un nome progetto valido",
            class: "error",
            position: "bottom right"
        });
        if (doneCb) doneCb();
        return;
    }

    var rowData = {
        id: progetto.id,
        nome: nuovoNome.trim()
    };
    if (base64Image !== null) {
        rowData.fotoProgetto = base64Image;
    } else {
        rowData.fotoProgetto = progetto.fotoProgetto;
    }
    App.Variables.crudProgetti.updateRecord(
        { row: rowData },
        function success(data) {
            App.Variables.crudProgetti.listRecords();
            Page.Widgets.searchByProjectName.query = nuovoNome.trim();
            Page.Widgets.searchByProjectName.datavalue = data;
            Page.Widgets.fileupload2.selectedFiles = [];
            Page.Actions.notificationSuccess.invoke({
                message: "Progetto aggiornato correttamente"
            });
            if (doneCb) doneCb();
        },
        function error(err) {
            console.error(err);
            Page.Actions.notificationError.invoke({
                message: "Errore salvataggio progetto",
                class: "error"
            });
            if (doneCb) doneCb();
        }
    );
};

Page.button5Click = function ($event, widget) {

};

Page.FileServiceUploadImageAsBase64onError = function (variable, data) {
    console.error("errore nel caricamento", data);
    Page.Actions.notificationError.invoke({
        message: "Errore upload file",
        class: "error",
        position: "bottom right"
    });
};

Page.FileServiceUploadImageAsBase64onSuccess = function (variable, data) {
    console.log("Upload immagine completato", data);

    if (data.success) {
        // data.base64Data contiene l'immagine compressa in base64
        Page.updateProject(data.base64Data);
    } else {
        Page.Actions.notificationError.invoke({
            message: data.errorMessage || "Errore elaborazione immagine",
            class: "error",
            position: "bottom right"
        });
    }
};

Page.fileupload2Select = function ($event, widget, selectedFiles) {
    // Preview da FileUpload
    if (selectedFiles && selectedFiles.length > 0) {
        const file = selectedFiles[0];
        const reader = new FileReader();

        reader.onload = function (e) {
            Page.Variables.imagePreview.datavalue = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    // Preview da DB (base64)
    const progetto = Page.Widgets.searchByProjectName.datavalue;
    if (progetto && progetto.fotoProgetto) {
        Page.Variables.imagePreview.datavalue = 'data:image/jpeg;base64,' + progetto.fotoProgetto;
    }

    // Fallback
    Page.Variables.imagePreview.datavalue = 'resources/images/imagelists/default-image.png';
};

Page.searchByProjectNameSubmit = function ($event, widget) {
    Page.Widgets.fileupload2.selectedFiles = [];
    Page.Widgets.fileupload2.clear();
};
