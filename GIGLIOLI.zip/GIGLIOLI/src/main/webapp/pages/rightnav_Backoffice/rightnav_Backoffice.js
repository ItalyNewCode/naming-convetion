/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */
};
Partial.anchorCambiaStatoClick = function ($event, widget) {
    App.activePage.Widgets.pagedialogCambiaStato.open();

};
Partial.anchorBloccaClick = function ($event, widget) {
    App.activePage.Widgets.pagedialogCambiaPropieta.open();
};



Partial.cercaClick = function ($event, widget) {
    App.activePage.Widgets.pagedialogCerca.open();
};
