/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
};

Partial.esciClick = function ($event, widget) {
    App.Actions.goToPage_master.invoke({
        data: {
            page: "0"
        }
    });
};

Partial.apriSchedaClick = function ($event, widget) {
    // var articoli = (typeof App.getSelectedArticoliForMasterActions === "function")
    //     ? App.getSelectedArticoliForMasterActions(true)
    //     : App.Variables.articoliSelezionati.getData();

    // if (!Array.isArray(articoli) || articoli.length !== 1) {
    //     App.showNotify("warning", "Seleziona esattamente un articolo");
    //     return;
    // }

    // App.Variables.articoloSelezionato.setData(articoli[0]);
    // App.Actions.goToPage_bom.navigate({
    //     data: {
    //         storico_id: null
    //     }
    // });
};

Partial.stampeClick = function ($event, widget) {
    var selezionati = App.Variables.confrontiSelezionati.getData() || [];
    var ids = _.chain(selezionati)
        .map(function (a) { return a && a.id; })
        .filter(function (id) { return id != null; })
        .uniq()
        .value();
    if (!ids.length) {
        App.showNotify("warning", "Seleziona almeno un articolo in confronto");
        return;
    }
    if (Partial.Variables && Partial.Variables.downloadPdfBomArticoliZip) {
        Partial.Variables.downloadPdfBomArticoliZip.setInput("idArticoli", ids);
        Partial.Variables.downloadPdfBomArticoliZip.invoke();
        return;
    }
    App.showNotify("warning", "Stampe non disponibili in questa vista");
};

Partial.esportaClick = function ($event, widget) {
    var selezionati = App.Variables.confrontiSelezionati.getData() || [];
    var ids = _.chain(selezionati)
        .map(function (a) { return a && a.id; })
        .filter(function (id) { return id != null; })
        .uniq()
        .value();
    if (!ids.length) {
        App.showNotify("warning", "Seleziona almeno un articolo in confronto");
        return;
    }

    if (!Partial.Variables || !Partial.Variables.downloadMasterViewByIds) {
        App.showNotify("warning", "Variabile downloadMasterViewByIds non disponibile");
        return;
    }
    Partial.Variables.downloadMasterViewByIds.setInput({});
    Partial.Variables.downloadMasterViewByIds.setInput("idsArticoli", ids);
    Partial.Variables.downloadMasterViewByIds.setInput("page", 1);
    Partial.Variables.downloadMasterViewByIds.setInput("size", ids.length);
    Partial.Variables.downloadMasterViewByIds.invoke();
};
