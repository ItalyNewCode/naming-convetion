/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */
};

Partial.comunicatoClick = function ($event, widget) {
    var articoli = (typeof App.getSelectedArticoliForMasterActions === "function")
        ? App.getSelectedArticoliForMasterActions(true)
        : App.Variables.articoliSelezionati.getData();
    if (!Array.isArray(articoli) || articoli.length !== 1) {
        App.showNotify("warning", "Seleziona esattamente un articolo");
        return;
    }

    var a = articoli[0];
    if (a.flag_storicizzato !== "S") {
        App.showNotify("warning", "La distinta dell'articolo deve essere storicizzata");
        return;
    }
    if (a.propostoPrezzoLordo === null || a.propostoPrezzoLordo === undefined || parseFloat(a.propostoPrezzoLordo) <= 0) {
        App.showNotify("warning", "Impostare un prezzo proposto maggiore di zero");
        return;
    }

    var preservedPage = Partial._getCurrentMasterPage();
    var preservedSize = Partial._getCurrentMasterPageSize();
    App.__comunicatoPendente = {
        idArticolo: a.id,
        preservedPage: preservedPage,
        preservedSize: preservedSize
    };

    var pageWidgets = Partial._getPageWidgets();
    var ta = pageWidgets && pageWidgets.textareaNotaComunicazione;
    if (ta) {
        ta.datavalue = "";
    }
    Partial._openDialogByName("dialogNotaComunicazione");
};

Partial.confrontoClick = function ($event, widget) {
    var articoli = App.Variables.articoliSelezionati.getData();

    if (!Array.isArray(articoli) || articoli.length === 0) {
        App.showNotify("warning", "Seleziona almeno un articolo da confrontare");
        return;
    }

    App.__openConfrontaRequested = true;
    App.Actions.goToPage_confronta.invoke({
        data: {
            page: "0"
        }
    });
};



Partial.esportaClick = function ($event, widget) {
    App.showNotify("info", "Funzionalità ancora in sviluppo");
};

Partial._getPageWidgets = function () {
    if (App.activePage && App.activePage.Widgets) {
        return App.activePage.Widgets;
    }
    if (typeof Page !== "undefined" && Page && Page.Widgets) {
        return Page.Widgets;
    }
    if (App.Widgets) {
        return App.Widgets;
    }
    return {};
};

Partial._openDialogByName = function (dialogName) {
    var widgets = Partial._getPageWidgets();
    var dlg = widgets ? widgets[dialogName] : null;
    if (dlg && typeof dlg.open === "function") {
        dlg.open();
        return true;
    }
    console.error("Dialog non trovato:", dialogName, widgets);
    App.showNotify("error", "Errore apertura popup: " + dialogName);
    return false;
};

Partial.anchorCambiaStatoClick = function ($event, widget) {
    // Disabilita il pulsante
    Partial.Widgets.anchorCambiaStato.disabled = true;
    Partial._openDialogByName("pagedialogCambiaStato");

    // Re-abilita dopo un breve delay (il dialog è modale)
    setTimeout(function () {
        Partial.Widgets.anchorCambiaStato.disabled = false;
    }, 500);
};

Partial.cercaClick = function ($event, widget) {
    // Disabilita il pulsante
    Partial.Widgets.cerca.disabled = true;
    Partial._openDialogByName("pagedialogCerca");

    // Re-abilita dopo un breve delay (il dialog è modale)
    setTimeout(function () {
        Partial.Widgets.cerca.disabled = false;
    }, 500);
};

Partial._getCurrentMasterPage = function () {
    return App.Variables.getMasterView.pagination.number + 1;
};

Partial._getCurrentMasterPageSize = function () {

    return App.Variables.getMasterView.pagination.size;
};

Partial.calcolaClick = function ($event, widget) {
    var articoli = (typeof App.getSelectedArticoliForMasterActions === "function")
        ? App.getSelectedArticoliForMasterActions(true)
        : App.Variables.articoliSelezionati.getData();

    if (!Array.isArray(articoli) || articoli.length === 0) {
        App.showNotify("warning", "Seleziona almeno un articolo");
        return;
    }

    // Disabilita il pulsante
    Partial.Widgets.calcola.disabled = true;
    // Salva la pagina ora: dopo il calcolo asincrono il widget può aver resettato currentPage.
    var preservedPage = Partial._getCurrentMasterPage();
    var preservedSize = Partial._getCurrentMasterPageSize();

    // Estrai solo gli ID degli articoli selezionati
    var idArticoli = articoli.map(function (a) { return a.id; });

    // Recupera prezzi proposti solo dagli articoli selezionati
    var prezziProposti = {};
    articoli.forEach(function (articolo) {
        if (articolo.propostoPrezzoLordo !== null && articolo.propostoPrezzoLordo !== undefined) {
            prezziProposti[articolo.id] = parseFloat(articolo.propostoPrezzoLordo);
        }
    });

    var prezziPropostiJson = JSON.stringify(prezziProposti);
    console.log("Prezzi proposti da inviare:", prezziProposti);

    App.Variables.fxCalcolaBomMultiplo.invoke({
        "inputFields": {
            "idArticoli": idArticoli,
            "prezziPropostiJson": prezziPropostiJson
        }
    }, function (data) {
        // WaveMaker restituisce la stringa con HTML entities, decodifichiamo
        var risultati = [];
        try {
            var jsonStr = data;
            if (typeof jsonStr === "string") {
                // Decodifica HTML entities (&quot; -> ", ecc.)
                var txt = document.createElement("textarea");
                txt.innerHTML = jsonStr;
                jsonStr = txt.value;
                risultati = JSON.parse(jsonStr);
            } else if (Array.isArray(data)) {
                risultati = data;
            }
        } catch (e) {
            console.log("Risposta calcolaBomMultiplo:", data);
            console.error("Errore parsing risultati:", e);
        }
        var errori = 0;
        var messaggiErrori = [];
        if (Array.isArray(risultati)) {
            risultati.forEach(function (r) {
                if (!r.successo) errori++;
                messaggiErrori[errori] = '\n• [' + r.idArticolo + ']' + r.esito;
                console.log("Articolo ID:", r.idArticolo, "- Esito:", r.esito, "- Successo:", r.successo);
            });
        }

        var messaggio = "Calcolo completato: " + idArticoli.length + " articoli";
        if (errori > 0) {
            messaggio += " (" + errori + " errori)\n";
            messaggio += messaggiErrori.join("\n");
            App.showNotify("warning", messaggio);
        } else {
            // App.showNotify("success", messaggio);
        }
        // Ricarica la lista master mantenendo la pagina in cui era l'utente al click.
        // WaveMaker: page/size vanno nell'oggetto opzioni di invoke; invoke({}) omette la paginazione e torna alla prima pagina.
        if (App.activePage && App.activePage.pageParams) {
            App.activePage.pageParams.page = preservedPage;
        }
        App.Variables.getMasterView.setInput("page", preservedPage);
        App.Variables.getMasterView.setInput("size", preservedSize);
        App.Variables.getMasterView.invoke({
            page: preservedPage,
            size: preservedSize
        }, function () {
            var listWidget = App.activePage && App.activePage.Widgets ? App.activePage.Widgets.getMasterViewList1 : null;
            if (listWidget) {
                listWidget.currentPage = preservedPage;
            }
            Partial.Widgets.calcola.disabled = false;
        }, function () {
            Partial.Widgets.calcola.disabled = false;
        });
    }, function (error) {
        console.error("Errore calcolo BOM multiplo:", error);
        App.showNotify("error", "Errore durante il calcolo della distinta");

        // Re-abilita il pulsante anche in caso di errore
        Partial.Widgets.calcola.disabled = false;
    });
};
// Funzione ausiliaria per aggiornare il pageParam page dal widget lista
Partial.updateCurrentPage = function () {
    var listWidget = App.activePage.Widgets.getMasterViewList1;
    if (listWidget && listWidget.currentPage !== undefined) {
        console.log("Pagina attiva (currentPage):", listWidget.currentPage);
        App.activePage.pageParams.page = listWidget.currentPage;
    }
};

Partial.avantiClick = function ($event, widget) {
    var nextBtn = document.querySelector('[name="getMasterViewList1"] .pagination-next a');
    if (nextBtn && !nextBtn.closest('li').classList.contains('disabled')) {
        Partial.Widgets.avanti.disabled = true;
        nextBtn.click();
        setTimeout(function () {
            Partial.updateCurrentPage();
            Partial.Widgets.avanti.disabled = false;
        }, 800);
    }
};

Partial.indietroClick = function ($event, widget) {
    var prevBtn = document.querySelector('[name="getMasterViewList1"] .pagination-prev a');
    if (prevBtn && !prevBtn.closest('li').classList.contains('disabled')) {
        Partial.Widgets.indietro.disabled = true;
        prevBtn.click();
        setTimeout(function () {
            Partial.updateCurrentPage();
            Partial.Widgets.indietro.disabled = false;
        }, 800);
    }
};
Partial.anchor13Click = function ($event, widget) {
    console.log(App);


    payload = _.omitBy(App.Variables.getMasterView.dataBinding, value =>
        _.isNil(value) || (_.isArray(value) && _.isEmpty(value))
    );
    Partial.Variables.downloadMasterView.setInput({});
    Partial.Variables.downloadMasterView.setInput(payload);
    Partial.Variables.downloadMasterView.setInput('page', App.Variables.getMasterView.pagination.number + 1);
    Partial.Variables.downloadMasterView.invoke();
};
Partial.reimpostaClick = function ($event, widget) {
    debugger;
     

    App.Variables.getMasterView.setInput(_.mapValues(App.Variables.getMasterView.dataBinding, () => null))
    App.Variables.getMasterView.setInput('page',1);
    App.Variables.getMasterView.setInput('size',1);
    App.Variables.getMasterView.invoke();
    App.Variables.articoliSelezionati.clearData();
};
