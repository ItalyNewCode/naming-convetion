/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Partial.onReady = function () {
    /*
     * variables can be accessed through 'Partial.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Partial.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Partial.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Partial.Widgets.username.datavalue'
     */
};

Partial.buttonSchedeSearchClick = function ($event, widget) {
    var selectedProject = App.Widgets.searchByProjectName && App.Widgets.searchByProjectName.datavalue;
    var includeUnassigned = App.Widgets.checkboxNonAssociate && App.Widgets.checkboxNonAssociate.datavalue ? 1 : 0;

    App.Variables.loadSchedeByProjectName.invoke({
        inputFields: {
            NOME_PROGETTO: selectedProject && selectedProject.nome ? selectedProject.nome : null,
            INCLUDE_UNASSIGNED: includeUnassigned,
            BRAND: Partial.Widgets.brandSearchText ? Partial.Widgets.brandSearchText.datavalue : null,
            G_TECHNOLOGY: Partial.Widgets.gtechnologySearchText ? Partial.Widgets.gtechnologySearchText.datavalue : null,
            SCHEDA: Partial.Widgets.schedaSearchText ? Partial.Widgets.schedaSearchText.datavalue : null,
            NOME_PROGETTO_SEARCH: Partial.Widgets.nomeProgettoSearchText ? Partial.Widgets.nomeProgettoSearchText.datavalue : null
        }
    });
};

Partial.buttonSchedeResetClick = function ($event, widget) {
    if (Partial.Widgets.brandSearchText) Partial.Widgets.brandSearchText.datavalue = '';
    if (Partial.Widgets.gtechnologySearchText) Partial.Widgets.gtechnologySearchText.datavalue = '';
    if (Partial.Widgets.schedaSearchText) Partial.Widgets.schedaSearchText.datavalue = '';
    if (Partial.Widgets.nomeProgettoSearchText) Partial.Widgets.nomeProgettoSearchText.datavalue = '';

    var selectedProject = App.Widgets.searchByProjectName && App.Widgets.searchByProjectName.datavalue;
    var includeUnassigned = App.Widgets.checkboxNonAssociate && App.Widgets.checkboxNonAssociate.datavalue ? 1 : 0;

    App.Variables.loadSchedeByProjectName.invoke({
        inputFields: {
            NOME_PROGETTO: selectedProject && selectedProject.nome ? selectedProject.nome : null,
            INCLUDE_UNASSIGNED: includeUnassigned,
            BRAND: null,
            G_TECHNOLOGY: null,
            SCHEDA: null,
            NOME_PROGETTO_SEARCH: null
        }
    });
};

Partial.checkbox1Change = function ($event, widget, item, currentItemWidgets, newVal) {
    const ds = App.Variables.loadSchedeByProjectName.dataSet;

    const row = ds.find(s => s.id === item.id);

    if (row) {
        row.selected = newVal;
    }
};
